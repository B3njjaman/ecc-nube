#!/usr/bin/env node
'use strict';
/**
 * ecc-ruta: costo real por encargo, subagente y modelo, vigilancia de subagentes que heredan Opus,
 * recordatorio de inicio e informe. Todo local, cero llamadas a modelos.
 *
 * Uso: node ecc-ruta.js <pre-agent|subagent-stop|stop|inicio|informe> [opciones]
 * Bajo el runner de hooks de ECC no recibe argumentos: el subcomando sale de ECC_HOOK_ID.
 * La telemetría nunca bloquea ni ensucia la sesión: cualquier error va a errores.log y se sale con 0.
 */
const fs = require('fs');
const os = require('os');
const path = require('path');

const PRECIOS = JSON.parse(fs.readFileSync(path.join(__dirname, 'ecc-precios.json'), 'utf8'));
const FAMILIAS = ['opus', 'sonnet', 'haiku', 'fable'];
const HEREDAN = new Set(['general-purpose', 'claude', 'fork', 'Explore', 'Plan']);
const POR_HOOK_ID = {
  'pre:agent:ecc-ruta': 'pre-agent',
  'subagentstop:ecc-ruta': 'subagent-stop',
  'stop:ecc-ruta': 'stop',
  'session:start:ecc-ruta': 'inicio'
};
const RE_RUTA = /^\s*\**Ruta\**\s*:\s*(.+)$/m;
const RE_RETRABAJO = /no funciona|sigue igual|no veo nada|no cambi[oó]|est[aá] igual|sigue sin|otra vez lo mismo|todav[ií]a no (sale|funciona|se ve)/i;
const TEXTO_INICIO = 'Router ECC (skill router-cascada): antes de un encargo no trivial escribe una línea «Ruta: organización · modelo/effort · control». Por defecto, la sesión sola y en secuencia; implementar → ecc:constructor (Sonnet); leer algo grande → ecc:explorador (Haiku); Opus en un subagente solo con motivo. Nunca general-purpose ni fork en Opus por descuido.\n';
const MOTIVO_DENY = 'Este subagente correría en Opus sin motivo. Usa el agente de la cascada: ecc:explorador (buscar y leer), ecc:mecanico (cambios exactos), ecc:ejecutor (comandos), ecc:constructor (implementar), ecc:resolutor (lo difícil), o pasa model: "sonnet" o "haiku". Si de verdad necesita Opus, agrega al brief una línea «Motivo Opus: <por qué>».';

// ---------- rutas y E/S ----------
function configDir() {
  let d = (process.env.CLAUDE_CONFIG_DIR || '').trim() || path.join(os.homedir(), '.claude');
  if (d === '~') d = os.homedir();
  else if (d.startsWith('~/') || d.startsWith('~\\')) d = path.join(os.homedir(), d.slice(2));
  return path.resolve(d);
}
function dataDir() {
  return process.env.ECC_RUTA_DIR || path.join(configDir(), 'ecc-rendimiento');
}
function anotarError(err, donde) {
  try {
    fs.mkdirSync(dataDir(), { recursive: true });
    fs.appendFileSync(path.join(dataDir(), 'errores.log'),
      `${new Date().toISOString()} ${donde || ''} ${err && err.stack ? err.stack : err}\n`);
  } catch (_) { /* sin dónde anotar */ }
}
function dormir(ms) {
  Atomics.wait(new Int32Array(new SharedArrayBuffer(4)), 0, 0, ms);
}
function registrar(sid, obj) {
  fs.mkdirSync(dataDir(), { recursive: true });
  const linea = JSON.stringify({ ts: new Date().toISOString(), session_id: sid, ...obj });
  fs.appendFileSync(path.join(dataDir(), 'registro.jsonl'), linea + '\n');
}
function leerJson(ruta, defecto) {
  try { return JSON.parse(fs.readFileSync(ruta, 'utf8')); } catch (_) { return defecto; }
}
function escribirAtomico(ruta, texto) {
  const tmp = `${ruta}.${process.pid}.tmp`;
  fs.writeFileSync(tmp, texto);
  for (let i = 0; ; i++) {
    try { fs.renameSync(tmp, ruta); return; } catch (e) {
      if (i >= 8 || !['EPERM', 'EBUSY', 'EACCES'].includes(e.code)) {
        try { fs.unlinkSync(tmp); } catch (_) { /* ya no está */ }
        throw e;
      }
      dormir(15 * (i + 1));
    }
  }
}
/** Lee-modifica-escribe estado.json bajo un lock de archivo (los hooks async pueden solaparse). */
function conEstado(fn) {
  fs.mkdirSync(dataDir(), { recursive: true });
  const lock = path.join(dataDir(), 'estado.lock');
  let fd = null;
  for (let i = 0; i < 100 && fd === null; i++) {
    try { fd = fs.openSync(lock, 'wx'); } catch (e) {
      if (e.code !== 'EEXIST' && e.code !== 'EPERM' && e.code !== 'EACCES') throw e;
      try { if (Date.now() - fs.statSync(lock).mtimeMs > 5000) fs.unlinkSync(lock); } catch (_) { /* otro lo soltó */ }
      dormir(20);
    }
  }
  try {
    const ruta = path.join(dataDir(), 'estado.json');
    const estado = leerJson(ruta, {});
    estado.cursores = estado.cursores || {};
    estado.sesiones = estado.sesiones || {};
    const r = fn(estado);
    escribirAtomico(ruta, JSON.stringify(estado));
    return r;
  } finally {
    if (fd !== null) {
      try { fs.closeSync(fd); } catch (_) { /* nada */ }
      try { fs.unlinkSync(lock); } catch (_) { /* nada */ }
    }
  }
}
function leerStdin() {
  return new Promise(resolve => {
    const trozos = [];
    process.stdin.on('data', t => trozos.push(t));
    process.stdin.on('end', () => resolve(Buffer.concat(trozos).toString('utf8')));
    process.stdin.on('error', () => resolve(Buffer.concat(trozos).toString('utf8')));
  });
}

// ---------- precios y uso ----------
function familia(modelo) {
  const m = String(modelo || '').toLowerCase();
  return FAMILIAS.find(f => m.includes(f)) || 'otro';
}
function tokensDe(usage) {
  const u = usage || {};
  return {
    input: u.input_tokens || 0,
    cache_write: u.cache_creation_input_tokens || 0,
    cache_read: u.cache_read_input_tokens || 0,
    output: u.output_tokens || 0
  };
}
/** Costo en USD por componente de UNA request. */
function desgloseCosto(fam, t) {
  const p = PRECIOS.modelos[fam];
  if (!p) return { input: 0, cache_write: 0, cache_read: 0, output: 0 };
  const tarifa = p.largo && t.input + t.cache_write + t.cache_read > p.umbral_prompt ? p.largo : p;
  return {
    input: t.input * tarifa.input / 1e6,
    cache_write: t.cache_write * tarifa.cache_write / 1e6,
    cache_read: t.cache_read * tarifa.cache_read / 1e6,
    output: t.output * tarifa.output / 1e6
  };
}
function costoRequest(fam, t) {
  const d = desgloseCosto(fam, t);
  return d.input + d.cache_write + d.cache_read + d.output;
}
function vacio() {
  return { input: 0, cache_write: 0, cache_read: 0, output: 0, costo: 0, n: 0 };
}
function sumar(acum, fam, t) {
  const a = acum[fam] || (acum[fam] = vacio());
  a.input += t.input; a.cache_write += t.cache_write; a.cache_read += t.cache_read; a.output += t.output;
  a.costo += costoRequest(fam, t);
  a.n += 1;
}
function redondear(acum) {
  const r = {};
  for (const [f, a] of Object.entries(acum)) r[f] = { ...a, costo: Math.round(a.costo * 1e6) / 1e6 };
  return r;
}
function costoTotal(acum) {
  return Math.round(Object.values(acum).reduce((s, a) => s + a.costo, 0) * 1e6) / 1e6;
}

// ---------- transcripts ----------
/** Lee lo nuevo de un archivo desde el offset; solo consume líneas completas. */
function leerDesde(ruta, offset) {
  const st = fs.statSync(ruta);
  if (st.size < offset) offset = 0; // el archivo se truncó o rotó
  if (st.size === offset) return { lineas: [], offset };
  const fd = fs.openSync(ruta, 'r');
  let buf;
  try {
    buf = Buffer.alloc(st.size - offset);
    fs.readSync(fd, buf, 0, buf.length, offset);
  } finally { fs.closeSync(fd); }
  const ultimo = buf.lastIndexOf(0x0a);
  if (ultimo < 0) return { lineas: [], offset };
  const lineas = [];
  for (const t of buf.subarray(0, ultimo + 1).toString('utf8').split('\n')) {
    if (!t.trim()) continue;
    try { lineas.push(JSON.parse(t)); } catch (_) { /* línea corrupta */ }
  }
  return { lineas, offset: offset + ultimo + 1 };
}
function claveMsg(l) {
  const id = l.message && l.message.id;
  return id ? `${id}|${l.requestId || ''}` : null;
}
function modeloReal(l) {
  const m = l.message && l.message.model;
  return m && m !== '<synthetic>' ? m : null;
}
function esAsistenteConUso(l) {
  return l && l.type === 'assistant' && l.message && l.message.usage && modeloReal(l);
}
/** Dedupe de respuestas en streaming: por clave gana la línea con más output. */
function mejorPorClave(lineas, vistos) {
  const mejores = new Map();
  let anon = 0;
  for (const l of lineas) {
    if (!esAsistenteConUso(l)) continue;
    const k = claveMsg(l) || `anon${anon++}`;
    if (vistos && vistos.has(k)) continue;
    const t = tokensDe(l.message.usage);
    const previo = mejores.get(k);
    if (!previo || t.output >= previo.t.output) mejores.set(k, { fam: familia(l.message.model), t });
  }
  return mejores;
}
function textoAsistente(l) {
  const c = l.message && l.message.content;
  if (typeof c === 'string') return c;
  if (!Array.isArray(c)) return '';
  return c.filter(b => b && b.type === 'text' && typeof b.text === 'string').map(b => b.text).join('\n');
}
function textoUsuario(l) {
  if (l.isMeta) return '';
  const c = l.message && l.message.content;
  let t = '';
  if (typeof c === 'string') t = c;
  else if (Array.isArray(c)) t = c.filter(b => b && b.type === 'text' && typeof b.text === 'string').map(b => b.text).join('\n');
  t = t.trim();
  return /^<(command-|local-command|system-reminder|task-notification)/.test(t) ? '' : t;
}
function cursorDe(estado, ruta) {
  return estado.cursores[ruta] || (estado.cursores[ruta] = { offset: 0, linea: 0, vistos: [] });
}
function recordarVistos(cursor, claves) {
  cursor.vistos = cursor.vistos.concat([...claves]).slice(-500);
}

// ---------- pre-agent ----------
function frontmatterModelo(ruta) {
  try {
    const t = fs.readFileSync(ruta, 'utf8');
    const m = /^---\r?\n([\s\S]*?)\r?\n---/.exec(t);
    if (!m) return undefined;
    const mm = /^model:\s*["']?([^\s"']+)/m.exec(m[1]);
    return mm ? mm[1] : undefined;
  } catch (_) { return undefined; }
}
function candidatosAgente(tipo, cwd) {
  const out = [];
  const extra = (process.env.ECC_RUTA_AGENT_DIRS || '').split(';').filter(Boolean);
  const nombre = tipo.includes(':') ? tipo.split(':').slice(1).join(':') : tipo;
  for (const d of extra) out.push(path.join(d, `${nombre}.md`));
  if (tipo.startsWith('ecc:')) {
    const raiz = process.env.CLAUDE_PLUGIN_ROOT || process.env.ECC_PLUGIN_ROOT || path.resolve(__dirname, '..', '..');
    out.push(path.join(raiz, 'agents', `${nombre}.md`));
  } else if (tipo.includes(':')) {
    const plugin = tipo.split(':')[0];
    const cache = path.join(configDir(), 'plugins', 'cache');
    try {
      for (const mercado of fs.readdirSync(cache)) {
        const base = path.join(cache, mercado, plugin);
        let versiones = [];
        try { versiones = fs.readdirSync(base); } catch (_) { continue; }
        versiones.sort((a, b) => b.localeCompare(a, undefined, { numeric: true }));
        for (const v of versiones) out.push(path.join(base, v, 'agents', `${nombre}.md`));
      }
    } catch (_) { /* sin caché de plugins */ }
  } else {
    out.push(path.join(configDir(), 'agents', `${nombre}.md`));
    if (cwd) out.push(path.join(cwd, '.claude', 'agents', `${nombre}.md`));
  }
  return out;
}
function modeloSesion(transcript) {
  try {
    const st = fs.statSync(transcript);
    const largo = Math.min(st.size, 256 * 1024);
    const fd = fs.openSync(transcript, 'r');
    const buf = Buffer.alloc(largo);
    try { fs.readSync(fd, buf, 0, largo, st.size - largo); } finally { fs.closeSync(fd); }
    const lineas = buf.toString('utf8').split('\n');
    for (let i = lineas.length - 1; i >= 0; i--) {
      try {
        const l = JSON.parse(lineas[i]);
        if (l.type === 'assistant' && modeloReal(l)) return familia(modeloReal(l));
      } catch (_) { /* primera línea cortada o parcial */ }
    }
  } catch (_) { /* sin transcript */ }
  return null;
}
function modeloEfectivo(input) {
  const ti = input.tool_input || {};
  const tipo = ti.subagent_type || 'general-purpose';
  const pedido = ti.model ? String(ti.model) : null;
  const pedidoFam = pedido && pedido !== 'inherit' ? familia(pedido) : null;
  if (pedidoFam && tipo !== 'fork') return { tipo, pedido, modelo: pedidoFam, origen: 'parametro' };
  if (HEREDAN.has(tipo)) {
    return { tipo, pedido, modelo: modeloSesion(input.transcript_path) || 'desconocido', origen: 'herencia' };
  }
  for (const ruta of candidatosAgente(tipo, input.cwd)) {
    if (!fs.existsSync(ruta)) continue;
    const m = frontmatterModelo(ruta);
    if (m && m !== 'inherit') return { tipo, pedido, modelo: familia(m), origen: 'definicion' };
    return { tipo, pedido, modelo: modeloSesion(input.transcript_path) || 'desconocido', origen: 'definicion' };
  }
  return { tipo, pedido, modelo: 'desconocido', origen: 'desconocido' };
}
function preAgent(raw) {
  const input = JSON.parse(raw);
  const ti = input.tool_input || {};
  const r = modeloEfectivo(input);
  registrar(input.session_id, {
    tipo: 'lanzamiento', tool_use_id: input.tool_use_id, agente: r.tipo,
    modelo_pedido: r.pedido, modelo_efectivo: r.modelo, origen: r.origen, descripcion: ti.description
  });
  const cfg = leerJson(path.join(dataDir(), 'config.json'), {});
  if (cfg.modo === 'bloquear' && ['opus', 'fable'].includes(r.modelo) && HEREDAN.has(r.tipo)
      && !/^[ \t]*Motivo Opus:/m.test(String(ti.prompt || ''))) {
    return JSON.stringify({
      hookSpecificOutput: {
        hookEventName: 'PreToolUse', permissionDecision: 'deny', permissionDecisionReason: MOTIVO_DENY
      }
    });
  }
  return '';
}

// ---------- subagent-stop ----------
function señales(texto) {
  const t = String(texto || '');
  const v = /\b(APROBADO|RECHAZADO)\b/.exec(t);
  return {
    veredicto: v ? v[1] : null,
    escalar: /ESCALAR/.test(t),
    consulta: /^\s*CONSULTA:/m.test(t),
    criticos: (t.match(/\bCRITICAL\b/g) || []).length,
    altos: (t.match(/\bHIGH\b/g) || []).length
  };
}
function subagentStop(raw) {
  const input = JSON.parse(raw);
  if (!input.agent_type || !input.agent_transcript_path) return;
  const ruta = input.agent_transcript_path;
  const sid = input.session_id;
  const uso = {};
  let encargo;
  conEstado(estado => {
    const c = cursorDe(estado, ruta);
    const { lineas, offset } = leerDesde(ruta, c.offset);
    const mejores = mejorPorClave(lineas, new Set(c.vistos));
    for (const { fam, t } of mejores.values()) sumar(uso, fam, t);
    recordarVistos(c, [...mejores.keys()].filter(k => !k.startsWith('anon')));
    c.offset = offset; c.linea += lineas.length;
    encargo = (estado.sesiones[sid] || {}).encargo || `${sid}:0`;
  });
  if (!Object.keys(uso).length) return;
  const meta = leerJson(ruta.replace(/\.jsonl$/, '.meta.json'), {});
  registrar(sid, {
    tipo: 'subagente', agente: meta.agentType || input.agent_type, agent_id: input.agent_id,
    tool_use_id: meta.toolUseId, encargo, uso: redondear(uso), costo: costoTotal(uso),
    'señales': señales(input.last_assistant_message)
  });
}

// ---------- stop ----------
function stopHook(raw) {
  const input = JSON.parse(raw);
  const ruta = input.transcript_path;
  const sid = input.session_id;
  if (!ruta) return;
  const eventos = []; // se registran fuera del lock
  conEstado(estado => {
    const ses = estado.sesiones[sid] || (estado.sesiones[sid] = { n: 0, encargo: `${sid}:0` });
    const c = cursorDe(estado, ruta);
    const { lineas, offset } = leerDesde(ruta, c.offset);
    const propias = lineas.filter(l => !l.isSidechain);
    const mejores = mejorPorClave(propias, new Set(c.vistos));
    let acum = {};
    const vaciar = () => {
      if (Object.keys(acum).length) {
        eventos.push({ tipo: 'turno', encargo: ses.encargo, uso: redondear(acum), costo: costoTotal(acum) });
      }
      acum = {};
    };
    const contados = new Set();
    for (const l of propias) {
      if (l.type === 'assistant') {
        const k = claveMsg(l);
        const m = RE_RUTA.exec(textoAsistente(l));
        if (m && !(k && contados.has(k))) {
          vaciar();
          ses.n += 1;
          ses.encargo = `${sid}:${ses.n}`;
          eventos.push({ tipo: 'encargo', encargo: ses.encargo, ruta: m[1].trim() });
        }
        if (k && mejores.has(k) && !contados.has(k)) {
          contados.add(k);
          const { fam, t } = mejores.get(k);
          sumar(acum, fam, t);
        }
      } else if (l.type === 'user') {
        const t = textoUsuario(l);
        if (t && RE_RETRABAJO.test(t)) eventos.push({ tipo: 'retrabajo', encargo: ses.encargo, muestra: t.slice(0, 80) });
      } else if (l.type === 'system' && l.subtype === 'compact_boundary') {
        eventos.push({ tipo: 'compactacion', encargo: ses.encargo });
      }
    }
    for (const [k, v] of mejores) { // respuestas sin id: no tienen clave de dedupe
      if (k.startsWith('anon')) sumar(acum, v.fam, v.t);
    }
    vaciar();
    recordarVistos(c, [...mejores.keys()].filter(k => !k.startsWith('anon')));
    c.offset = offset; c.linea += lineas.length;
  });
  for (const e of eventos) registrar(sid, e);
}

// ---------- informe ----------
function mediana(xs) {
  if (!xs.length) return 0;
  const s = [...xs].sort((a, b) => a - b);
  const m = s.length >> 1;
  return s.length % 2 ? s[m] : (s[m - 1] + s[m]) / 2;
}
const usd = x => `US$${x.toLocaleString('es-CL', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;
const pct = (x, total) => (total ? `${(100 * x / total).toFixed(1)} %` : '0 %');
const pocas = n => (n < 5 ? ' (pocas muestras)' : '');
function tabla(cab, filas) {
  return [`| ${cab.join(' | ')} |`, `| ${cab.map(() => '---').join(' | ')} |`, ...filas.map(f => `| ${f.join(' | ')} |`)].join('\n');
}
function parseArgs(argv) {
  const o = { dias: 14, transcripts: false, carpeta: null };
  for (let i = 0; i < argv.length; i++) {
    if (argv[i] === '--dias') o.dias = Number(argv[++i]) || 14;
    else if (argv[i] === '--transcripts') {
      o.transcripts = true;
      if (argv[i + 1] && !argv[i + 1].startsWith('--')) o.carpeta = argv[++i];
    }
  }
  return o;
}
function informeRegistro(dias) {
  const corte = Date.now() - dias * 864e5;
  const regs = [];
  try {
    for (const t of fs.readFileSync(path.join(dataDir(), 'registro.jsonl'), 'utf8').split('\n')) {
      if (!t.trim()) continue;
      try { const r = JSON.parse(t); if (Date.parse(r.ts) >= corte) regs.push(r); } catch (_) { /* línea corrupta */ }
    }
  } catch (_) {
    return `# Rendimiento ECC (${dias} días)\n\nSin registro todavía (${path.join(dataDir(), 'registro.jsonl')}).\n`;
  }
  const filas = new Map(); // "quien|modelo" -> {costo, n}
  const suma = (quien, fam, costo, n) => {
    const k = `${quien}|${fam}`;
    const f = filas.get(k) || { quien, fam, costo: 0, n: 0 };
    f.costo += costo; f.n += n; filas.set(k, f);
  };
  const encargos = new Map();
  const enc = id => encargos.get(id) || encargos.set(id, { costo: 0, retrabajo: false, veredictos: [] }).get(id);
  const lanz = new Map();
  const subPorTool = new Map();
  let escalar = 0, consultas = 0;
  for (const r of regs) {
    if (r.tipo === 'turno') {
      for (const [f, a] of Object.entries(r.uso)) suma('sesión', f, a.costo, a.n);
      enc(r.encargo).costo += r.costo;
    } else if (r.tipo === 'subagente') {
      for (const [f, a] of Object.entries(r.uso)) suma(r.agente, f, a.costo, 1);
      enc(r.encargo).costo += r.costo;
      const s = r['señales'] || {};
      if (s.veredicto) enc(r.encargo).veredictos.push(s.veredicto);
      if (s.escalar) escalar++;
      if (s.consulta) consultas++;
      if (r.tool_use_id) subPorTool.set(r.tool_use_id, (subPorTool.get(r.tool_use_id) || 0) + r.costo);
    } else if (r.tipo === 'retrabajo') enc(r.encargo).retrabajo = true;
    else if (r.tipo === 'lanzamiento') lanz.set(r.tool_use_id || `x${lanz.size}`, r);
    else if (r.tipo === 'encargo') enc(r.encargo);
  }
  const total = [...filas.values()].reduce((s, f) => s + f.costo, 0);
  const lista = [...filas.values()].sort((a, b) => b.costo - a.costo);
  const out = [`# Rendimiento ECC (últimos ${dias} días)`, '',
    '_Costo equivalente API; con suscripción no es la factura sino lo que consume los límites._', '',
    '## Quién gasta', '',
    tabla(['Quién', 'Modelo', 'Costo', '%', 'Turnos/Subagentes'],
      lista.map(f => [f.quien, f.fam, usd(f.costo), pct(f.costo, total), `${f.n}${pocas(f.n)}`])),
    '', `Total: ${usd(total)}`, ''];
  const ids = [...encargos.values()];
  const costos = ids.map(e => e.costo);
  const conVer = ids.filter(e => e.veredictos.length);
  out.push('## Encargos', '',
    `- Encargos: ${ids.length}${pocas(ids.length)}`,
    `- Costo mediano: ${usd(mediana(costos))}; total: ${usd(costos.reduce((s, x) => s + x, 0))}`,
    `- Con retrabajo: ${pct(ids.filter(e => e.retrabajo).length, ids.length)}`,
    `- APROBADO a la primera: ${pct(conVer.filter(e => e.veredictos[0] === 'APROBADO').length, conVer.length)} de ${conVer.length} con veredicto${pocas(conVer.length)}`,
    `- Escalamientos (ESCALAR): ${escalar}; consultas (CONSULTA:): ${consultas}`, '');
  const origen = new Map();
  for (const l of lanz.values()) {
    const o = origen.get(l.origen) || { n: 0, her: 0, costoHer: 0 };
    o.n++;
    if (l.modelo_efectivo === 'opus' && l.origen === 'herencia') { o.her++; o.costoHer += subPorTool.get(l.tool_use_id) || 0; }
    origen.set(l.origen, o);
  }
  out.push('## Lanzamientos por origen', '',
    tabla(['Origen', 'Lanzamientos', 'Heredaron Opus', 'Costo de los que heredaron Opus'],
      [...origen].map(([k, o]) => [k, `${o.n}${pocas(o.n)}`, String(o.her), usd(o.costoHer)])), '');
  return out.join('\n');
}
function recorrer(dir, acc) {
  let ents;
  try { ents = fs.readdirSync(dir, { withFileTypes: true }); } catch (_) { return acc; }
  for (const e of ents) {
    const p = path.join(dir, e.name);
    if (e.isDirectory()) recorrer(p, acc);
    else if (e.name.endsWith('.jsonl')) acc.push(p);
  }
  return acc;
}
function agregarTranscripts(dias, carpeta) {
  const base = carpeta || process.env.ECC_RUTA_PROJECTS || path.join(configDir(), 'projects');
  const corte = Date.now() - dias * 864e5;
  const archivos = recorrer(base, []).filter(p => fs.statSync(p).mtimeMs >= corte).sort();
  const vistos = new Map(); // clave -> {quien, fam, t}
  let anon = 0;
  for (const p of archivos) {
    const sub = /[\\/]subagents[\\/]/.test(p);
    const quien = sub ? (leerJson(p.replace(/\.jsonl$/, '.meta.json'), {}).agentType || 'subagente') : 'sesión';
    let texto;
    try { texto = fs.readFileSync(p, 'utf8'); } catch (_) { continue; }
    for (const t of texto.split('\n')) {
      if (!t || t.indexOf('"usage"') < 0) continue;
      let l;
      try { l = JSON.parse(t); } catch (_) { continue; }
      if (!esAsistenteConUso(l) || !(Date.parse(l.timestamp) >= corte)) continue;
      const k = claveMsg(l) || `anon${anon++}`;
      const tk = tokensDe(l.message.usage);
      const previo = vistos.get(k);
      if (!previo) vistos.set(k, { quien, fam: familia(l.message.model), t: tk });
      else if (tk.output > previo.t.output) previo.t = tk;
    }
  }
  const filas = new Map();
  for (const { quien, fam, t } of vistos.values()) {
    const k = `${quien}|${fam}`;
    const f = filas.get(k) || { quien, fam, n: 0, d: { input: 0, cache_write: 0, cache_read: 0, output: 0 } };
    const d = desgloseCosto(fam, t);
    for (const c of Object.keys(f.d)) f.d[c] += d[c];
    f.n++; filas.set(k, f);
  }
  const lista = [...filas.values()].map(f => ({ ...f, costo: f.d.input + f.d.cache_write + f.d.cache_read + f.d.output }))
    .sort((a, b) => b.costo - a.costo);
  return { archivos: archivos.length, unicas: vistos.size, filas: lista, total: lista.reduce((s, f) => s + f.costo, 0) };
}
function informeTranscripts(dias, carpeta) {
  const { archivos, unicas, filas, total } = agregarTranscripts(dias, carpeta);
  return [`# Rendimiento ECC desde transcripts (últimos ${dias} días)`, '',
    `Archivos leídos: ${archivos}; respuestas únicas: ${unicas}`, '',
    '_Costo equivalente API; con suscripción no es la factura sino lo que consume los límites._', '',
    tabla(['Quién', 'Modelo', 'Costo', '%', 'Turnos', 'Entrada', 'Escritura caché', 'Lectura caché', 'Salida'],
      filas.map(f => [f.quien, f.fam, usd(f.costo), pct(f.costo, total), `${f.n}${pocas(f.n)}`,
        usd(f.d.input), usd(f.d.cache_write), usd(f.d.cache_read), usd(f.d.output)])),
    '', `Total: ${usd(total)}`, ''].join('\n');
}
function informe(argv) {
  const o = parseArgs(argv);
  return o.transcripts ? informeTranscripts(o.dias, o.carpeta) : informeRegistro(o.dias);
}

// ---------- entrada ----------
async function main() {
  const sub = process.argv[2] || POR_HOOK_ID[process.env.ECC_HOOK_ID || ''];
  try {
    if (sub === 'informe') { process.stdout.write(informe(process.argv.slice(3)) + '\n'); return; }
    if (sub === 'inicio') { await leerStdin(); process.stdout.write(TEXTO_INICIO); return; }
    const manejadores = { 'pre-agent': preAgent, 'subagent-stop': subagentStop, stop: stopHook };
    if (!manejadores[sub]) return;
    const raw = await leerStdin();
    const salida = manejadores[sub](raw);
    if (salida) process.stdout.write(salida);
  } catch (e) { anotarError(e, sub); }
}

if (require.main === module) {
  main().catch(e => anotarError(e, 'main')).finally(() => { process.exitCode = 0; });
}

module.exports = { familia, costoRequest, desgloseCosto, mejorPorClave, señales, agregarTranscripts };
