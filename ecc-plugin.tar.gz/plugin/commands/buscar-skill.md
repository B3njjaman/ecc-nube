---
description: Busca una skill o un servidor MCP que cubra una necesidad (instalado, ECC completo, marketplace oficial, anthropics/skills y GitHub), la revisa entera y la usa o la instala según la skill buscar-skills.
argument-hint: "<qué hace falta saber hacer o a qué sistema hay que acceder>"
---

# /buscar-skill

Carga la skill `buscar-skills` y aplícala a esta necesidad: $ARGUMENTS

1. Di si lo que falta es una skill o un MCP (sección 0).
2. Busca en las fuentes en orden (sección 2) y quédate con 5 candidatos como máximo.
3. Revisa entero el mejor candidato antes de usarlo (sección 3).
4. Úsalo una vez o déjalo instalado según quién decide (sección 4), e informa con la tabla final.
