---
description: Informe de costo y resultado de las rutas de trabajo (sesión, subagentes, modelos, encargos) desde el registro de ECC, y propuesta de ajustes a la skill router-cascada para que cada tipo de tarea vaya por la ruta más barata que pase la revisión.
argument-hint: "[días, por defecto 14]"
---

# /rendimiento

Sin llamar a ningún agente (es un comando y su lectura; la sesión sola basta):

1. Corre el informe con los días pedidos (`$ARGUMENTS`, o 14 si viene vacío):
   ```bash
   node "$(ls -d ~/.claude/plugins/cache/ecc-benja/ecc/*/ | sort -V | tail -1)scripts/hooks/ecc-ruta.js" informe --dias <días>
   ```
   Si el registro tiene menos de 5 encargos, corre además el mismo comando con `--transcripts` para ver la línea base sacada directo de los transcripts.
2. Muéstrale a Benja, en 10 a 15 líneas:
   - dónde se fue el costo: la sesión, cada tipo de subagente y cada modelo;
   - cuántos subagentes heredaron Opus sin motivo, y cuánto costaron;
   - por tipo de encargo: costo mediano, % con retrabajo, % aprobado a la primera y escalamientos, con cuántos casos hay detrás.
3. Propón como mucho 3 ajustes a la skill `router-cascada`, siguiendo su sección 7:
   - la mejor ruta es la más barata entre las que pasan la revisión sin retrabajo;
   - con menos de 5 casos no se cambia una regla;
   - cada propuesta dice qué texto cambia, qué dato la respalda y cuánto se ahorraría.
4. Si `~/.claude/ecc-rendimiento/config.json` está en `"modo": "observar"` y hay al menos una semana de datos con lanzamientos que heredaron Opus, propón pasar a `"bloquear"`.
5. No apliques nada sin el OK de Benja. Los cambios a la skill van en `C:\Users\Benja\ecc-benja\extras\` y se instalan con `python C:/Users/Benja/ecc-benja/ecc.py actualizar`, que corre Benja. Anota en la memoria del proyecto lo que se decidió.
