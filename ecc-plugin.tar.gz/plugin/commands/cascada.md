---
description: Elige la ruta más simple y barata para una tarea y la reparte entre la sesión, Haiku, Sonnet y Opus, con el effort de cada parte, siguiendo la skill router-cascada - escribe la línea Ruta, lanza en paralelo solo lo independiente, verifica lo que hizo Haiku y sube effort o modelo cuando algo falla.
argument-hint: "<tarea o entrega del plan>"
---

# /cascada

Carga la skill `router-cascada` y aplícala a esta tarea: $ARGUMENTS

1. Elige la ruta (sección 0 de la skill): organización, modelo y effort, y cómo se comprueba. Escríbela en una línea `Ruta: …`. Si la sesión sola basta, dilo y hazlo sin repartir.
2. Si hay que repartir, divide la tarea en partes y clasifica cada una en el nivel 0, 1, 2 o 3 con su effort (secciones 1 y 1b). Muestra la tabla en 5 a 10 líneas: parte, nivel, agente, effort.
3. Si alguna parte cambia arquitectura, toca 3 o más archivos o es ambigua y no hay un plan aprobado: primero `/ecc:plan` y espera el OK de Benja.
4. Lanza en paralelo solo las partes independientes, con un brief completo para cada agente (sección 4). Una secuencia de pasos dependientes va entera a un solo agente, o se queda en la sesión.
5. Si un constructor responde `CONSULTA`, contéstale corto con `SendMessage` (sección 2b).
6. Verifica toda salida del nivel 1 (sección 2, punto 3) y sube effort o modelo según el tipo de fallo (punto 4).
7. Cierra con la revisión y la verificación de siempre del ciclo ECC.
8. Informa: qué quedó hecho y con qué evidencia, qué subió de effort o de modelo y por qué.
