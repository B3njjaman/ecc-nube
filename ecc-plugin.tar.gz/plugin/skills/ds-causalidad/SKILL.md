---
name: ds-causalidad
description: "Responder preguntas causales (qué pasa si hago X, X causó Y, cuánto efecto tuvo una intervención, a quién conviene aplicarla) sin confundir asociación con causa: estimando, escalera de evidencia, diagrama causal (DAG) y qué controlar y qué no, diseño según cómo se asignó el tratamiento (experimento, diferencias en diferencias, regresión discontinua, variables instrumentales, ajuste por observables con IPW o AIPW, control sintético, series de tiempo interrumpidas), supuestos de cada diseño y cómo ponerlos a prueba (placebos, tendencias previas, balance, sensibilidad con E-value), efectos heterogéneos y uplift, y procesos industriales con lazos de control. Úsala cuando la pregunta sea de efecto o de palanca, al evaluar el impacto de un programa, campaña, cambio de proceso o política, o al revisar si un análisis puede afirmar causalidad."
metadata:
  origin: "ecc-benja; ideas de hypothesis-generation (causal_inference_and_claims) de K-Dense-AI/claude-scientific-skills (MIT, a25cf9ec00e2); diseños según Angrist y Pischke, Hernán y Robins, Cunningham (Causal Inference: The Mixtape)"
---

# Inferencia causal

Una asociación dice qué pasa junto. Un efecto causal dice qué pasaría con estos mismos casos si se cambiara X y nada más. Lo que permite pasar de lo primero a lo segundo es el **diseño**, es decir, cómo se asignó el tratamiento, y no el modelo: ningún algoritmo convierte una correlación en causa por sí solo.

El código de cada diseño, con datos simulados donde se conoce el efecto real, está en [references/recetario.md](references/recetario.md) (probado con statsmodels 0.15, linearmodels 7.1, scikit-learn 1.9 y scipy 1.17). El ciclo completo está en `ds-maestro`; los experimentos A/B, en `ds-hipotesis-y-pruebas`.

## 1. ¿La pregunta es causal? El estimando

Es causal si la respuesta se usaría para **cambiar** algo: lanzar, invertir, ajustar un proceso, dirigir una campaña. Se define:

- **Tratamiento**: qué, exactamente, y desde cuándo (no "la capacitación", sino "el curso de 16 horas completado antes de marzo").
- **Resultado** y ventana en que se mide.
- **Población** y el **contraste**: ATE (efecto promedio en todos), ATT (en los que recibieron el tratamiento: "¿sirvió el programa a quienes lo tomaron?") o CATE (efecto según características: "¿a quién le sirve?").
- **El contrafactual**, en una frase: "qué habría pasado con estas plantas en estos meses sin el reactivo nuevo".

## 2. Escalera de evidencia y el verbo permitido

| Peldaño | Diseño | Se puede escribir |
|---|---|---|
| 1 | Experimento aleatorizado bien ejecutado | "causa", "produce", con su IC |
| 2 | Cuasi-experimento con supuestos argumentados y diagnosticados (regresión discontinua, diferencias en diferencias, variables instrumentales, control sintético) | "el efecto estimado es…, bajo el supuesto de…" |
| 3 | Observacional con ajuste por confusores (regresión, IPW, AIPW) y análisis de sensibilidad | "se asocia con…, ajustando por…; un confusor no medido tendría que ser de tal fuerza para anularlo" |
| 4 | Correlación sin ajuste | "se asocia con", y nada más |

Si se puede aleatorizar, se aleatoriza: es más barato que discutir supuestos. En procesos industriales, eso puede ser una **operación evolutiva (EVOP)**: variaciones chicas y planificadas en la operación normal, asignadas al azar por turno o por línea.

## 3. Diagrama causal (DAG): qué controlar y qué no

Se dibuja con quien conoce el proceso (operaciones, negocio, el profesor guía) **antes** de mirar los resultados. Cada flecha es una afirmación: "A afecta a B".

- **Sí se controla**: los **confusores**, o causas comunes del tratamiento y del resultado.
- **No se controlan los mediadores** (el camino por el que actúa el tratamiento) si se quiere el efecto total.
- **No se controlan los colisionadores**, es decir, consecuencias comunes del tratamiento y el resultado o de sus causas: controlarlos crea una asociación falsa. Tampoco las variables medidas después del tratamiento, ni los instrumentos (agregan varianza y pueden amplificar el sesgo).
- `dagitty.net` (o la librería DoWhy) dice qué conjunto mínimo de variables basta ajustar.

Ejemplo en una planta concentradora, para el efecto del reactivo sobre la recuperación: la **ley de alimentación** es un confusor, porque el operador dosifica según la ley y la ley mueve la recuperación, así que se controla. El **pH de la pulpa** es un mediador, porque el reactivo actúa en parte a través de él, así que no se controla si se quiere el efecto total. "Turno con incidente reportado" puede ser un colisionador, porque lo afectan la dosis y la recuperación, así que no se controla.

## 4. Elegir el diseño según cómo se asignó el tratamiento

| Cómo se asignó | Diseño | Supuesto clave | Cómo se pone a prueba |
|---|---|---|---|
| Al azar | experimento (A/B) | la aleatorización se cumplió y no hay interferencia | SRM, balance de covariables previas (`ds-hipotesis-y-pruebas`) |
| A un grupo desde una fecha, con otro grupo comparable no tratado y datos de antes y después | **diferencias en diferencias** (DiD) | tendencias paralelas: sin el tratamiento, los dos grupos habrían evolucionado igual | event study con coeficientes previos cerca de cero (no rechazar no prueba nada si la prueba tiene poca potencia); placebo con una fecha falsa; sensibilidad a desvíos de la tendencia |
| Por un umbral en una variable continua (puntaje ≥ 600, consumo > X) | **regresión discontinua** (RDD) | nada más salta en el umbral, y nadie manipula su posición | densidad continua en el umbral, covariables sin salto, sensibilidad al ancho de banda, umbral placebo |
| Hay algo que mueve el tratamiento y que afecta al resultado solo a través de él | **variables instrumentales** (IV) | relevancia (mueve el tratamiento), independencia (el instrumento es como asignado al azar respecto de los resultados), exclusión (no hay otro camino) y, para leerlo como LATE, monotonicidad (nadie hace lo contrario de lo que empuja el instrumento) | F de la primera etapa (mejor la F efectiva); balance de covariables según el instrumento; independencia, exclusión y monotonicidad se argumentan, no se prueban |
| Según características que se observan (selección en observables) | **ajuste**: regresión, emparejamiento, IPW, **AIPW** (doblemente robusto) | no hay confusores sin medir y hay **solapamiento** (cada tipo de caso puede caer en ambos grupos) | balance (SMD < 0,1 después de ponderar), distribución del propensity, E-value |
| Una sola unidad tratada (una faena, una región) y varias que no | **control sintético** | una combinación de controles reproduce bien el pasado de la tratada | ajuste previo (RMSPE), placebos en las unidades de control |
| Una serie con una intervención en una fecha conocida, sin grupo de control | **serie de tiempo interrumpida** (ITS) | sin la intervención, la tendencia y la estacionalidad habrían seguido igual | quiebres placebo; es el diseño más débil de esta tabla |
| Nada de lo anterior | descriptivo + sensibilidad | — | no se afirma causa |

Detalles por diseño:

- **DiD**: errores agrupados por unidad. Que el event study no rechace las tendencias previas no las prueba (Roth, 2022): se reportan los coeficientes previos con su IC y una sensibilidad a desvíos de la tendencia paralela (HonestDiD, Rambachan y Roth, 2023), y el análisis no se condiciona a pasar la prueba. Si las unidades entran al tratamiento en fechas distintas (adopción escalonada) y el efecto cambia con el tiempo, la regresión con efectos fijos de unidad y período (TWFE) mezcla comparaciones malas: se usa Callaway-Sant'Anna o Sun-Abraham (paquetes `differences` o `csdid`).
- **RDD**: regresión lineal local a cada lado con kernel triangular. El ancho de banda se reporta con su sensibilidad (h/2, h, 2h). Para el análisis final, `rdrobust` da el ancho óptimo y el IC con corrección de sesgo, y `rddensity` la prueba de manipulación. El IC de la lineal local con errores robustos sirve para mirar, pero no corrige el sesgo de aproximación: el número final sale de `rdrobust`. El efecto vale **en el umbral**, no para todos.
- **IV**: con un instrumento débil, el estimador queda sesgado hacia el de MCO y su IC no es confiable: la F de la primera etapa (con errores robustos, la F efectiva de Montiel Olea y Pflueger, 2013) tiene que ser holgadamente mayor que 10, que es una regla histórica y no un umbral seguro; si no, se usan intervalos robustos a instrumentos débiles (Anderson-Rubin). Con tratamiento binario y monotonicidad, se estima el efecto en quienes el instrumento hace cambiar (LATE, los "cumplidores"), no en todos.
- **Ajuste por observables**: con modelos flexibles (boosting) para el propensity o el resultado se usa ajuste cruzado (DoubleML o EconML) para no sobreajustar. Los casos sin solapamiento se recortan y se dice a qué población aplica el efecto. Recortar el propensity (por ejemplo a [0,01; 0,99]) estabiliza los pesos, pero cambia la población y rompe la doble robustez estricta: se muestra el rango sin recortar y cuántos casos afecta.
- **Control sintético**: pesos no negativos que suman 1, ajustados solo con el período previo; la inferencia sale de los placebos (cuántas unidades de control muestran un "efecto" tan grande como el real). Es un p de permutación: vale si las unidades son intercambiables y no hay anticipación ni contagio entre la tratada y los controles, y con J controles no puede bajar de 1/(J+1).
- **ITS**: tendencia, nivel y cambio de pendiente, con la estacionalidad modelada y la autocorrelación modelada (regresión con errores ARIMA). Con series cortas, los errores HAC quedan optimistas: en una simulación de 60 meses, su IC 95 % cubrió el efecto real el 69 % de las veces, y el de errores AR(1) el 92 %. Cualquier otra cosa que haya cambiado en esa fecha invalida el diseño.

## 5. Refutar antes de creer

- **Placebo de tratamiento**: una fecha o un umbral falsos tienen que dar efecto ≈ 0.
- **Control negativo**: un resultado que el tratamiento no puede mover (las ventas de antes del programa, un indicador de otra área) también tiene que dar ≈ 0.
- **Tendencias previas** (DiD), **balance** (ajuste), **densidad** en el umbral (RDD), **primera etapa** (IV) y **ajuste previo** (control sintético).
- **Sensibilidad a confusores no medidos**: el **E-value** dice qué tan fuerte, en razón de riesgo, tendría que ser un confusor no medido, asociado con el tratamiento y con el resultado, para anular el efecto. No hay umbrales universales: se compara con la fuerza de los confusores medidos más importantes. Si el confusor medido más fuerte tiene una razón de riesgo de 1,5 y el E-value es 1,3, el resultado es frágil.
- **Especificaciones**: el efecto no debería depender de una elección arbitraria (ventana, controles razonables, forma funcional).

## 6. Efectos heterogéneos y uplift: ¿a quién le aplico X?

- Para decidir a quién dirigir una campaña o intervención importa el **efecto** del tratamiento en cada caso (uplift), no el **riesgo**. Los clientes de mayor riesgo de churn pueden ser casos perdidos a los que la oferta no les cambia nada; a otros, la oferta incluso les recuerda irse.
- Se estima con datos de un **experimento** (o con un diseño causal creíble), con meta-learners: T-learner (un modelo por grupo), S-learner o X-learner (mejor con grupos desbalanceados); `EconML` y `CausalML` los traen.
- Se valida con curvas de uplift o Qini en datos experimentales reservados, comparando contra dirigir por riesgo o al azar.

## 7. Procesos industriales con lazos de control

En una planta, muchas variables "de entrada" las mueve un operador o un controlador **en respuesta** al estado del proceso (más reactivo cuando la ley baja, menos velocidad cuando sube la temperatura). Esto confunde por diseño: la correlación cruda entre la variable manipulada y el resultado puede salir nula o con el signo invertido aunque el efecto real sea fuerte. Por eso:

- Se modela por qué se movió la variable (la regla del operador o la lógica del controlador) y se ajusta por lo que la gatilla.
- Mejor todavía: variaciones planificadas (EVOP) o pruebas por turnos asignados al azar.
- Si la dosis se decide turno a turno y lo que la gatilla depende de la dosis anterior (confusión que cambia en el tiempo y que el propio tratamiento afecta), ajustar en una regresión no basta para estimar el efecto de una estrategia de dosificación: hace falta la fórmula g o modelos estructurales marginales con IPW, o mejor, variaciones planificadas.
- Las series de planta están autocorrelacionadas: se agrega por turno o por día y se modela la autocorrelación. HAC sirve con series largas, no con pocas decenas de puntos.

El recetario trae el caso del reactivo: la regresión cruda da un efecto negativo y la ajustada recupera el positivo.

## 8. Cómo se redacta

> Bajo el supuesto de tendencias paralelas (diagnóstico: los coeficientes previos del event study son pequeños y compatibles con cero, prueba conjunta p = 0,64, y el efecto se mantiene positivo ante desvíos moderados de la tendencia), el proceso nuevo aumentó el rendimiento en 1,5 t/h (IC 95 %: 1,1 a 1,9) en las plantas que lo adoptaron, durante los 12 meses siguientes.

Siempre: el diseño, el supuesto del que depende la conclusión, la evidencia sobre ese supuesto, la población y el período a los que aplica el efecto, y lo que la podría invalidar.

## Trampas

- "Controlar por todo lo disponible": se controlan mediadores, colisionadores o variables posteriores y se crea sesgo.
- Leer la importancia de variables de un modelo predictivo como efecto.
- DiD sin mirar las tendencias previas, leer "no se rechazó" como "se cumplen", o TWFE con adopción escalonada.
- RDD extrapolado lejos del umbral, o con un polinomio de grado alto sobre todos los datos.
- IV con un instrumento débil o con una exclusión que no resiste una conversación con alguien del área.
- Ajuste por observables sin revisar el solapamiento.
- Dirigir una intervención por riesgo cuando la pregunta es por efecto.
- En planta: correlacionar una variable manipulada con el resultado sin modelar el lazo de control.
