# Recetario de diseños causales

Cada bloque simula datos con un efecto real conocido y comprueba que el diseño lo recupera (el `assert` final), y en la mayoría muestra además cuánto se equivoca el análisis ingenuo. En un análisis real se reemplazan las líneas de "datos de ejemplo" y, antes, se corre el pipeline sobre datos simulados con la forma de los reales.

Probado el 2026-11-03 con numpy 2.4, pandas 2.3, scipy 1.17, statsmodels 0.15, linearmodels 7.1 y scikit-learn 1.9, sin usos de API obsoleta.

## Índice

1. Diferencias en diferencias y event study
2. Regresión discontinua: lineal local, ancho de banda, manipulación y placebo
3. Variables instrumentales
4. Ajuste por observables: IPW y AIPW con balance y solapamiento
5. Control sintético con placebos
6. Serie de tiempo interrumpida
7. E-value
8. Uplift: dirigir por efecto y no por riesgo
9. Lazo de control en planta: el confusor que invierte el signo

## 1. Diferencias en diferencias y event study

```python
import numpy as np
import pandas as pd
import statsmodels.formula.api as smf

rng = np.random.default_rng(41)
unidades, periodos, inicio = 40, 24, 12   # datos de ejemplo: 40 plantas, 24 meses; 20 adoptan un proceso en el mes 12
df = pd.DataFrame([(u, t) for u in range(unidades) for t in range(periodos)], columns=["planta", "mes"])
df["tratada"] = (df["planta"] < 20).astype(int)
df["D"] = df["tratada"] * (df["mes"] >= inicio)
df["y"] = (80 + rng.normal(0, 3, unidades)[df["planta"]] + 2 * df["tratada"]     # niveles distintos: DiD los quita
           + 0.1 * df["mes"] + rng.normal(0, 1, periodos)[df["mes"]]             # shocks comunes
           + 1.5 * df["D"] + rng.normal(0, 1, len(df)))                          # efecto real 1.5

ingenuo = df.loc[df["mes"] >= inicio].groupby("tratada")["y"].mean().diff().iloc[-1]
twfe = smf.ols("y ~ D + C(planta) + C(mes)", df).fit(cov_type="cluster", cov_kwds={"groups": df["planta"]})
lo, hi = twfe.conf_int().loc["D"]
print(f"comparación ingenua después del cambio: {ingenuo:.2f}; DiD: {twfe.params['D']:.2f} (IC 95 %: {lo:.2f} a {hi:.2f})")

# Event study: un coeficiente por mes relativo al inicio (referencia: el mes -1); los previos deben ser ≈ 0
df["rel"] = np.where(df["tratada"] == 1, df["mes"] - inicio, -1)
es = smf.ols("y ~ C(rel, Treatment(reference=-1)) + C(planta) + C(mes)", df).fit(
    cov_type="cluster", cov_kwds={"groups": df["planta"]})
previos = [n for n in es.params.index if n.startswith("C(rel") and int(n.split("[T.")[1].rstrip("]")) < -1]
R = np.zeros((len(previos), len(es.params)))
for i, n in enumerate(previos):
    R[i, es.params.index.get_loc(n)] = 1
prueba = es.wald_test(R, scalar=True)
print(f"tendencias previas: prueba conjunta de {len(previos)} coeficientes, p = {float(prueba.pvalue):.3f}")
# en la simulación se exige p > 0.05 como chequeo del pipeline; con datos reales no se condiciona el análisis a pasarla
assert lo < 1.5 < hi and float(prueba.pvalue) > 0.05
```

## 2. Regresión discontinua: lineal local, ancho de banda, manipulación y placebo

```python
import numpy as np
import pandas as pd
import statsmodels.formula.api as smf
from scipy import stats

rng = np.random.default_rng(42)
n, corte = 4000, 600   # datos de ejemplo: un beneficio se entrega con puntaje >= 600
puntaje = rng.uniform(400, 800, n)
D = (puntaje >= corte).astype(int)
y = 20 + 0.03 * (puntaje - corte) + 0.00005 * (puntaje - corte) ** 2 + 3.0 * D + rng.normal(0, 4, n)   # efecto real 3

def rdd_local(x, y, d, c, h):
    """Lineal local a cada lado del corte, con kernel triangular de ancho h.
    El IC (HC1) es ilustrativo: no corrige el sesgo de aproximación; el número final sale de rdrobust."""
    xc = x - c
    w = np.clip(1 - np.abs(xc) / h, 0, None)
    m = w > 0
    datos = pd.DataFrame({"y": y[m], "xc": xc[m], "D": d[m]})
    fit = smf.wls("y ~ D + xc + D:xc", datos, weights=w[m]).fit(cov_type="HC1")
    return fit.params["D"], *fit.conf_int().loc["D"], int(m.sum())

for h in (25, 50, 100):   # sensibilidad al ancho de banda
    est, lo, hi, nh = rdd_local(puntaje, y, D, corte, h)
    print(f"h = {h:3d}: efecto {est:.2f} (IC 95 %: {lo:.2f} a {hi:.2f}), n = {nh}")

# Manipulación, diagnóstico crudo: con densidad continua y una franja angosta, los conteos a cada lado son parecidos
# (si la densidad tiene pendiente, no son iguales aunque no haya manipulación); la prueba formal es rddensity
izq = int(((puntaje >= corte - 10) & (puntaje < corte)).sum())
der = int(((puntaje >= corte) & (puntaje < corte + 10)).sum())
print(f"casos 10 puntos bajo/sobre el corte: {izq}/{der}, p binomial = {stats.binomtest(der, izq + der).pvalue:.3f}")

# Placebo: un corte falso en 550, usando solo datos sin tratamiento
abajo = puntaje < corte
est_p, lo_p, hi_p, _ = rdd_local(puntaje[abajo], y[abajo], (puntaje[abajo] >= 550).astype(int), 550, 50)
print(f"corte placebo en 550: {est_p:.2f} (IC 95 %: {lo_p:.2f} a {hi_p:.2f})")
est, lo, hi, _ = rdd_local(puntaje, y, D, corte, 50)
assert lo < 3 < hi and lo_p < 0 < hi_p
```

## 3. Variables instrumentales

```python
import numpy as np
import pandas as pd
import statsmodels.formula.api as smf
from linearmodels.iv import IV2SLS

rng = np.random.default_rng(43)
n = 5000   # datos de ejemplo: la motivación (no medida) mueve la capacitación y la productividad
motivacion = rng.normal(size=n)
cercania = rng.integers(0, 2, n)   # instrumento: vivir cerca del centro de capacitación
capacitacion = (0.8 * cercania + 0.8 * motivacion + rng.normal(size=n) > 0.5).astype(int)
productividad = 50 + 2.0 * capacitacion + 3.0 * motivacion + rng.normal(0, 2, n)   # efecto real 2
df = pd.DataFrame({"productividad": productividad, "capacitacion": capacitacion, "cercania": cercania})

mco = smf.ols("productividad ~ capacitacion", df).fit()
iv = IV2SLS.from_formula("productividad ~ 1 + [capacitacion ~ cercania]", df).fit(cov_type="robust")
f_primera = iv.first_stage.diagnostics["f.stat"].iloc[0]
lo, hi = iv.conf_int().loc["capacitacion"]
print(f"MCO (sesgado por la motivación): {mco.params['capacitacion']:.2f}")
print(f"IV: {iv.params['capacitacion']:.2f} (IC 95 %: {lo:.2f} a {hi:.2f}); F de la primera etapa = {f_primera:.0f}")
assert lo < 2 < hi and f_primera > 10
```

## 4. Ajuste por observables: IPW y AIPW con balance y solapamiento

```python
import numpy as np
import pandas as pd
from sklearn.linear_model import LinearRegression, LogisticRegression

rng = np.random.default_rng(44)
n = 6000   # datos de ejemplo: la campaña se envió más a clientes antiguos y con más uso, que ya gastaban más
X = pd.DataFrame({"antiguedad": rng.gamma(3, 12, n), "uso": rng.gamma(2, 10, n), "reclamos": rng.poisson(1, n)})
logit = -1 + 0.03 * (X["antiguedad"] - 36) + 0.05 * (X["uso"] - 20) - 0.3 * X["reclamos"]
T = (rng.random(n) < 1 / (1 + np.exp(-logit))).astype(int).to_numpy()
gasto = (100 + 0.8 * X["antiguedad"] + 1.2 * X["uso"] - 5 * X["reclamos"] + 8 * T
         + rng.normal(0, 10, n)).to_numpy()   # ATE real 8

def smd(x, t, w=None):
    """Diferencia estandarizada de medias (balance); w = pesos."""
    w = np.ones(len(x)) if w is None else w
    m1, m0 = np.average(x[t == 1], weights=w[t == 1]), np.average(x[t == 0], weights=w[t == 0])
    return (m1 - m0) / np.sqrt((x[t == 1].var() + x[t == 0].var()) / 2)

def aipw(X, T, Y):
    # recortar a [0.01, 0.99] estabiliza los pesos pero cambia la población: mostrar antes el rango sin recortar
    e = LogisticRegression(max_iter=1000).fit(X, T).predict_proba(X)[:, 1].clip(0.01, 0.99)
    mu1 = LinearRegression().fit(X[T == 1], Y[T == 1]).predict(X)
    mu0 = LinearRegression().fit(X[T == 0], Y[T == 0]).predict(X)
    ate = np.mean(mu1 - mu0 + T * (Y - mu1) / e - (1 - T) * (Y - mu0) / (1 - e))
    return ate, e

ingenuo = gasto[T == 1].mean() - gasto[T == 0].mean()
ate, e = aipw(X, T, gasto)
w = np.where(T == 1, 1 / e, 1 / (1 - e))
ipw = np.average(gasto[T == 1], weights=w[T == 1]) - np.average(gasto[T == 0], weights=w[T == 0])
print(f"propensity: tratados {e[T == 1].min():.2f} a {e[T == 1].max():.2f}; "
      f"controles {e[T == 0].min():.2f} a {e[T == 0].max():.2f} (solapamiento)")
for c in X:
    print(f"  SMD {c:10s} antes {smd(X[c].to_numpy(), T):+.2f}  después de ponderar {smd(X[c].to_numpy(), T, w):+.2f}")

boot = []
for _ in range(300):   # IC por bootstrap: se reajustan los dos modelos en cada remuestreo
    i = rng.integers(0, n, n)
    boot.append(aipw(X.iloc[i].reset_index(drop=True), T[i], gasto[i])[0])
lo, hi = np.percentile(boot, [2.5, 97.5])
print(f"ingenuo {ingenuo:.2f}; IPW {ipw:.2f}; AIPW {ate:.2f} (IC 95 %: {lo:.2f} a {hi:.2f})")
assert lo < 8 < hi and abs(ingenuo - 8) > 5
```

## 5. Control sintético con placebos

```python
import numpy as np
from scipy.optimize import minimize

rng = np.random.default_rng(45)
T0, T, J = 36, 48, 15   # datos de ejemplo: 36 meses antes y 12 después; la faena 0 adopta un sistema; 15 de control
factores = rng.normal(size=(T, 2)).cumsum(axis=0)              # tendencias comunes no observadas
cargas = rng.uniform(0.5, 1.5, (J + 1, 2))
Y = 100 + factores @ cargas.T + rng.normal(0, 0.5, (T, J + 1))
Y[T0:, 0] += 4.0                                               # efecto real 4

def sintetico(y, controles):
    """Pesos no negativos que suman 1, ajustados solo con el período previo."""
    k = controles.shape[1]
    res = minimize(lambda w: np.mean((y[:T0] - controles[:T0] @ w) ** 2), np.full(k, 1 / k), method="SLSQP",
                   bounds=[(0, 1)] * k, constraints={"type": "eq", "fun": lambda w: w.sum() - 1})
    brecha = y - controles @ res.x
    rmspe_pre, rmspe_post = np.sqrt(np.mean(brecha[:T0] ** 2)), np.sqrt(np.mean(brecha[T0:] ** 2))
    return brecha, rmspe_post / rmspe_pre

brecha, razon = sintetico(Y[:, 0], Y[:, 1:])
efecto = brecha[T0:].mean()
# Placebos: cada control como si fuera el tratado, con los otros controles (sin la tratada)
razones = [sintetico(Y[:, j], np.delete(Y[:, 1:], j - 1, axis=1))[1] for j in range(1, J + 1)]
# p de permutación por rango: supone unidades intercambiables, sin anticipación ni contagio entre tratada y controles
p = (1 + sum(r >= razon for r in razones)) / (1 + J)
print(f"efecto medio post {efecto:.2f}; ajuste previo RMSPE {np.sqrt(np.mean(brecha[:T0] ** 2)):.2f}; "
      f"p por placebos = {p:.3f} (con 15 controles, el mínimo posible es {1 / (J + 1):.3f})")
assert abs(efecto - 4) < 1.5
```

## 6. Serie de tiempo interrumpida

Con series cortas, los errores HAC quedan demasiado optimistas. En 300 simulaciones de este mismo caso (60 meses, ruido AR(1) con φ = 0,6), el IC 95 % con HAC cubrió el salto real solo el 69 % de las veces; modelando la autocorrelación con errores ARIMA(1,0,0), el 92 %.

```python
import numpy as np
import pandas as pd
from statsmodels.tsa.arima.model import ARIMA

rng = np.random.default_rng(46)
meses, inicio = 60, 36   # datos de ejemplo: consumo de agua mensual; una medida de ahorro desde el mes 36
t = np.arange(meses)
ruido = np.zeros(meses)
for i in range(1, meses):   # ruido autocorrelacionado AR(1)
    ruido[i] = 0.6 * ruido[i - 1] + rng.normal(0, 3)
y = pd.Series(200 + 0.5 * t + 10 * np.sin(2 * np.pi * t / 12) - 8 * (t >= inicio) + ruido)   # salto real −8

exog = pd.DataFrame({"t": t, "post": (t >= inicio).astype(float), "t_post": np.where(t >= inicio, t - inicio, 0.0)})
exog = exog.join(pd.get_dummies(t % 12, prefix="mes", drop_first=True, dtype=float))   # estacionalidad
its = ARIMA(y, exog=exog, order=(1, 0, 0), trend="c").fit()   # regresión con errores AR(1)
lo, hi = its.conf_int().loc["post"]
print(f"cambio de nivel {its.params['post']:.2f} (IC 95 %: {lo:.2f} a {hi:.2f}); "
      f"cambio de pendiente {its.params['t_post']:.2f} por mes; AR(1) estimado {its.params['ar.L1']:.2f}")
assert lo < -8 < hi
```

Con una sola realización de 60 meses, el estimado puede alejarse bastante del salto real: se lee el intervalo. Si existe una serie comparable no intervenida, se usa como control (DiD o control sintético), que es mucho más fuerte que la serie sola.

## 7. E-value

Qué tan fuerte (como razón de riesgo con el tratamiento y con el resultado) tendría que ser un confusor no medido para llevar el efecto a nulo (VanderWeele y Ding, 2017).

```python
import numpy as np

def e_value(rr, lo=None, hi=None):
    """E-value del punto y del límite del IC más cercano a 1 (si el IC cruza 1, ese E-value es 1)."""
    def ev(r):
        r = 1 / r if r < 1 else r
        return r + np.sqrt(r * (r - 1))
    if lo is None or hi is None:
        return ev(rr), None
    return ev(rr), 1.0 if lo <= 1 <= hi else ev(lo if rr > 1 else hi)

punto, limite = e_value(1.8, 1.3, 2.5)   # datos de ejemplo: RR 1,8 (IC 95 %: 1,3 a 2,5)
print(f"E-value del punto {punto:.2f}; del límite del IC {limite:.2f}")
# Para una diferencia de medias estandarizada d, aproximar RR ≈ exp(0.91 · d) antes de calcularlo
d = 0.4
print(f"d = {d}: RR aproximado {np.exp(0.91 * d):.2f}, E-value {e_value(np.exp(0.91 * d))[0]:.2f}")
assert abs(punto - 3.0) < 1e-9
```

## 8. Uplift: dirigir por efecto y no por riesgo

```python
import numpy as np
from sklearn.ensemble import HistGradientBoostingClassifier
from sklearn.model_selection import train_test_split

rng = np.random.default_rng(47)
n = 20000   # datos de ejemplo: experimento, la mitad recibió al azar una oferta de retención
X = rng.normal(size=(n, 4))
riesgo = 1 / (1 + np.exp(-(-1 + 1.5 * X[:, 0])))                # probabilidad de irse sin oferta
efecto = -0.15 * np.exp(-X[:, 0] ** 2) * (X[:, 1] > 0)           # solo sirve a riesgo medio y con X1 > 0
T = rng.integers(0, 2, n)
churn = (rng.random(n) < np.clip(riesgo + efecto * T, 0, 1)).astype(int)
X_tr, X_te, T_tr, T_te, y_tr, y_te, ef_tr, ef_te = train_test_split(X, T, churn, efecto, test_size=0.5,
                                                                    random_state=0)

# T-learner: un modelo por grupo; uplift = cambio en la probabilidad de irse si recibe la oferta
m1 = HistGradientBoostingClassifier(max_depth=3, random_state=0).fit(X_tr[T_tr == 1], y_tr[T_tr == 1])
m0 = HistGradientBoostingClassifier(max_depth=3, random_state=0).fit(X_tr[T_tr == 0], y_tr[T_tr == 0])
uplift = m1.predict_proba(X_te)[:, 1] - m0.predict_proba(X_te)[:, 1]
riesgo_pred = m0.predict_proba(X_te)[:, 1]

k = int(0.2 * len(X_te))   # presupuesto: ofrecer al 20 %
for nombre, orden in (("por riesgo", np.argsort(-riesgo_pred)), ("por uplift", np.argsort(uplift)),
                      ("al azar", rng.permutation(len(X_te)))):
    sel = orden[:k]
    salvados = -ef_te[sel].sum()   # verdad simulada: churns evitados
    t, c = sel[T_te[sel] == 1], sel[T_te[sel] == 0]   # estimación experimental dentro del grupo elegido
    print(f"{nombre:10s}: churns evitados (verdad simulada) {salvados:.0f}; "
          f"efecto experimental en el grupo {100 * (y_te[t].mean() - y_te[c].mean()):+.1f} pp")
# el efecto experimental dentro de cada grupo es ruidoso (±2 pp con ~1.000 casos por brazo); la verdad simulada no
sel_r, sel_u = np.argsort(-riesgo_pred)[:k], np.argsort(uplift)[:k]
assert -ef_te[sel_u].sum() > 1.5 * -ef_te[sel_r].sum()
```

## 9. Lazo de control en planta: el confusor que invierte el signo

```python
import numpy as np
import pandas as pd
import statsmodels.formula.api as smf

rng = np.random.default_rng(48)
n = 3000   # datos de ejemplo: turnos de flotación; el operador sube el reactivo cuando la ley viene baja
ley = rng.normal(0.9, 0.15, n)
reactivo = 40 - 30 * (ley - 0.9) + rng.normal(0, 2, n)
recuperacion = 70 + 25 * (ley - 0.9) + 0.3 * (reactivo - 40) + rng.normal(0, 1, n)   # efecto real +0.3 por g/t
df = pd.DataFrame({"ley": ley, "reactivo": reactivo, "recuperacion": recuperacion})

crudo = smf.ols("recuperacion ~ reactivo", df).fit()
ajustado = smf.ols("recuperacion ~ reactivo + ley", df).fit(cov_type="HC3")
lo, hi = ajustado.conf_int().loc["reactivo"]
print(f"sin ajustar: {crudo.params['reactivo']:+.3f} por g/t (¡signo invertido!); "
      f"ajustando por la ley: {ajustado.params['reactivo']:+.3f} (IC 95 %: {lo:.3f} a {hi:.3f})")
assert crudo.params["reactivo"] < 0 and lo < 0.3 < hi
```
