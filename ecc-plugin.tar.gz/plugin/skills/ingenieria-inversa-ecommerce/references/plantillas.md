# Plantillas

Cortas a propósito: cada campo pide evidencia (captura, URL o salida de un fragmento). Lo que no aplica se marca `N/A`; lo no comprobado, `SUPUESTO`.

## PLATAFORMA.md

```markdown
# Plataforma de <referencia>
- URL: · Fecha:
- Plataforma (y tema, si hay):
- Front:
- API de vitrina pública: sí/no — rutas que respondieron:
- Pagos que se ven:
- Despacho que se ve:
- Analítica y píxeles:
- Reseñas / chat / búsqueda / newsletter:
- Animación y carruseles:
- Dominios de terceros:
- Qué implica para la tienda propia:
```

## MAPA.md

```markdown
# Mapa de <referencia>
Sitemap: <n> URLs — productos <n>, categorías <n>, páginas <n>

| Tipo de página | URL de ejemplo | Secciones en orden | Fijo / sticky | Interacción por sección | Capturas |
|---|---|---|---|---|---|
| Home | | | | | home-1440.png, home-390.png |
| Categoría | | | | | |
| Ficha | | | | | |
| Búsqueda | | | | | |
| Carrito | | | | | |
| Checkout | | | | | |
| Cuenta | | | | | |
| Contenido | | | | | |
| 404 | | | | | |

Menú: <estructura del menú y del mega menú>
Footer: <columnas y enlaces>
```

## FLUJOS.md

```markdown
# Flujos de <referencia>

## <Flujo, ej.: de la ficha al checkout>
| # | Acción | Resultado visible | Red (si aplica) | Captura |
|---|---|---|---|---|
| 1 | Clic en talla M | precio igual, foto cambia, URL ?variant=… | — | ficha-390-talla.png |
| 2 | Clic en "Agregar" | drawer desde la derecha, contador 1 | POST /cart/add.js → 200 | ficha-390-drawer.png |

Errores y casos borde: <sin stock, cupón inválido, campo obligatorio vacío…>
Dónde se paró: <paso antes del pago>
```

## components/<nombre>.spec.md

Adaptada de la ficha de `clone-website` (MIT).

```markdown
# <Componente>
- Archivo destino: `src/components/<Componente>.tsx`
- Captura: `docs/referencias/<captura>.png`
- Interacción: estática | clic | scroll | hover | tiempo

## Estructura
<qué contiene a qué>

## Estilos medidos (getComputedStyle)
### Contenedor
- display: … · padding: … · maxWidth: …
### <Hijo>
- fontSize: … · lineHeight: … · color: …

## Estados
### <Estado, ej.: header con scroll>
- Disparador: <scroll > 80px | IntersectionObserver | clic en … | hover>
- Antes: …
- Después: …
- Transición: <propiedad, duración, curva>

## Contenido por estado (pestañas, variantes)

## Por ancho
- 1440: …
- 768: …
- 390: …
- Cambia en ~<n>px

## Qué se cambia por lo propio
- Colores de marca → tokens de Benja · Fotos → TODO-CONTENIDO · Textos → propios
```

## DISENO.md

```markdown
# Diseño
## Estructura (se mantiene)
- Ancho máximo: · Grilla y columnas: · Espaciado base y escala:
- Escala tipográfica: display / h1 / h2 / h3 / cuerpo / chico (tamaño, peso, interlineado)
- Radios: · Sombras: · Densidad: compacta | cómoda | amplia
- Movimiento: duraciones, curvas, cómo entran las cosas
## Marca de la referencia (solo como dato, no se usa)
- Colores: · Tipografías y su licencia: · Tono de los textos:
## Marca propia (de Benja)
- Colores: · Tipografías: · Logo: · Fotos: · Tono:
## Componentes
| Componente | Ficha | Estados | Prioridad |
|---|---|---|---|
```

## DATOS.md

```markdown
# Datos
Fuente: API de vitrina <ruta> | JSON-LD de las fichas | HTML · Muestra: <n> productos

## Modelo
- Producto: campos …
- Variante y opciones: …
- Precio normal / oferta / cuotas: …
- Inventario: …
- Imágenes: cantidad, tamaños, formato
- Categorías / colecciones / etiquetas / atributos: …

## URLs y SEO
- Producto: /products/<slug> · Categoría: … · Filtros: ?…
- JSON-LD presente: Product, Offer, BreadcrumbList, Organization…
- Títulos y descripciones meta: <patrón>
```

## PLAN.md

```markdown
# Plan de <tienda propia>
Precios y condiciones verificados el: <fecha>

## Opciones de base
| Opción | Costo mensual y por venta | A favor | En contra |
|---|---|---|---|

Decisión: <opción> — por qué (ADR si es difícil de revertir)

## Qué se mantiene, qué se mejora, qué es propio
- Se mantiene de la referencia:
- Se mejora:
- Propio (marca, catálogo, textos):

## Orden de construcción
| # | Página o componente | Ficha | Listo cuando |
|---|---|---|---|

## Fuera de alcance
```

## docs/NOTAS.md

Va dentro de `docs/` para que la auditoría de restos lo excluya: es el único archivo fuera de la investigación que nombra a la referencia.

```markdown
# <Tienda propia>, inspirada en <referencia>
- Corre en: <URL o comando>
- Base elegida: <plataforma> — por qué
- Referencia estudiada el: <fecha>

## Referencia contra tienda propia
| Tipo de página | Referencia | Tienda propia | Diferencias y decisiones | Evidencia |
|---|---|---|---|---|

## Puntaje (0 a 5, solo con evidencia)
| Dimensión | Puntaje | Evidencia |
|---|---|---|
| Estructura (páginas, secciones, navegación) | | |
| Flujos de compra completos | | |
| Visual (tipografía, espaciado, proporciones) | | |
| Celular y tablet | | |
| Datos y SEO | | |
| Funciona (carrito, checkout y pago de prueba) | | |
| Marca propia (auditoría de restos en cero) | | |
| Riesgos legales resueltos (licencias, textos legales propios) | | |

## Verificaciones corridas
- build: · tipos: · lint: · tests: · capturas 390×844 claro/oscuro: · consola:

## Brechas y lo que no se verificó
```
