# Base de la tienda propia

Carrito, checkout, pagos, inventario, impuestos y panel de administración son lo más caro y lo más riesgoso de programar. Se parte de una plataforma que ya los trae, salvo que el negocio no quepa en ninguna.

Precios, comisiones y condiciones cambian: verificarlos en la web oficial el día que se decide y anotar la fecha en PLAN.md.

## Opciones

| Base | Qué trae | Conviene cuando | Ojo con |
|---|---|---|---|
| **Shopify** (tema Liquid, o Hydrogen si es headless) | Checkout, pagos, inventario, panel y miles de apps | Hay que vender pronto y con poco desarrollo | Plan mensual. Sin Shopify Payments, las pasarelas externas suman una comisión extra de Shopify. El checkout se personaliza poco |
| **WooCommerce** (WordPress) | Código abierto, plugins de pago locales, blog | Control total y costo bajo, con hosting propio | Mantenimiento, actualizaciones y seguridad de los plugins quedan de tu lado |
| **Jumpseller** | Plataforma chilena con pagos y despachos locales integrados | Tienda chilena sin desarrollo a medida | Menos flexibilidad de diseño que un front propio |
| **Medusa** (código abierto, Node/TypeScript) + front en Next.js | Backend de comercio completo y un front libre en el stack de Benja | Diseño a medida, lógica propia o varios canales | Más desarrollo. Las pasarelas chilenas pueden pedir un plugin propio. Hay que alojar servidor y base de datos |
| **Your Next Store** (front Next.js con MIT; visto en su repo el 27-10-2026) | Front de tienda listo para modificar, con pagos por Stripe | Front moderno sin escribirlo desde cero | El backend es su plataforma hospedada (`YNS_API_KEY` de yns.store): el catálogo y los pedidos no quedan en tu servidor |
| **A medida** | Todo propio | Modelo que no cabe en ninguna (marketplace con varios vendedores, suscripciones raras) | El costo más alto: pagos, seguridad, impuestos y panel son trabajo tuyo |

Si la referencia está en Shopify o en otra plataforma con temas, se puede partir de un tema parecido de la tienda oficial de temas y adaptarlo, en vez de reconstruir el diseño desde cero.

## Lista para Chile (revisar en el plan)

- **Pagos**: Webpay Plus (Transbank), Mercado Pago, Flow. Ver cuáles tiene la base elegida, su comisión y el plazo en que liberan la plata.
- **Despacho**: Chilexpress, Starken, Blue Express o despacho propio. Cálculo por comuna y retiro en tienda.
- **Documentos tributarios**: boleta y factura electrónica del SII, con un proveedor que se conecte a la base.
- **Consumidor** (Ley 19.496, modificada por la Ley 21.398): derecho a retracto en compras a distancia y garantía legal, cada uno con sus condiciones y excepciones; precios con impuestos incluidos; términos y política de cambios propios, no copiados de la referencia. Revisar el texto vigente en bcn.cl o sernac.cl.
- **Datos personales**: política de privacidad propia. La Ley 21.719 entra en vigencia el 1 de diciembre de 2026; en 2026 se presentó un proyecto para postergarla a 2027: revisar su estado en camara.cl o bcn.cl.
- **Cookies y analítica**: qué se mide y con qué consentimiento.
