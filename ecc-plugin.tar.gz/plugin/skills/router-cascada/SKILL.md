---
name: router-cascada
description: "Router de ECC para Benja: en cada encargo elige la ruta más simple y barata que pase la revisión. Decide tres cosas: cómo se organiza (la sesión sola, un agente, varios en paralelo), qué modelo y effort hace cada parte (Haiku, Sonnet u Opus, low a max) y cómo se comprueba. Sube effort o modelo cuando algo falla, verifica toda salida de Haiku y aprende del registro de costo (/ecc:rendimiento). Úsala al empezar cualquier encargo de más de un paso, al planear una entrega y en cada paso del ciclo plan → test → implementar → revisar → verificar."
metadata:
  origin: ecc-benja
---

# Router de ECC: la ruta más simple y barata que pase la revisión

Regla de oro: **la forma más simple que resuelva el problema, y el modelo más chico que pase la revisión.** La calidad no se negocia: la revisión y la verificación del ciclo ECC son las mismas venga el trabajo de donde venga. Lo que se optimiza es cuánto cuesta llegar ahí.

La sesión principal (Opus) entiende, decide la ruta, reparte y verifica. El trabajo largo lo hacen agentes del nivel más barato que pueda hacerlo bien.

## 0. Elegir la ruta

Antes de un encargo no trivial (más de 3 o 4 pasos), la sesión toma tres decisiones y las escribe en una línea:

```
Ruta: <organización> · <modelo y effort> · <cómo se comprueba>
```

Ejemplos:
- `Ruta: la sesión sola · Opus (sesión) · el build pasa y la captura en 390 px se ve bien`
- `Ruta: un constructor para toda la cadena + code-reviewer · Sonnet medium · tests de la regla nueva en verde`
- `Ruta: 3 exploradores en paralelo → la sesión decide · Haiku low · ecc:verificador revisa las citas`

La línea no se escribe en preguntas, respuestas cortas ni cambios de una o dos líneas. Se vuelve a escribir si la estrategia cambia a mitad de camino. El hook de registro la usa para separar encargos y comparar lo declarado con lo que de verdad se ejecutó (sección 7).

### 0a. Organización: por defecto, la sesión sola y en secuencia

| Si… | Organización |
|---|---|
| Es una pregunta, una decisión con Benja, un cambio de pocos pasos, o cada paso depende de lo que se está conversando | **La sesión sola** |
| Es una secuencia de más de 3 o 4 pasos con un criterio comprobable (implementar y dejar los tests en verde, correr y arreglar) | **Un agente para toda la cadena.** Un solo brief, no un agente por paso |
| Hay que leer algo grande (logs, archivos largos, catálogos, muchos archivos) para sacar poco | **Un explorador (Haiku)** que devuelve solo lo relevante, con archivo:línea |
| Hay partes independientes que no se pisan (barridos de varias carpetas, revisiones de distintas dimensiones) | **Varios agentes en paralelo**, en un solo mensaje |

- Repartir solo vale cuando las partes son independientes o cuando saca una lectura grande del contexto de Opus. Una secuencia de pasos dependientes no se reparte: cada agente parte de cero y vuelve a leer lo que la sesión ya sabe.
- Según Anthropic, en su sistema de investigación un agente gasta ~4 veces los tokens de un chat y un sistema multiagente ~15 veces. No es un multiplicador fijo para ECC, pero marca la dirección: cada agente tiene que ganarse su lugar.

### 0b. Modelo: el más chico que pase la revisión

| Si… | Modelo |
|---|---|
| Se comprueba con un comando o con una cita (buscar, leer, cambios con instrucciones exactas, correr comandos, consultar docs) | **Haiku low** (nivel 1) |
| Hay que implementar o revisar, aunque haya decisiones habituales (nombres, estructura local, cómo testear) | **Sonnet medium** (nivel 2) |
| Hay ambigüedad real, un error sería caro o difícil de revertir (contratos, datos, seguridad, arquitectura), o algo ya falló | **Opus**: la sesión, `ecc:resolutor`, `ecc:planner` o `ecc:architect` (nivel 3) |

"Requiere criterio" no basta para subir a Opus: casi todo trabajo lo requiere y Sonnet lo resuelve. Lo que sube es la ambigüedad, el costo del error y la dificultad de comprobar el resultado.

### 0c. Control: cómo se comprueba

- **Siempre:** un criterio de aceptación comprobable y la revisión ECC que corresponda (paso 4 del método). No cambia con la ruta.
- **Uno hace, otro revisa con vueltas:** cuando el criterio es claro pero la primera versión suele no bastar (pantallas, textos para clientes). Máximo 2 o 3 vueltas.
- **Plan explícito:** 3 o más archivos, encargo ambiguo o cambio de arquitectura → `/ecc:plan` y esperar el OK de Benja.
- **Agente autónomo:** solo con el objetivo ya aclarado, un presupuesto y límites de alcance. Un objetivo abierto primero se aclara con Benja.

### 0d. Lo que cuesta cada turno

Medido sobre los transcripts de Benja del 12 al 26-10-2026, a precio API (con suscripción, es lo que consume los límites):

| Quién | Costo medio por turno |
|---|---|
| La sesión (Opus xhigh, relee ~200.000 tokens de contexto en cada turno) | ~US$0,10 |
| Un fork (copia todo el contexto de la sesión) | ~US$0,13 |
| `general-purpose` heredando Opus | ~US$0,07 |
| `ecc:constructor` (Sonnet) | ~US$0,04 |
| Haiku | < US$0,01 |

Consecuencias:
- Un encargo que en la sesión tomaría muchos turnos de herramientas suele salir más barato en un agente del nivel que corresponde, aun contando el brief.
- Nunca `general-purpose`, `claude` ni fork en Opus por descuido: en 14 días fueron el 24 % del gasto. Usar el agente de la cascada, o pasar `model: "sonnet"` o `"haiku"`. Si un subagente de verdad necesita Opus, el brief lleva una línea `Motivo Opus: <por qué>`.
- La sesión larga encarece cada turno. Un encargo grande va en su propia sesión, y se compacta en los cortes lógicos (skill `strategic-compact`).

## 1. Niveles

| Nivel | Modelo | Effort de partida | Para qué | Agentes |
|---|---|---|---|---|
| 0. Directo | la sesión | el de la sesión | Preguntas, cambios de pocos pasos, decisiones con el contexto ya cargado | ninguno |
| 1. Mecánico | Haiku | low | Buscar y leer, cambios con instrucciones exactas, correr comandos, consultar documentación | `ecc:explorador`, `ecc:mecanico`, `ecc:ejecutor`, `ecc:docs-lookup` |
| 2. Acotado | Sonnet | medium (high en seguridad y base de datos) | Implementar con criterio (una pantalla, una ruta, un bug ya diagnosticado), tests, revisiones, decisiones habituales | `ecc:constructor`, `ecc:tdd-guide`, `ecc:build-error-resolver`, `ecc:e2e-runner`, revisores (`ecc:code-reviewer`, `ecc:react-reviewer`, `ecc:typescript-reviewer`, `ecc:security-reviewer`, `ecc:database-reviewer`…), `ecc:verificador` |
| 3. Difícil | Opus | high | Ambigüedad real, contratos y datos, seguridad, arquitectura, bugs que se resisten | la sesión, `ecc:planner`, `ecc:architect`, `ecc:resolutor`, y Codex como segunda opinión |

Cada agente trae su effort de partida en el frontmatter. Para una llamada puntual, la sesión pasa `effort` en la herramienta Agent; esta skill es la instrucción explícita que lo autoriza. El effort de la sesión principal no lo cambia el router: lo elige Benja (`claude --effort <nivel>` al abrir, o `effortLevel` en settings.json).

## 1b. Effort

Elige el effort con la misma pregunta que el modelo: cuánto hay que pensar, no cuánto hay que escribir.

| Effort | Cuándo |
|---|---|
| low | Lo que se comprueba solo: buscar, copiar un patrón, correr comandos, revisar citas |
| medium | Implementar algo acotado, revisar código común, barridos donde hay que decidir qué es relevante |
| high | Datos, migraciones, seguridad, concurrencia, diseño; y todo lo que ya falló una vez por falta de profundidad |
| xhigh | Un bug que sobrevivió al resolutor en high, o una decisión de arquitectura con muchas salidas |
| max | Solo si xhigh no bastó y vale más acertar que el costo. Avisarle a Benja cuando se use |

- Subir un escalón de effort suele costar menos que cambiar de modelo, pero es una hipótesis: `/ecc:rendimiento` muestra si se cumple en cada tipo de tarea.
- No subas effort para compensar un brief malo. Si el agente no tenía la información, arregla el brief.
- Para algo simple que necesita el contexto de Opus, a veces conviene que lo haga la sesión antes que pasárselo a un modelo menor que tiene que releer todo.

## 2. Cascada

1. **Elegir la ruta** (sección 0) y clasificar cada parte en el nivel más barato que pueda hacerla bien, con su effort (sección 1b). Por defecto, el de partida del agente.
2. **Repartir.** Un brief autocontenido por agente (sección 4), con `effort` en la llamada solo si difiere del de partida. Las partes independientes van en paralelo, en un solo mensaje con varios agentes.
3. **Verificar toda salida del nivel 1 antes de usarla:**
   - si hay una prueba que la confirme (tests, tipos, lint, `git diff` limitado a los archivos del brief), se corre esa prueba;
   - si no la hay (una búsqueda, un resumen, una cifra), la revisa `ecc:verificador`.
4. **Si falla:**
   - fallo de forma (falta un archivo, formato, comando mal escrito): un reintento con el mismo modelo y el mismo effort, con el error exacto;
   - fallo por falta de profundidad (quedó incompleto, se saltó casos, concluyó apurado, no corrió toda la validación): mismo modelo, un escalón más de effort;
   - fallo de capacidad (entendió mal, decidió algo que no le tocaba, cita inventada, test roto) o `ESCALAR`: siguiente modelo, con el brief, el intento fallido y el motivo;
   - la escalera es Haiku low → Haiku medium → Sonnet medium → Sonnet high → Opus high (`ecc:resolutor`) → Opus xhigh → Opus max (avisando a Benja);
   - cada modelo sube effort una sola vez; si vuelve a fallar, cambia de modelo. Una tarea que ya falló no vuelve a un escalón más bajo.
5. **Revisión final** igual que siempre, venga de quien venga el cambio: `ecc:code-reviewer`, los revisores del área, `ecc:security-reviewer` si corresponde y Codex en los cambios grandes. Todo CRITICAL y HIGH se corrige antes de entregar.
6. **Aprender** con datos (sección 7).

## 2b. Asesor: consultar sin rehacer

Cuando el constructor (Sonnet) se traba en una decisión que el brief no toma, pero que no cambia contratos, datos ni arquitectura, no escala: consulta.

1. Responde `CONSULTA:` con la pregunta, 2 o 3 opciones y su recomendación, y se detiene.
2. La sesión contesta corto (1 a 5 líneas) con `SendMessage` al mismo agente. Él sigue con su contexto, sin rehacer lo hecho.
3. Máximo 2 consultas por subtarea. A la tercera, la sesión replantea el brief o el agente responde `ESCALAR`.
4. `ESCALAR` sigue siendo para lo que cambia contratos, datos o arquitectura, o cuando el agente no puede hacerlo.

Así el modelo caro escribe unas líneas en vez de repetir el trabajo entero.

## 3. El ciclo ECC con la cascada

| Paso | Quién |
|---|---|
| Investigar | `ecc:explorador` (repo, logs, archivos largos) y `ecc:docs-lookup` (documentación oficial), en paralelo. La sesión lee solo los hallazgos. Si ninguna skill cargada cubre la tarea, skill `buscar-skills` (el barrido de catálogos también es del explorador) |
| Planear | la sesión, con `ecc:planner` o `ecc:architect` si cambia arquitectura. Espera el OK de Benja |
| Test primero | `ecc:constructor` o `ecc:tdd-guide`; `ecc:mecanico` solo para esqueletos ya definidos |
| Implementar | según la ruta: la sesión si son pocos pasos; si no, el agente del nivel que corresponde, en paralelo cuando no se pisan archivos |
| Revisar | revisores Sonnet; Codex y Opus en los cambios grandes; `ecc:verificador` para todo lo que hizo Haiku |
| Verificar | `ecc:ejecutor` corre check, tests y build y devuelve cifras literales; la sesión decide. Capturas y e2e: la sesión o `ecc:e2e-runner` |
| Recordar | la sesión: la memoria pide criterio |
| Mejorar | la sesión con `/ecc:learn-eval` y `/ecc:rendimiento` |

## 4. Formato del brief

Cada agente parte sin ver la conversación, así que el brief va completo:

```
Objetivo: <una frase>
Contexto: <repo y carpeta, convenciones que importan, archivos de referencia>
Qué tocar: <archivos o búsqueda exacta>   Qué NO tocar: <lo que queda fuera>
Criterio de aceptación: <comprobable: comando, cita o resultado esperado>
Validación: <comando y carpeta>
Responde con: <el formato del agente; CONSULTA o ESCALAR si se traba>
```

## 5. Cuándo no delegar

- Cuando hacerlo toma menos de 3 o 4 pasos: cada agente parte de cero y vuelve a leer lo que la sesión ya sabe.
- Cuando el paso depende de lo que se está conversando con Benja en ese momento.
- Commits, push, migraciones sobre datos reales y mensajes hacia afuera: siempre la sesión, con las reglas de siempre.

## 6. Qué no cambia

- Codex sigue siendo la segunda opinión independiente; Claude verifica lo que hace.
- `hzblj-skills:fast-worker` y `hzblj-skills:orchestrate` no se usan: esta cascada los reemplaza.
- El informe a Benja dice qué hizo cada nivel solo si importa: si algo subió de effort o de modelo, o si una salida de Haiku se rechazó.

## 7. Medir y aprender

Los hooks de ECC registran todo solos, sin llamar a ningún modelo, en `~/.claude/ecc-rendimiento/registro.jsonl`:
- cada encargo, separado por su línea `Ruta:`;
- el costo de la sesión y de cada subagente, por modelo;
- los veredictos de los revisores, `ESCALAR`, `CONSULTA` y una alerta cuando el siguiente mensaje de Benja dice "no funciona" o "sigue igual".

Al lanzar un subagente, otro hook calcula con qué modelo va a correr de verdad. En `~/.claude/ecc-rendimiento/config.json`, `"modo": "observar"` solo lo anota. `"bloquear"` niega `general-purpose`, `claude`, `fork`, `Explore` y `Plan` en Opus sin una línea `Motivo Opus:`, y le dice a la sesión qué agente usar. El bloqueo se enciende solo con el OK de Benja.

`/ecc:rendimiento` lee el registro y propone ajustes a esta skill. Las reglas para leerlo:
- La mejor ruta para un tipo de tarea es **la más barata entre las que pasan la revisión sin retrabajo**. Un ahorro que trae retrabajo no es ahorro.
- Con menos de 5 casos no se cambia una regla: se sigue mirando.
- Si un tipo de tarea falla dos veces en Haiku, desde ahí va directo a Sonnet. Si siempre necesita más effort, desde ahí parte con ese effort.
- Los cambios a la tabla los aprueba Benja, y se anotan en la memoria del proyecto.

## 8. Los 12 flujos y dónde quedan

Los flujos agénticos no son 12 opciones para elegir una: cada uno sale de una de las tres decisiones de la sección 0.

| Flujo | Sale de | En ECC |
|---|---|---|
| Cadena de pasos | organización | la sesión sola, o un agente para toda la cadena |
| Enrutamiento | organización | la sesión clasifica (sección 0) y deriva |
| En paralelo | organización | varios agentes en un mensaje, solo con partes independientes |
| Orquestador y trabajadores | organización | la sesión reparte con `/ecc:cascada` |
| Uno hace, otro revisa | control | constructor + revisor; Codex en lo grande |
| Agente autónomo | control | solo con objetivo aclarado, presupuesto y límites |
| Cascada | modelo | la escalera de la sección 2 |
| Router de modelos y effort | modelo | la tabla de la sección 0b |
| Router + cascada | modelo | lo que hace ECC: elegir el nivel y escalar si falla |
| Asesor y ejecutor | modelo | `CONSULTA` del constructor (sección 2b) |
| Planificar y ejecutar | control | `/ecc:plan`: la sesión planea, los niveles 1 y 2 ejecutan |
| Effort | modelo | la sección 1b |
