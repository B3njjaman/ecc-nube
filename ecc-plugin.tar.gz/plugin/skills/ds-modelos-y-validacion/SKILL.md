---
name: ds-modelos-y-validacion
description: "Elegir el modelo según el tipo de problema y validarlo sin engañarse: base primero y escalera de complejidad, catálogo por problema (clasificación, regresión, conteos, series de tiempo, supervivencia, anomalías, segmentación, texto, datos espaciales y RL), esquema de validación según la estructura de los datos (grupos, tiempo, espacio, anidada), auditoría de fuga, métricas elegidas por el costo del error, umbral, calibración, desbalance, análisis de errores, comparación estadística de modelos, interpretabilidad sin confundirla con causa, intervalos de predicción y evaluación de algoritmos de RL entre semillas (IQM, bootstrap estratificado). Úsala cuando haya que decidir qué modelo usar, cómo validarlo o compararlo, qué métrica reportar, por qué un modelo anda bien en validación y mal en la realidad, o cuántas semillas correr en la tesis."
metadata:
  origin: "ecc-benja; ideas de scikit-learn y exploratory-data-analysis de K-Dense-AI/claude-scientific-skills (MIT, a25cf9ec00e2), de mle-workflow de affaan-m/ECC (b38be6a7) y de Agarwal et al. (NeurIPS 2021) para RL"
---

# Modelos y validación

El orden no se negocia: definir qué se predice y cuándo, separar los datos como se van a usar en la realidad, medir una base, subir de complejidad un peldaño a la vez y comparar con estadística. Casi todos los modelos que "andaban bien" y fallaron en producción tenían una validación que no imitaba el uso real.

El código de cada pieza, ejecutable y con datos simulados, está en [references/recetario.md](references/recetario.md) (probado con scikit-learn 1.9, lightgbm 4.7, statsmodels 0.15 y lifelines 0.30). Fichas por tipo de problema en [references/catalogo.md](references/catalogo.md). El ciclo completo está en `ds-maestro`; para llevar el modelo a producción, `mle-workflow` y `ecc:mle-reviewer`.

## 1. Antes de elegir el modelo

- **Qué se predice, exactamente**: el objetivo, su horizonte ("falla en los próximos 7 días", no "falla") y la unidad.
- **Cuándo se predice**: el momento de la decisión. Solo entran variables conocidas en ese momento. Es la regla que más modelos salva.
- **Cuánto cuesta cada error** y qué capacidad hay para actuar (cuántas alertas por semana puede atender el equipo, cuántos clientes puede llamar el call center).
- **Cuántos datos hay**, y de cuántas unidades independientes. Mil filas de 12 equipos son 12 equipos.

## 2. Escalera de complejidad

| Peldaño | Qué es | Sube al siguiente si… |
|---|---|---|
| 0. Base | media, mediana, clase mayoritaria, último valor, ingenuo estacional, la regla que usa hoy el negocio | siempre se mide; si nada le gana, esa es la respuesta |
| 1. Lineal | regresión lineal o logística regularizada, con buen preprocesamiento (escalar, codificar, splines si hay curvatura) | el análisis de errores muestra interacciones o no linealidades que importan |
| 2. Árboles con boosting | LightGBM, XGBoost, CatBoost o `HistGradientBoosting` de sklearn: el estándar en datos tabulares | la ganancia sobre el lineal supera la incertidumbre de la validación y compensa perder simplicidad |
| 3. Específicos | redes para imagen, audio, texto largo o secuencias; modelos de supervivencia; modelos de base preentrenados (TabPFN para tablas chicas, Chronos o TimesFM para series) | los datos no son tabulares o hay muchísimos, y la validación lo justifica |
| 4. Ensambles | promedio o stacking de modelos distintos | la ganancia es estable entre pliegues y el costo de mantenerlo vale la pena |

En tablas típicas, el boosting suele ganarle a las redes (Grinsztajn et al., NeurIPS 2022). Un peldaño se sube por evidencia del análisis de errores, no por moda.

## 3. Catálogo por problema

| Problema | Base | Primer candidato serio | Cuándo subir | Ojo con |
|---|---|---|---|---|
| Clasificación binaria (churn, falla, fraude) | clase mayoritaria o regla actual | logística regularizada → LightGBM | interacciones claras en los errores | umbral por costo, calibración, positivos raros |
| Multiclase (tipo de falla, categoría de reclamo) | clase más frecuente | logística multinomial → LightGBM | — | F1 macro si las clases chicas importan |
| Regresión (demanda, ley de cobre, consumo) | media o mediana por segmento | lineal con splines → LightGBM | — | objetivo sesgado: modelar log o usar pérdida de cuantil o Tweedie |
| Conteos (fallas, reclamos) | tasa por segmento | GLM Poisson o binomial negativa con exposición → LightGBM `objective="poisson"` | — | la exposición (horas, clientes) va como offset |
| Series de tiempo | ingenuo estacional | ETS o SARIMAX → LightGBM con rezagos y calendario | muchas series relacionadas | validación con origen móvil; rezagos calculados solo con el pasado |
| Tiempo hasta evento con censura | Kaplan-Meier | Cox → Weibull AFT → bosques de supervivencia | riesgos no proporcionales | nunca tirar a los censurados ni tratarlos como "no ocurrió" |
| Anomalías (sensores) | umbral robusto (mediana ± k·MAD) por régimen | residuos de un modelo de comportamiento normal → Isolation Forest | muchas variables acopladas | se evalúa por eventos, no por puntos; régimen de operación |
| Segmentación | reglas (RFM, cuartiles) | k-means con variables estandarizadas → GMM o HDBSCAN | formas no esféricas, ruido | estabilidad; un segmento sin acción asociada no sirve |
| Texto | palabras clave | TF-IDF + logística → embeddings + logística → ajuste fino | — | etiquetas ruidosas; revisar errores a mano |
| Espacial (leyes de sondajes, bloques) | promedio por zona, vecino más cercano | kriging o regresión con coordenadas → boosting con variables geológicas | — | autocorrelación espacial: validar por bloques |
| Ranking y recomendación | lo más popular | factorización o vecinos → boosting para ranking | — | validar por tiempo; métricas @k |
| RL (tesis) | política aleatoria y el algoritmo de referencia | el algoritmo de referencia bien ajustado | — | sección 11 |

## 4. Validación según la estructura de los datos

| Estructura | Esquema | En sklearn |
|---|---|---|
| Filas independientes | k pliegues estratificados (5 o 10), repetidos si n es chico | `StratifiedKFold`, `RepeatedStratifiedKFold` |
| Varias filas por entidad (cliente, equipo, faena) | por grupos: una entidad nunca está en entrenamiento y validación a la vez | `GroupKFold`, `StratifiedGroupKFold` |
| Datos en el tiempo | origen móvil: entrenar con el pasado y validar con el futuro, con un hueco del tamaño del horizonte | `TimeSeriesSplit(gap=..., test_size=...)` |
| Tiempo y entidades nuevas | corte temporal y además entidades que no se vieron | a mano |
| Espacial | bloques espaciales como grupos | `GroupKFold` con el ID del bloque |
| Ajuste de hiperparámetros con pocos datos | CV anidada: la interna ajusta, la externa estima | `GridSearchCV` dentro de `cross_val_score` |
| RL | semillas independientes; evaluar en episodios y semillas de entorno distintas a las de entrenamiento | sección 11 |

- **Todo el preprocesamiento va dentro del `Pipeline`**: imputar, escalar, codificar categóricas, target encoding, seleccionar variables y re-muestrear (para esto último, `imblearn.pipeline.Pipeline`: el de sklearn no acepta re-muestreadores). Si se ajusta con todos los datos antes de partir, la validación ve información de la validación.
- El conjunto de prueba final se usa una sola vez. Si se usó para elegir algo, ya es de validación y hace falta otro.
- El error de validación lleva su dispersión entre pliegues: media ± desviación, o un intervalo.
- El número final de prueba lleva su intervalo (bootstrap del conjunto de prueba, por grupos si hay entidades), no solo el punto.

## 5. Fuga de datos

Señales: el modelo es demasiado bueno, una sola variable lo explica casi todo, o el desempeño cae en picada al ponerlo en uso.

1. **Variables del futuro**: posteriores al evento o al momento de la decisión (fecha de cierre del caso, "días en mora" para predecir mora, el campo que llena el técnico después de la falla).
2. **Identificadores que delatan**: IDs, códigos o números de orden que se asignan según el resultado.
3. **Agregados con todo el período**: el promedio del cliente calculado con el año entero, incluido el futuro.
4. **Duplicados o casi duplicados** entre entrenamiento y validación (el mismo equipo, el mismo cliente, la misma ventana solapada).
5. **Preprocesamiento fuera del pipeline** (sección 4).
6. **Selección con el conjunto de prueba**: elegir variables, umbrales o modelos mirándolo.
7. **Etiquetas selectivas y retroalimentación**: en datos de operación, la falla o el fraude solo quedan etiquetados donde alguien inspeccionó, y una vez en uso el modelo cambia qué se inspecciona, así que las etiquetas futuras ya no son una muestra del mismo proceso. Se registra qué se inspeccionó y por qué, y se reserva una fracción de inspecciones al azar.

El recetario trae el barrido: el AUC de cada variable sola (encuentra variables sospechosas), el cruce de entidades entre particiones y el placebo del procedimiento con el objetivo barajado (encuentra fuga del procedimiento, no de variables).

## 6. Métricas según el costo del error

| Situación | Métrica | Por qué |
|---|---|---|
| Clases balanceadas y costos parecidos | ROC-AUC, log loss | resume la separación en todos los umbrales |
| Positivos raros (falla, fraude) | PR-AUC (`average_precision_score`), recall a precisión fija | la ROC-AUC se ve bien aunque el modelo no sirva en la práctica |
| Costos de cada error conocidos | costo esperado con el umbral elegido | la decisión es el umbral, no el modelo |
| Capacidad limitada (inspeccionar 20 equipos por semana) | precisión@k, recall@k | se mide lo que se puede hacer |
| Las probabilidades se usan como probabilidades (riesgo, precio) | log loss, Brier y curva de calibración | un buen ranking puede tener probabilidades malas |
| Regresión con errores de igual costo | MAE | robusto y en unidades del problema |
| Los errores grandes son muy caros | RMSE | castiga los grandes |
| Importa el porcentaje | WAPE (∑\|e\| / ∑\|y\|) | el MAPE explota cerca de cero y premia subestimar |
| Pronóstico | MASE, WAPE, cobertura de los intervalos y la comparación con el ingenuo estacional en las mismas ventanas | el MASE escala por el error del ingenuo dentro de entrenamiento: sirve para comparar series; para decir que se le gana al ingenuo, se compara con él en la prueba |
| Cuantiles (inventario al p90) | pinball loss | — |
| Ranking o recomendación | NDCG@k, MAP@k, recall@k | — |
| Segmentación | silueta, estabilidad (ARI entre remuestreos), utilidad | — |
| Anomalías | fallas detectadas con anticipación ≥ h, falsas alarmas por semana | se evalúa por eventos |

La **exactitud** (accuracy) solo sirve con clases balanceadas y costos iguales. La PR-AUC y la precisión dependen de la prevalencia: no se comparan entre plantas, períodos o datos re-muestreados con otra tasa de positivos, y la prevalencia se reporta al lado. El **umbral** se elige en validación, desde los costos o la capacidad, nunca 0,5 por defecto. Con probabilidades calibradas, el umbral de costo mínimo es C_FP / (C_FP + C_FN); si no están calibradas, se busca en validación (`TunedThresholdClassifierCV` lo hace con un costo propio; ver el recetario).

## 7. Calibración y desbalance

- Si las probabilidades se van a leer como probabilidades, se mira la curva de calibración y el Brier en validación. Se recalibra con `CalibratedClassifierCV`: sigmoide con pocos datos e isotónica con muchos.
- Desbalance: primero, una métrica adecuada y mover el umbral. Después, `class_weight`. Re-muestrear (SMOTE y similares) rara vez ayuda a los modelos fuertes y descalibra las probabilidades. Si se usa, va dentro del pipeline y solo sobre los datos de entrenamiento de cada pliegue.

## 8. Ajuste de hiperparámetros

- **El mismo presupuesto para todos los modelos que se comparan**, incluida la base y el algoritmo de referencia. Ajustar mucho el propio y poco el de referencia es la forma más común de inventar una mejora.
- Búsqueda aleatoria o bayesiana (Optuna) antes que una grilla grande. Early stopping contra un pliegue de validación, nunca contra la prueba.
- Con pocos datos, CV anidada para que el error reportado no quede optimista por la selección.
- En series de tiempo, el ajuste también se hace dentro de cada origen y solo con el pasado: ajustar con la serie entera filtra el futuro.

## 9. Análisis de errores

Después de cada modelo, no solo la métrica:

1. Separar falsos positivos y falsos negativos (o los residuos más grandes) y leer 20 o 30 casos a mano.
2. Agrupar los errores por segmento: planta, turno, tipo de cliente, mes, región, régimen de operación y fuente del dato.
3. Distinguir errores del modelo de errores de etiqueta, datos faltantes, cambios de definición y casos ambiguos.
4. Cada grupo de errores lleva a una de cuatro acciones: mejores etiquetas, mejores variables, otro umbral o configuración, o una regla de negocio que lo resuelva.
5. La siguiente iteración se escribe como hipótesis comprobable ("agregar la vibración de 24 h baja los falsos negativos en el molino 2"), no como "mejorar el modelo".

## 10. Comparar modelos con estadística

- Sobre **los mismos pliegues** (comparación pareada).
- La desviación entre pliegues subestima la incertidumbre, porque los pliegues comparten datos. Se usa la **t corregida de Nadeau y Bengio** sobre CV repetida.
- En un conjunto de prueba común: **McNemar** para aciertos y errores, o **bootstrap pareado** de la diferencia de AUC, MAE u otra métrica.
- La t corregida supone filas intercambiables: con entidades repetidas o datos en el tiempo, la CV repetida es por grupos o temporal.
- McNemar y el bootstrap sobre un solo conjunto de prueba miden solo la variación de esa muestra: sirven para elegir entre dos modelos ya entrenados, no para afirmar que un algoritmo es mejor que otro (Dietterich, 1998). McNemar compara decisiones, así que se usa con el umbral de operación real.
- Una diferencia menor que la variación entre semillas o pliegues no es una mejora.

## 11. RL: evaluar algoritmos entre semillas (tesis)

Basado en Agarwal et al., *Deep RL at the Edge of the Statistical Precipice* (NeurIPS 2021), y Henderson et al., *Deep RL that Matters* (AAAI 2018):

- **La unidad es la corrida (semilla), no el episodio.** Mil episodios de evaluación de una semilla son una medición precisa de esa corrida, no mil observaciones del algoritmo.
- **Semillas**: 10 o más por algoritmo y entorno cuando se pueda. Con 3 a 5, los intervalos son tan anchos que el orden entre algoritmos cambia de una tanda a otra. Si el cómputo no alcanza, se calcula el efecto mínimo detectable con las semillas que hay (potencia en `ds-hipotesis-y-pruebas`) y se dice.
- **Puntaje normalizado** por entorno: (retorno − aleatorio) / (referencia − aleatorio), para poder agregar entre entornos.
- **Agregado**: IQM (media del 50 % central), más robusto que la media y más eficiente que la mediana, con **IC por bootstrap estratificado** (se remuestrean semillas dentro de cada entorno), y el IC de la diferencia IQM(A) − IQM(B) con el mismo bootstrap, que es el que se compara con el efecto mínimo relevante. Además, **perfiles de desempeño** (fracción de corridas sobre cada umbral) y **probabilidad de mejora** P(A > B).
- **Protocolo**: mismo presupuesto de pasos de entorno y de ajuste de hiperparámetros para todos; semillas de evaluación distintas a las de entrenamiento; el punto de control a reportar se decide antes (el final o uno fijado de antemano), nunca el máximo de la curva, que está sesgado hacia arriba.
- **Curvas de aprendizaje** con banda de IC entre semillas (no la desviación de una sola corrida), y sin un suavizado que esconda la varianza.
- Se reportan **todas** las semillas corridas. Descartar las "que divergieron" es seleccionar el resultado.
- La librería `rliable` implementa todo esto; en el recetario está el cálculo con numpy para entenderlo y verificarlo.

## 12. Interpretabilidad (no es causalidad)

- **Importancia por permutación** en validación (`permutation_importance`); la importancia que trae el árbol favorece las variables con muchos valores distintos.
- Con variables correlacionadas, la importancia se reparte o se esconde: se agrupan las correlacionadas.
- SHAP para explicar casos individuales, y PDP o ICE para la forma del efecto.
- **Que una variable importe para predecir no significa que moverla cambie el resultado.** Para eso, `ds-causalidad`.

## 13. Incertidumbre de la predicción

- Intervalos por cuantiles (LightGBM o `HistGradientBoostingRegressor` con `loss="quantile"`) o por **conformal**: con un conjunto de calibración, el intervalo cubre el nivel pedido **en promedio** (cobertura marginal) si los datos son intercambiables; no lo garantiza para cada tipo de caso, y por eso se revisa por segmento. En series de tiempo esa condición no se cumple: se usan variantes adaptativas y se verifica la cobertura en backtesting.
- Los cuantiles solos pueden quedar cortos: en el recetario, una meta de 90 % cubre 80 %. CQR (conformal sobre los cuantiles) lleva la cobertura promedio a la meta con un ancho adaptado al ruido. Por tramo, el conformal de ancho fijo cubrió 100 % donde había poco ruido y 70 % donde había mucho; CQR, 95 % y 81 %.
- Se reporta la **cobertura** real de los intervalos en validación: un intervalo de 90 % que cubre el 70 % está mal.

## Trampas

- Validación aleatoria con datos en el tiempo, con entidades repetidas o con autocorrelación espacial.
- Preprocesar o seleccionar variables con todos los datos antes de partir.
- Reportar el mejor de muchos intentos como si fuera el único.
- Comparar un modelo propio muy ajustado contra una base sin ajustar.
- Exactitud con clases desbalanceadas; MAPE con ceros; umbral 0,5 por defecto.
- Leer la importancia de variables como causa.
- Comparar detectores o modelos con cortes de distinta exigencia, o con el corte elegido mirando los mismos eventos con que se evalúan.
- En RL: pocas semillas, el máximo de la curva, evaluar en los episodios de entrenamiento, ajustar con las semillas de evaluación.
