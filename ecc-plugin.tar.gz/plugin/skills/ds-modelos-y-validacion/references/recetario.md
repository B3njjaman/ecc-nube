# Recetario de modelos y validación

Cada bloque se ejecuta solo y simula sus datos (las líneas marcadas "datos de ejemplo" se reemplazan por los reales). Los `assert` comprueban que el método recupera lo simulado: se mantienen como prueba del pipeline corriéndolo antes sobre datos simulados con la forma de los reales.

Probado el 2026-11-03 con numpy 2.4, pandas 2.3, scipy 1.17, statsmodels 0.15, scikit-learn 1.9, lightgbm 4.7 y lifelines 0.30, sin usos de API obsoleta.

## Índice

1. Pipeline sin fuga, validación por grupos y comparación con la base
2. Barrido de fuga: variables sospechosas y entidades cruzadas
3. Series de tiempo: backtesting con origen móvil y MASE
4. Umbral por costo y calibración
5. CV anidada: el error optimista de la búsqueda
6. Comparar dos modelos: t corregida, bootstrap pareado y McNemar
7. Supervivencia: Kaplan-Meier, log-rank y Cox
8. Anomalías en sensores, evaluadas por eventos
9. Segmentación: silueta y estabilidad
10. Texto: TF-IDF + logística contra la base
11. RL: IQM, bootstrap estratificado, probabilidad de mejora y perfiles
12. Importancia por permutación con variables correlacionadas
13. Intervalos de predicción: cuantiles y conformal
14. Datos espaciales: validación por bloques

## 1. Pipeline sin fuga, validación por grupos y comparación con la base

```python
import numpy as np
import pandas as pd
from sklearn.compose import ColumnTransformer
from sklearn.dummy import DummyClassifier
from sklearn.ensemble import HistGradientBoostingClassifier
from sklearn.impute import SimpleImputer
from sklearn.linear_model import LogisticRegression
from sklearn.model_selection import StratifiedGroupKFold, cross_validate
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import OneHotEncoder, StandardScaler

rng = np.random.default_rng(21)
n_clientes = 800   # datos de ejemplo: de 1 a 5 meses por cliente; objetivo churn
filas = rng.integers(1, 6, n_clientes)
df = pd.DataFrame({"cliente": np.repeat(np.arange(n_clientes), filas)})
propension = np.repeat(rng.normal(0, 1, n_clientes), filas)        # rasgo del cliente que no se observa
df["uso"] = rng.gamma(2, 10, len(df)) * np.exp(-0.3 * propension)
df["reclamos"] = rng.poisson(0.5 + 0.5 * (propension > 1), len(df))
df["plan"] = rng.choice(["basico", "full", "empresa"], len(df))
df.loc[rng.random(len(df)) < 0.05, "uso"] = np.nan
logit = (-2.0 - 0.04 * df["uso"].fillna(20) + 0.6 * df["reclamos"] + 0.8 * propension
         + 0.5 * (df["plan"] == "basico"))
df["churn"] = (rng.random(len(df)) < 1 / (1 + np.exp(-logit))).astype(int)

X, y, grupos = df[["uso", "reclamos", "plan"]], df["churn"], df["cliente"]
prep = ColumnTransformer([   # todo el preprocesamiento dentro del pipeline: se ajusta en cada pliegue
    ("num", make_pipeline(SimpleImputer(strategy="median", add_indicator=True), StandardScaler()),
     ["uso", "reclamos"]),   # el indicador conserva la señal de "faltaba el dato"
    ("cat", OneHotEncoder(handle_unknown="ignore"), ["plan"]),
])
modelos = {
    "base (clase mayoritaria)": DummyClassifier(strategy="prior"),
    "logística": make_pipeline(prep, LogisticRegression(max_iter=1000)),
    "boosting": make_pipeline(prep, HistGradientBoostingClassifier(max_depth=3, random_state=0)),
}
cv = StratifiedGroupKFold(n_splits=5, shuffle=True, random_state=0)   # un cliente nunca queda a ambos lados
resultados = {}
for nombre, modelo in modelos.items():
    r = cross_validate(modelo, X, y, groups=grupos, cv=cv, scoring=["average_precision", "roc_auc"])
    resultados[nombre] = r["test_average_precision"].mean()
    print(f"{nombre:25s} PR-AUC {r['test_average_precision'].mean():.3f} ± {r['test_average_precision'].std():.3f}"
          f" | ROC-AUC {r['test_roc_auc'].mean():.3f}")
print(f"tasa de churn {y.mean():.3f}: es la PR-AUC de un modelo sin información")
assert resultados["logística"] > resultados["base (clase mayoritaria)"] + 0.05
```

Con estos datos el boosting no mejora a la logística, porque el fenómeno simulado es lineal: por eso se miden la base y el lineal antes de subir de peldaño. Para afirmar que uno le gana al otro hace falta la comparación pareada de la sección 6, no las medias de los pliegues.

## 2. Barrido de fuga: variables sospechosas y entidades cruzadas

```python
import numpy as np
import pandas as pd
from sklearn.model_selection import StratifiedKFold, cross_val_score
from sklearn.preprocessing import OrdinalEncoder
from sklearn.tree import DecisionTreeClassifier

rng = np.random.default_rng(22)
n = 2000   # datos de ejemplo: registros de equipos con dos variables que filtran el objetivo
df = pd.DataFrame({"temperatura": rng.normal(60, 8, n), "vibracion": rng.gamma(2, 1, n),
                   "turno": rng.choice(["A", "B", "C"], n)})
logit = -3 + 0.05 * (df["temperatura"] - 60) + 0.4 * df["vibracion"]
df["falla"] = (rng.random(n) < 1 / (1 + np.exp(-logit))).astype(int)
df["horas_detencion"] = np.where(df["falla"] == 1, rng.gamma(3, 4, n), 0)      # se registra después de la falla
df["orden_trabajo"] = np.where(df["falla"] == 1, rng.integers(9000, 9999, n),   # el correlativo delata el objetivo
                               rng.integers(1000, 8999, n))

X = df.drop(columns="falla")
categoricas = X.select_dtypes(exclude="number").columns
X[categoricas] = OrdinalEncoder().fit_transform(X[categoricas])
cv = StratifiedKFold(5, shuffle=True, random_state=0)
auc_sola = {c: cross_val_score(DecisionTreeClassifier(max_depth=3, random_state=0), X[[c]], df["falla"],
                               cv=cv, scoring="roc_auc").mean() for c in X.columns}
for c, auc in sorted(auc_sola.items(), key=lambda kv: -kv[1]):
    # el corte es una alarma, no una regla: una variable posterior al evento con AUC 0,75 también filtra
    aviso = "<- SOSPECHOSA: ¿se conoce en el momento de decidir?" if auc > 0.9 else ""
    print(f"{c:16s} AUC sola {auc:.3f} {aviso}")
assert {c for c, a in auc_sola.items() if a > 0.9} == {"horas_detencion", "orden_trabajo"}
```

Entidades que quedan a ambos lados de la partición (debe dar cero si la validación es por grupos):

```python
import numpy as np
from sklearn.model_selection import GroupKFold, KFold

grupos = np.repeat(np.arange(100), 10)   # datos de ejemplo: 100 equipos, 10 ventanas de tiempo por equipo
for nombre, cv in (("KFold", KFold(5, shuffle=True, random_state=0)), ("GroupKFold", GroupKFold(5))):
    cruces = [len(set(grupos[tr]) & set(grupos[va])) for tr, va in cv.split(grupos, groups=grupos)]
    print(f"{nombre}: equipos en entrenamiento y validación a la vez, por pliegue: {cruces}")
    if nombre == "GroupKFold":
        assert sum(cruces) == 0
```

Placebo del procedimiento: con el objetivo barajado, el procedimiento completo (selección de variables y preprocesamiento incluidos) tiene que dar el nivel de la base. Detecta la fuga del procedimiento, no la de variables: al barajar, una variable posterior al evento pierde su relación con el objetivo igual que las demás, y esas se encuentran con la auditoría de disponibilidad y el barrido de arriba. Con entidades repetidas, el placebo se corre con validación por grupos.

```python
import numpy as np
from sklearn.feature_selection import SelectKBest, f_classif
from sklearn.linear_model import LogisticRegression
from sklearn.model_selection import StratifiedKFold, cross_val_score
from sklearn.pipeline import make_pipeline

rng = np.random.default_rng(23)
X = rng.normal(size=(200, 2000))   # datos de ejemplo: 2.000 variables de puro ruido
y = rng.permutation(np.r_[np.zeros(100), np.ones(100)]).astype(int)   # objetivo barajado: no hay nada que aprender
cv = StratifiedKFold(5, shuffle=True, random_state=0)

# Mal: elegir las 20 variables más asociadas usando todos los datos, y después validar
elegidas = SelectKBest(f_classif, k=20).fit(X, y).get_support()
auc_fuera = cross_val_score(LogisticRegression(max_iter=1000), X[:, elegidas], y, cv=cv, scoring="roc_auc").mean()
# Bien: la selección dentro del pipeline, ajustada solo con el entrenamiento de cada pliegue
dentro = make_pipeline(SelectKBest(f_classif, k=20), LogisticRegression(max_iter=1000))
auc_dentro = cross_val_score(dentro, X, y, cv=cv, scoring="roc_auc").mean()
print(f"objetivo barajado: AUC con la selección fuera de la validación {auc_fuera:.3f} (fuga); "
      f"dentro del pipeline {auc_dentro:.3f}")
assert auc_fuera > 0.7 and abs(auc_dentro - 0.5) < 0.1
```

## 3. Series de tiempo: backtesting con origen móvil y MASE

```python
import lightgbm as lgb
import numpy as np
import pandas as pd
from statsmodels.tsa.holtwinters import ExponentialSmoothing

rng = np.random.default_rng(23)
semanas = pd.date_range("2022-01-02", periods=208, freq="W")
t = np.arange(len(semanas))
y = pd.Series(1000 + 2 * t + 120 * np.sin(2 * np.pi * t / 52) + rng.normal(0, 40, len(t)),
              index=semanas)   # datos de ejemplo: demanda semanal con tendencia y estacionalidad anual

h, m = 4, 52   # horizonte de 4 semanas, estacionalidad de 52

def mase(real, pred, entrenamiento):
    escala = np.mean(np.abs(entrenamiento[m:] - entrenamiento[:-m]))   # error del ingenuo estacional en entrenamiento
    return np.mean(np.abs(real - pred)) / escala

# LightGBM sobre el cambio contra el año anterior (los árboles no extrapolan tendencias),
# con rezagos >= h: todos se conocen en el momento de pronosticar
d = y - y.shift(m)
X_todo = pd.DataFrame({f"d_lag_{k}": d.shift(k) for k in (h, h + 1, h + 2, h + 3)})
X_todo["semana"] = y.index.isocalendar().week.astype(int).to_numpy()

errores = {"ingenuo estacional": [], "Holt-Winters": [], "LightGBM con rezagos": []}
for origen in range(156, len(y) - h + 1, h):   # 13 orígenes en el último año
    entrenamiento, real = y.iloc[:origen], y.iloc[origen:origen + h].to_numpy()
    ingenuo = y.iloc[origen - m:origen - m + h].to_numpy()
    hw = ExponentialSmoothing(entrenamiento, trend="add", seasonal="add", seasonal_periods=m).fit()
    filas = X_todo.iloc[:origen].join(d.rename("objetivo")).dropna()
    gbm = lgb.LGBMRegressor(n_estimators=200, learning_rate=0.05, min_child_samples=5, verbose=-1)
    gbm.fit(filas.drop(columns="objetivo"), filas["objetivo"])
    pred_gbm = y.shift(m).iloc[origen:origen + h].to_numpy() + gbm.predict(X_todo.iloc[origen:origen + h])
    for nombre, pred in (("ingenuo estacional", ingenuo), ("Holt-Winters", hw.forecast(h).to_numpy()),
                         ("LightGBM con rezagos", pred_gbm)):
        errores[nombre].append(mase(real, pred, entrenamiento.to_numpy()))

for nombre, e in errores.items():
    print(f"{nombre:22s} MASE {np.mean(e):.2f} (entre orígenes: {np.min(e):.2f} a {np.max(e):.2f})")
assert np.mean(errores["Holt-Winters"]) < np.mean(errores["ingenuo estacional"])
```

## 4. Umbral por costo y calibración

```python
import numpy as np
from sklearn.calibration import CalibratedClassifierCV, calibration_curve
from sklearn.datasets import make_classification
from sklearn.ensemble import HistGradientBoostingClassifier
from sklearn.metrics import brier_score_loss, confusion_matrix, make_scorer
from sklearn.model_selection import TunedThresholdClassifierCV, train_test_split

X, y = make_classification(n_samples=6000, n_features=12, n_informative=5, weights=[0.95],
                           random_state=24)   # datos de ejemplo: 5 % de fallas
X_tr, X_te, y_tr, y_te = train_test_split(X, y, test_size=0.3, stratify=y, random_state=0)

COSTO_FN, COSTO_FP = 50.0, 2.0   # una falla no detectada cuesta 25 veces una inspección innecesaria

def costo_total(y_true, y_pred):
    tn, fp, fn, tp = confusion_matrix(y_true, y_pred, labels=[0, 1]).ravel()
    return COSTO_FN * fn + COSTO_FP * fp

modelo = HistGradientBoostingClassifier(random_state=0)
por_costo = TunedThresholdClassifierCV(modelo, scoring=make_scorer(costo_total, greater_is_better=False),
                                       cv=5).fit(X_tr, y_tr)
con_05 = HistGradientBoostingClassifier(random_state=0).fit(X_tr, y_tr)
costo_05, costo_ajustado = costo_total(y_te, con_05.predict(X_te)), costo_total(y_te, por_costo.predict(X_te))
print(f"umbral elegido por costo: {por_costo.best_threshold_:.3f}")
print(f"costo en prueba con umbral 0,5: {costo_05:.0f}; con el umbral por costo: {costo_ajustado:.0f}")

prob = con_05.predict_proba(X_te)[:, 1]
calibrado = CalibratedClassifierCV(HistGradientBoostingClassifier(random_state=0), method="isotonic",
                                   cv=5).fit(X_tr, y_tr)
prob_cal = calibrado.predict_proba(X_te)[:, 1]
print(f"Brier sin calibrar {brier_score_loss(y_te, prob):.4f}; calibrado {brier_score_loss(y_te, prob_cal):.4f}")
observado, predicho = calibration_curve(y_te, prob_cal, n_bins=8, strategy="quantile")
print("calibración (predicho -> observado):", " ".join(f"{p:.2f}->{o:.2f}" for p, o in zip(predicho, observado)))
assert costo_ajustado < costo_05
```

## 5. CV anidada: el error optimista de la búsqueda

```python
from sklearn.datasets import make_classification
from sklearn.linear_model import LogisticRegression
from sklearn.model_selection import GridSearchCV, StratifiedKFold, cross_val_score
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import StandardScaler

X, y = make_classification(n_samples=200, n_features=60, n_informative=4, flip_y=0.1,
                           random_state=25)   # datos de ejemplo: pocos casos y muchas variables
busqueda = GridSearchCV(
    make_pipeline(StandardScaler(), LogisticRegression(max_iter=5000)),
    {"logisticregression__C": [0.001, 0.003, 0.01, 0.03, 0.1, 0.3, 1, 3, 10, 30, 100]},
    cv=StratifiedKFold(5, shuffle=True, random_state=1), scoring="roc_auc",
)
optimista = busqueda.fit(X, y).best_score_
anidada = cross_val_score(busqueda, X, y, cv=StratifiedKFold(5, shuffle=True, random_state=2), scoring="roc_auc")
print(f"AUC del mejor C en la búsqueda (optimista): {optimista:.3f}; "
      f"con CV anidada: {anidada.mean():.3f} ± {anidada.std():.3f}")
```

## 6. Comparar dos modelos: t corregida, bootstrap pareado y McNemar

Sobre CV repetida, con los mismos pliegues para los dos modelos:

```python
import numpy as np
from scipy import stats
from sklearn.datasets import make_classification
from sklearn.ensemble import HistGradientBoostingClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.model_selection import RepeatedStratifiedKFold, cross_val_score

X, y = make_classification(n_samples=1500, n_features=20, n_informative=6, random_state=26)   # datos de ejemplo
k, r = 10, 5
cv = RepeatedStratifiedKFold(n_splits=k, n_repeats=r, random_state=0)   # semilla fija: mismos pliegues para ambos
a = cross_val_score(HistGradientBoostingClassifier(random_state=0), X, y, cv=cv, scoring="roc_auc")
b = cross_val_score(LogisticRegression(max_iter=1000), X, y, cv=cv, scoring="roc_auc")

d = a - b
n_val, n_ent = len(y) / k, len(y) * (k - 1) / k
t_corr = d.mean() / np.sqrt((1 / len(d) + n_val / n_ent) * d.var(ddof=1))   # Nadeau y Bengio (2003)
p_corr = 2 * stats.t.sf(abs(t_corr), df=len(d) - 1)
t_ingenua = d.mean() / np.sqrt(d.var(ddof=1) / len(d))
print(f"diferencia de AUC {d.mean():.4f}; t corregida {t_corr:.2f} (p = {p_corr:.4g}); "
      f"la t ingenua daría {t_ingenua:.2f}")
assert abs(t_corr) < abs(t_ingenua)
```

Sobre un conjunto de prueba común:

```python
import numpy as np
from sklearn.datasets import make_classification
from sklearn.ensemble import HistGradientBoostingClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import roc_auc_score
from sklearn.model_selection import train_test_split
from statsmodels.stats.contingency_tables import mcnemar

X, y = make_classification(n_samples=3000, n_features=20, n_informative=6, random_state=27)   # datos de ejemplo
X_tr, X_te, y_tr, y_te = train_test_split(X, y, test_size=0.4, stratify=y, random_state=0)
pa = HistGradientBoostingClassifier(random_state=0).fit(X_tr, y_tr).predict_proba(X_te)[:, 1]
pb = LogisticRegression(max_iter=1000).fit(X_tr, y_tr).predict_proba(X_te)[:, 1]

rng = np.random.default_rng(0)
difs = []
for _ in range(2000):   # bootstrap pareado: los mismos casos remuestreados para ambos modelos
    i = rng.integers(0, len(y_te), len(y_te))
    difs.append(roc_auc_score(y_te[i], pa[i]) - roc_auc_score(y_te[i], pb[i]))
lo, hi = np.percentile(difs, [2.5, 97.5])
print(f"AUC A − B = {roc_auc_score(y_te, pa) - roc_auc_score(y_te, pb):.4f} (IC 95 % bootstrap {lo:.4f} a {hi:.4f})")

# McNemar compara decisiones: se usa el umbral de operación real (aquí 0,5 porque las clases están balanceadas)
acierta_a, acierta_b = (pa > 0.5) == y_te, (pb > 0.5) == y_te
tabla = [[np.sum(acierta_a & acierta_b), np.sum(acierta_a & ~acierta_b)],
         [np.sum(~acierta_a & acierta_b), np.sum(~acierta_a & ~acierta_b)]]
print("McNemar:", mcnemar(tabla, exact=False, correction=True))
```

Estas dos pruebas solo miden la variación de la muestra de prueba: sirven para elegir entre dos modelos ya entrenados, no para afirmar que un algoritmo es mejor que otro (para eso, la t corregida sobre CV repetida, que incluye la variación del entrenamiento; Dietterich, 1998). La t corregida supone filas intercambiables: con entidades repetidas o datos en el tiempo, la CV repetida tiene que ser por grupos o temporal.

## 7. Supervivencia: Kaplan-Meier, log-rank y Cox

```python
import numpy as np
import pandas as pd
from lifelines import CoxPHFitter, KaplanMeierFitter
from lifelines.statistics import logrank_test

rng = np.random.default_rng(28)
n = 400   # datos de ejemplo: horas hasta la falla de un componente, de dos proveedores
df = pd.DataFrame({"proveedor_b": rng.integers(0, 2, n), "carga": rng.uniform(0.5, 1.0, n)})
k = 1.5   # Weibull con riesgos proporcionales: HR real del proveedor B = 1.6
escala = 5000 * np.exp(-(np.log(1.6) * df["proveedor_b"] + 1.2 * (df["carga"] - 0.75)) / k)
tiempo_falla = escala * rng.weibull(k, n)
censura = rng.uniform(1000, 12000, n)   # equipos que siguen funcionando o se retiraron sin fallar
df["horas"] = np.minimum(tiempo_falla, censura)
df["fallo"] = (tiempo_falla <= censura).astype(int)
print(f"censurados: {1 - df['fallo'].mean():.0%} (no se botan ni se tratan como 'no falló')")

for prov, g in df.groupby("proveedor_b"):
    km = KaplanMeierFitter().fit(g["horas"], g["fallo"], label=f"proveedor {'B' if prov else 'A'}")
    print(f"{km.label}: mediana de vida {km.median_survival_time_:.0f} h")
b, a = df[df["proveedor_b"] == 1], df[df["proveedor_b"] == 0]
print(f"log-rank p = {logrank_test(b['horas'], a['horas'], b['fallo'], a['fallo']).p_value:.4g}")

cox = CoxPHFitter().fit(df, duration_col="horas", event_col="fallo")
lo, hi = np.exp(cox.confidence_intervals_.loc["proveedor_b"])
print(f"HR proveedor B = {cox.hazard_ratios_['proveedor_b']:.2f} (IC 95 %: {lo:.2f} a {hi:.2f}); "
      f"C-index {cox.concordance_index_:.3f}")
cox.check_assumptions(df, p_value_threshold=0.01, show_plots=False)   # riesgos proporcionales
assert lo < 1.6 < hi
```

## 8. Anomalías en sensores, evaluadas por eventos

La vibración normal depende de la carga. Un umbral fijo confunde "mucha carga" con "falla"; el residuo de un modelo de comportamiento normal no. Para comparar detectores con justicia, los tres usan la misma regla de corte, fijada en el período normal sin mirar las fallas, y además se muestra la curva de fallas avisadas contra falsas alarmas.

```python
import numpy as np
import pandas as pd
from scipy.stats import median_abs_deviation
from sklearn.ensemble import IsolationForest
from sklearn.linear_model import HuberRegressor

rng = np.random.default_rng(29)
horas = pd.date_range("2025-01-01", periods=24 * 240, freq="h")   # datos de ejemplo: 240 días de un molino, por hora
carga = np.clip(0.7 + 0.15 * np.sin(np.arange(len(horas)) * 2 * np.pi / (24 * 9))
                + rng.normal(0, 0.05, len(horas)), 0.3, 1.0)
vib = 2.0 + 3.0 * carga + rng.normal(0, 0.15, len(horas))
fallas = pd.to_datetime(["2025-03-10 14:00", "2025-05-02 03:00", "2025-06-20 22:00", "2025-08-01 09:00"])
for f in fallas:   # deriva en las 48 h previas a cada falla
    previa = (horas > f - pd.Timedelta("48h")) & (horas <= f)
    vib[previa] += np.linspace(0, 0.8, previa.sum())
df = pd.DataFrame({"carga": carga, "vibracion": vib}, index=horas)
fin_normal = "2025-02-28"   # período sin fallas: se aprende lo normal y se fija el corte
normal = df.loc[:fin_normal]

# Tres puntajes: más alto = más anómalo
modelo = HuberRegressor().fit(normal[["carga"]], normal["vibracion"])   # vibración esperada según la carga
res = df["vibracion"] - modelo.predict(df[["carga"]])
res_n = res.loc[:fin_normal]
iso = IsolationForest(n_estimators=300, random_state=0).fit(normal)
puntajes = {
    "umbral fijo": df["vibracion"],
    "residuo robusto": (res - np.median(res_n)) / median_abs_deviation(res_n, scale="normal"),
    "Isolation Forest": pd.Series(-iso.score_samples(df), index=df.index),
}

def evaluar(alertas, anticipacion="6h", ventana="72h"):
    """Fallas avisadas entre 72 h y 6 h antes, y falsas alarmas por semana (contadas como episodios)."""
    avisadas, cerca = 0, pd.Series(False, index=alertas.index)
    for f in fallas:
        avisadas += bool(alertas[(alertas.index > f - pd.Timedelta(ventana))
                                 & (alertas.index <= f - pd.Timedelta(anticipacion))].any())
        cerca |= (alertas.index > f - pd.Timedelta(ventana)) & (alertas.index <= f)
    falsas = alertas & ~cerca
    episodios = int((falsas & ~falsas.shift(fill_value=False)).sum())
    semanas = (alertas.index[-1] - alertas.index[0]) / pd.Timedelta("7D")
    return avisadas, episodios / semanas

resultado = {}
for nombre, s in puntajes.items():
    suave = s.rolling("6h").mean()                    # el mismo suavizado para todos
    corte = suave.loc[:fin_normal].quantile(0.999)    # la misma regla: fijada en el período normal
    evaluacion = suave.loc["2025-03-01":]
    resultado[nombre] = evaluar(evaluacion > corte)
    curva = []                                         # curva: mejor resultado con cada presupuesto de falsas alarmas
    for c in np.quantile(evaluacion, np.linspace(0.90, 0.9999, 60)):
        curva.append(evaluar(evaluacion > c))
    por_presupuesto = {b: max((a for a, fa in curva if fa <= b), default=0) for b in (0.15, 0.5, 1.0)}
    print(f"{nombre:17s} con el corte del período normal: {resultado[nombre][0]}/{len(fallas)} avisadas, "
          f"{resultado[nombre][1]:.2f} falsas/semana | curva (falsas/semana -> avisadas): {por_presupuesto}")
assert resultado["residuo robusto"][0] >= 3 and resultado["residuo robusto"][1] < 0.5
```

Con estos datos y la misma regla de corte, el residuo avisa 4 de 4 fallas con 0,15 falsas alarmas por semana; el Isolation Forest, 4 de 4 con 0,62; el umbral fijo, 1 de 4. Con un presupuesto de 0,15 falsas alarmas por semana, la curva da 4, 3 y 1. La regla de corte (el percentil 99,9 del puntaje suavizado en el período normal) se fija sin mirar las fallas; la curva sí las usa, y sirve para comparar detectores en el mismo punto de operación, no para elegir el corte. En datos reales, el corte se ajusta a cuántas alertas por semana puede atender el equipo y se evalúa en fallas que no se usaron para elegirlo.

## 9. Segmentación: silueta y estabilidad

```python
import numpy as np
from sklearn.cluster import KMeans
from sklearn.datasets import make_blobs
from sklearn.metrics import adjusted_rand_score, silhouette_score
from sklearn.preprocessing import StandardScaler

X, _ = make_blobs(n_samples=1500, centers=4, cluster_std=[1.0, 1.5, 0.8, 1.2], n_features=5,
                  random_state=30)   # datos de ejemplo: 4 segmentos reales
X = StandardScaler().fit_transform(X)
rng = np.random.default_rng(30)
siluetas = {}
for k in range(2, 8):
    siluetas[k] = silhouette_score(X, KMeans(k, n_init=10, random_state=0).fit_predict(X))
    aris = []
    for _ in range(10):   # estabilidad: dos ajustes en remuestreos distintos, comparados sobre todos los puntos
        i, j = rng.integers(0, len(X), len(X)), rng.integers(0, len(X), len(X))
        a = KMeans(k, n_init=10, random_state=1).fit(X[i]).predict(X)
        b = KMeans(k, n_init=10, random_state=2).fit(X[j]).predict(X)
        aris.append(adjusted_rand_score(a, b))
    print(f"k = {k}: silueta {siluetas[k]:.3f}, estabilidad (ARI medio) {np.mean(aris):.3f}")
assert max(siluetas, key=siluetas.get) == 4
```

## 10. Texto: TF-IDF + logística contra la base

```python
import numpy as np
from sklearn.dummy import DummyClassifier
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import LogisticRegression
from sklearn.model_selection import StratifiedKFold, cross_val_score
from sklearn.pipeline import make_pipeline

rng = np.random.default_rng(31)
vocabulario = {   # datos de ejemplo: órdenes de trabajo de mantenimiento
    "mecanica": ["rodamiento", "desgaste", "eje", "vibracion", "lubricacion"],
    "electrica": ["motor", "cortocircuito", "tablero", "fusible", "voltaje"],
    "hidraulica": ["fuga", "manguera", "presion", "bomba", "aceite"],
}
comunes = ["revisar", "equipo", "turno", "urgente", "falla", "cambio", "inspeccion", "operador"]
todas = [p for lista in vocabulario.values() for p in lista]
textos, etiquetas = [], []
for _ in range(600):
    cat = rng.choice(list(vocabulario), p=[0.5, 0.3, 0.2])
    palabras = [*rng.choice(vocabulario[cat], 2), *rng.choice(todas, 1), *rng.choice(comunes, 4)]
    textos.append(" ".join(rng.permutation(palabras)))
    etiquetas.append(cat)

cv = StratifiedKFold(5, shuffle=True, random_state=0)
base = cross_val_score(DummyClassifier(strategy="most_frequent"), textos, etiquetas, cv=cv, scoring="f1_macro")
tfidf = cross_val_score(make_pipeline(TfidfVectorizer(ngram_range=(1, 2), min_df=2), LogisticRegression(max_iter=1000)),
                        textos, etiquetas, cv=cv, scoring="f1_macro")
print(f"F1 macro: base {base.mean():.3f}; TF-IDF + logística {tfidf.mean():.3f} ± {tfidf.std():.3f}")
assert tfidf.mean() > base.mean() + 0.3
```

## 11. RL: IQM, bootstrap estratificado, probabilidad de mejora y perfiles

```python
import numpy as np
from scipy.stats import trim_mean

rng = np.random.default_rng(32)
entornos, semillas = 5, 10   # datos de ejemplo: puntaje normalizado final por entorno (filas) y semilla (columnas)
ppo = rng.beta(5.0, 4.0, (entornos, semillas))        # (retorno − aleatorio) / (referencia − aleatorio)
variante = rng.beta(6.0, 3.6, (entornos, semillas))   # corridas independientes, no pareadas con las de PPO

def iqm(puntajes):
    return trim_mean(puntajes.ravel(), 0.25)   # media del 50 % central de todas las corridas

def ic_estratificado(estadistico, *matrices, reps=5000):
    """Bootstrap estratificado: remuestrea semillas dentro de cada entorno, por separado para cada algoritmo."""
    valores = np.empty(reps)
    for r in range(reps):
        remuestreo = [np.take_along_axis(x, rng.integers(0, x.shape[1], x.shape), axis=1) for x in matrices]
        valores[r] = estadistico(*remuestreo)
    return np.percentile(valores, [2.5, 97.5])

def prob_mejora(a, b):
    """P(una corrida de A supera a una de B), promediada entre entornos (U de Mann-Whitney / n·m)."""
    return np.mean([np.mean(a[e][:, None] > b[e][None, :]) + 0.5 * np.mean(a[e][:, None] == b[e][None, :])
                    for e in range(a.shape[0])])

for nombre, x in (("PPO", ppo), ("variante", variante)):
    lo, hi = ic_estratificado(iqm, x)
    print(f"{nombre:9s} IQM {iqm(x):.3f} (IC 95 %: {lo:.3f} a {hi:.3f})")
lo_d, hi_d = ic_estratificado(lambda a, b: iqm(a) - iqm(b), variante, ppo)
print(f"IQM variante − IQM PPO = {iqm(variante) - iqm(ppo):.3f} (IC 95 %: {lo_d:.3f} a {hi_d:.3f})")
lo, hi = ic_estratificado(prob_mejora, variante, ppo)
print(f"P(variante > PPO) = {prob_mejora(variante, ppo):.3f} (IC 95 %: {lo:.3f} a {hi:.3f})")

umbrales = np.linspace(0, 1, 11)   # perfil de desempeño: fracción de corridas por sobre cada umbral
for nombre, x in (("PPO", ppo), ("variante", variante)):
    print(f"perfil {nombre:9s}", " ".join(f"{(x > u).mean():.2f}" for u in umbrales))

real = iqm(rng.beta(6.0, 3.6, 10**6)) - iqm(rng.beta(5.0, 4.0, 10**6))   # diferencia poblacional, por Monte Carlo
print(f"diferencia real simulada {real:.3f}")
assert lo_d < real < hi_d
```

Para la tesis se usa la librería `rliable` (Agarwal et al., 2021), que implementa lo mismo con gráficos; este bloque sirve para entender y verificar sus números.

## 12. Importancia por permutación con variables correlacionadas

```python
import numpy as np
from sklearn.ensemble import HistGradientBoostingRegressor
from sklearn.inspection import permutation_importance
from sklearn.metrics import mean_absolute_error
from sklearn.model_selection import train_test_split

rng = np.random.default_rng(33)
n = 3000   # datos de ejemplo: x2 es casi una copia de x1; ruido no aporta nada
x1 = rng.normal(size=n)
x2 = x1 + rng.normal(scale=0.05, size=n)
x3, ruido = rng.normal(size=n), rng.normal(size=n)
X = np.c_[x1, x2, x3, ruido]
y = 2 * x1 + 1 * x3 + rng.normal(size=n)
nombres = ["x1", "x2 (copia de x1)", "x3", "ruido"]
X_tr, X_va, y_tr, y_va = train_test_split(X, y, test_size=0.3, random_state=0)
m = HistGradientBoostingRegressor(random_state=0).fit(X_tr, y_tr)

imp = permutation_importance(m, X_va, y_va, n_repeats=20, random_state=0, scoring="neg_mean_absolute_error")
for nombre, media, de in zip(nombres, imp.importances_mean, imp.importances_std):
    print(f"{nombre:17s} sube el MAE en {media:.3f} ± {de:.3f}")

# Permutar juntas las correlacionadas muestra cuánto pesa el grupo
base = mean_absolute_error(y_va, m.predict(X_va))
Xp = X_va.copy()
Xp[:, [0, 1]] = Xp[rng.permutation(len(Xp))][:, [0, 1]]
print(f"x1 y x2 juntas suben el MAE en {mean_absolute_error(y_va, m.predict(Xp)) - base:.3f}")
assert imp.importances_mean[3] < 0.05
```

## 13. Intervalos de predicción: cuantiles y conformal

```python
import numpy as np
from sklearn.ensemble import HistGradientBoostingRegressor
from sklearn.model_selection import train_test_split

rng = np.random.default_rng(34)
n = 6000   # datos de ejemplo: consumo de energía con ruido que crece con la carga
X = rng.uniform(0, 10, (n, 3))
y = 5 + 2 * X[:, 0] + np.sin(X[:, 1]) + rng.normal(0, 0.3 + 0.3 * X[:, 0], n)
X_tr, X_tmp, y_tr, y_tmp = train_test_split(X, y, test_size=0.5, random_state=0)
X_cal, X_te, y_cal, y_te = train_test_split(X_tmp, y_tmp, test_size=0.5, random_state=0)
alfa = 0.10   # se busca un 90 % de cobertura

# Cuantiles: dos modelos, uno por borde
lo_m = HistGradientBoostingRegressor(loss="quantile", quantile=alfa / 2, random_state=0).fit(X_tr, y_tr)
hi_m = HistGradientBoostingRegressor(loss="quantile", quantile=1 - alfa / 2, random_state=0).fit(X_tr, y_tr)
cob_cuantil = np.mean((y_te >= lo_m.predict(X_te)) & (y_te <= hi_m.predict(X_te)))

# Conformal partido: el residuo de calibración da el ancho, con garantía si los datos son intercambiables
media = HistGradientBoostingRegressor(random_state=0).fit(X_tr, y_tr)
residuos = np.abs(y_cal - media.predict(X_cal))
nivel = np.ceil((len(residuos) + 1) * (1 - alfa)) / len(residuos)
q = np.quantile(residuos, nivel, method="higher")
pred = media.predict(X_te)
cob_conformal = np.mean((y_te >= pred - q) & (y_te <= pred + q))

# Conformal sobre los cuantiles (CQR): ancho que se adapta al ruido y con la garantía de cobertura
e = np.maximum(lo_m.predict(X_cal) - y_cal, y_cal - hi_m.predict(X_cal))
q_cqr = np.quantile(e, nivel, method="higher")
cob_cqr = np.mean((y_te >= lo_m.predict(X_te) - q_cqr) & (y_te <= hi_m.predict(X_te) + q_cqr))
print(f"cobertura en prueba (meta 90 %): cuantiles {cob_cuantil:.1%}; conformal {cob_conformal:.1%} "
      f"(ancho fijo ±{q:.2f}); CQR {cob_cqr:.1%}")

# La garantía es marginal (en promedio sobre x): se revisa por tramo, sobre todo donde el ruido es mayor
tramo = np.digitize(X_te[:, 0], [2.5, 5.0, 7.5])
bordes = {"conformal": (pred - q, pred + q),
          "CQR": (lo_m.predict(X_te) - q_cqr, hi_m.predict(X_te) + q_cqr)}
for nombre, (b_lo, b_hi) in bordes.items():
    cob = [np.mean((y_te[tramo == k] >= b_lo[tramo == k]) & (y_te[tramo == k] <= b_hi[tramo == k])) for k in range(4)]
    print(f"{nombre:9s} cobertura por tramo de x0 (ruido creciente): " + " / ".join(f"{c:.0%}" for c in cob))
assert 0.87 < cob_conformal < 0.93 and 0.87 < cob_cqr < 0.93
```

Con estos datos los cuantiles solos cubren 80 % (para una meta de 90 %); conformal llega a 88 % y CQR a 89 %. Pero la garantía es marginal: por tramo, el conformal de ancho fijo sobrecubre donde hay poco ruido y queda muy corto donde hay mucho, y CQR reparte mejor la cobertura sin igualarla del todo. Para producción, la librería MAPIE implementa estas variantes.

## 14. Datos espaciales: validación por bloques

Las muestras de sondajes cercanas se parecen. Con validación aleatoria, el modelo "predice" una muestra mirando a su vecina, y el error queda optimista. El tamaño del bloque se elige con el variograma, y define la tarea que se está validando.

```python
import numpy as np
from scipy.spatial.distance import pdist
from sklearn.ensemble import HistGradientBoostingRegressor
from sklearn.model_selection import GroupKFold, KFold, cross_val_score

rng = np.random.default_rng(35)
n = 1500   # datos de ejemplo: muestras en un área de 1 km², con ley espacialmente autocorrelacionada
xy = rng.uniform(0, 1000, (n, 2))
centros, pesos = rng.uniform(0, 1000, (150, 2)), rng.normal(0, 1, 150)
campo = (pesos * np.exp(-((xy[:, None, :] - centros[None]) ** 2).sum(-1) / (2 * 60**2))).sum(1)
ley = 0.8 + 0.3 * campo + rng.normal(0, 0.1, n)

# Variograma empírico: a qué distancia las muestras dejan de parecerse (el alcance)
i = rng.choice(n, 700, replace=False)
dist, semi = pdist(xy[i]), 0.5 * pdist(ley[i, None], "sqeuclidean")
paso = 25
centros_bin = np.arange(0, 700, paso)
gamma = np.array([semi[(dist >= a) & (dist < a + paso)].mean() for a in centros_bin])
meseta = gamma[centros_bin >= 450].mean()
alcance = centros_bin[np.argmax(gamma >= 0.95 * meseta)] + paso / 2
print(f"alcance aproximado del variograma: {alcance:.0f} m")

modelo = HistGradientBoostingRegressor(random_state=0)
r2_azar = cross_val_score(modelo, xy, ley, cv=KFold(5, shuffle=True, random_state=0), scoring="r2").mean()
print(f"validación aleatoria: R² = {r2_azar:.3f}")
r2_bloques = {}
for lado in (100, 250, 500):   # sensibilidad al tamaño del bloque
    bloque = (xy[:, 0] // lado).astype(int) * 100 + (xy[:, 1] // lado).astype(int)
    pliegues = min(5, len(np.unique(bloque)))
    r2_bloques[lado] = cross_val_score(modelo, xy, ley, cv=GroupKFold(pliegues), groups=bloque, scoring="r2").mean()
    marca = "(≥ alcance)" if lado >= alcance else "(< alcance: todavía optimista)"
    print(f"bloques de {lado} m {marca}: R² = {r2_bloques[lado]:.3f}")
assert r2_azar > r2_bloques[250] + 0.1
```

Con estos datos: validación aleatoria R² 0,80; bloques de 100 m (menores que el alcance de unos 190 m) 0,52; bloques de 250 y 500 m, R² negativo. Con solo coordenadas, extrapolar a una zona sin sondajes no funciona, y la validación aleatoria lo escondía por completo. Bloques mayores que el alcance miden cuánto se puede extrapolar a una zona sin sondajes. Si la tarea real es interpolar dentro de una malla de sondajes, el bloque imita la distancia real entre el punto a estimar y el sondaje más cercano. En evaluación de recursos se usan además la validación cruzada del kriging y los gráficos swath. Lo que no se hace es reportar la validación aleatoria como el error esperado.
