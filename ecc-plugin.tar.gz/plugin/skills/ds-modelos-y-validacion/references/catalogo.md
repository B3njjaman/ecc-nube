# Catálogo de modelos por tipo de problema

Una ficha por tipo de problema: con qué se parte, qué subir y en qué se suele fallar. Los parámetros nombrados son los que más pesan; el resto se deja por defecto hasta que el análisis de errores diga otra cosa. El código está en [recetario.md](recetario.md).

## Clasificación (binaria o multiclase)

- **Partida**: clase mayoritaria y la regla que usa hoy el negocio. Después, logística regularizada con variables escaladas y categóricas codificadas (one-hot o target encoding dentro del pipeline).
- **Siguiente**: LightGBM, XGBoost, CatBoost o `HistGradientBoostingClassifier`. En LightGBM pesan `num_leaves` (15 a 127), `learning_rate` (0,02 a 0,1, con early stopping que decide `n_estimators`), `min_child_samples` (subirlo con datos ruidosos), `feature_fraction` y `bagging_fraction` con `bagging_freq`, y `lambda_l2`. CatBoost se luce con muchas categóricas de alta cardinalidad.
- **Desbalance**: métrica PR-AUC y umbral por costo antes que `scale_pos_weight` o re-muestrear, porque estos dos descalibran las probabilidades.
- **Falla típica**: celebrar la ROC-AUC con positivos raros, umbral 0,5, variables posteriores al evento.

## Regresión

- **Partida**: media o mediana por segmento. Después, lineal con splines (`SplineTransformer`) para la curvatura e interacciones elegidas a mano.
- **Siguiente**: boosting. Se elige la pérdida según el costo: L2 (`regression`) si los errores grandes pesan más; L1 o Huber si hay extremos que no deben dominar; `quantile` para planificar con un percentil; `tweedie` para montos con muchos ceros y cola larga (consumo, siniestros, compras); `poisson` para conteos.
- **Objetivo sesgado**: modelar el log y, al volver, corregir el sesgo de retransformar (`exp(pred)` estima la mediana, no la media).
- **Falla típica**: MAPE con valores cerca de cero, extrapolar fuera del rango visto (los árboles no extrapolan).

## Conteos y tasas

- **Partida**: tasa por segmento (eventos / exposición).
- **Modelo**: GLM de Poisson con la exposición como offset (`exposure=` en statsmodels). Si la dispersión de Pearson (χ² / gl) pasa de ~1,5, binomial negativa. Con exceso de ceros que no explica la binomial negativa, modelos zero-inflated.
- **Con boosting**: `objective="poisson"`, con la exposición como `init_score=np.log(exposicion)`, o modelando la tasa con `weight=exposicion`. Con `init_score`, `predict` no suma el offset: devuelve la tasa por unidad de exposición, que se multiplica por la exposición.
- **Falla típica**: comparar conteos crudos entre equipos con distintas horas de operación.

## Series de tiempo y pronóstico

- **Partida**: ingenuo (último valor) e ingenuo estacional (el mismo período del ciclo anterior). Son la vara del MASE.
- **Una o pocas series**: ETS (`ExponentialSmoothing` o `ETSModel`) y SARIMAX, con regresores externos (precio, feriados de Chile, paradas de planta). `statsforecast` (AutoETS, AutoARIMA) ajusta miles de series rápido.
- **Muchas series relacionadas** (SKUs, equipos, sucursales): un modelo global de boosting con rezagos, medias móviles, calendario e ID de la serie (`mlforecast` lo arma). Si las series tienen jerarquía (SKU → familia → total), se concilian los pronósticos.
- **Demanda intermitente** (repuestos que se piden de vez en cuando): Croston o TSB, no ETS.
- **Modelos de base preentrenados** (Chronos, TimesFM, Moirai): candidatos sin entrenamiento; se comparan con el ingenuo estacional en el mismo backtesting.
- **Validación**: origen móvil con el horizonte real; rezagos, medias móviles e hiperparámetros, solo con el pasado de cada origen. Se reporta la cobertura de los intervalos.
- **Falla típica**: partir al azar, usar rezagos menores que el horizonte, olvidar quiebres (pandemia, cambio de proceso) que hacen que el pasado lejano no sirva.

## Tiempo hasta un evento (supervivencia)

- **Cuándo**: hay censura, es decir, casos en que el evento todavía no ocurre o se dejó de observar (equipos en servicio, clientes que siguen activos).
- **Partida**: Kaplan-Meier por grupo y log-rank.
- **Modelo**: Cox (`CoxPHFitter`, con `penalizer` si hay muchas variables). Se revisa el supuesto de riesgos proporcionales (`check_assumptions`); si falla, estratificar por la variable que lo rompe, agregar su interacción con el tiempo (partiendo el seguimiento en episodios, con `CoxTimeVaryingFitter`) o pasar a un modelo AFT (`WeibullAFTFitter`), que además da tiempos esperados.
- **No lineal**: bosques de supervivencia aleatorios (`scikit-survival`).
- **Riesgos competitivos**: si otro evento impide el que interesa (el equipo se da de baja antes de fallar), Aalen-Johansen o Fine-Gray, no Kaplan-Meier.
- **Métricas**: C-index (de Harrell o de Uno), Brier integrado y AUC dependiente del tiempo.
- **Falla típica**: botar a los censurados o tratarlos como "no ocurrió"; usar variables medidas después del tiempo cero; suponer censura no informativa cuando no lo es (se retiran justo los equipos que andaban mal); olvidar el truncamiento por la izquierda, es decir, equipos que entran al registro ya en servicio (se declara la edad de entrada: `entry_col` en `CoxPHFitter`, `entry` en `KaplanMeierFitter`).

## Anomalías

- **Partida**: umbral robusto (mediana ± k·MAD) por régimen de operación (carga, producto, turno).
- **Comportamiento normal**: se modela la señal esperada según las condiciones de operación y se vigila el residuo. Funciona muy bien en sensores industriales porque separa "opera distinto" de "algo anda mal".
- **Multivariado**: Isolation Forest o LOF. El corte se fija por el cuantil del puntaje en un período normal y por cuántas alertas se pueden atender, no con `contamination` a ciegas.
- **Cambios de régimen**: detección de puntos de cambio (`ruptures`, método PELT). Patrones raros en subsecuencias: matrix profile (`stumpy`).
- **Autoencoders**: solo con mucho dato y después de que lo anterior se quedó corto.
- **Evaluación**: por eventos (fallas avisadas con anticipación suficiente, falsas alarmas por semana), con las fallas pasadas y validación temporal.
- **Falla típica**: evaluar punto por punto, ignorar el régimen, etiquetas de falla con la fecha de la orden de trabajo y no la del inicio real.

## Segmentación

- **Partida**: reglas que el negocio entiende (RFM, cuartiles de consumo).
- **Modelo**: k-means sobre variables estandarizadas (`n_init` ≥ 10), con k elegido por silueta, estabilidad entre remuestreos y utilidad. GMM si los grupos son elípticos o se quiere pertenencia blanda (k por BIC). HDBSCAN (`sklearn.cluster.HDBSCAN`) si hay ruido y formas raras. Con variables mixtas, distancia de Gower o k-prototypes.
- **Descripción**: cada segmento se describe con las variables originales y lleva una acción asociada. PCA o UMAP sirven para mirar, no para decidir.
- **Falla típica**: no escalar, elegir k por el codo sin más, segmentos que cambian con cada semilla, y "probar" que los segmentos difieren en las mismas variables con que se formaron (siempre van a diferir: es usar dos veces los mismos datos).

## Texto

- **Partida**: reglas de palabras clave.
- **Modelo**: TF-IDF con n-gramas + logística o SVM lineal: rápido, fuerte y explicable. Después, embeddings multilingües (sentence-transformers) + logística. Ajuste fino de un transformer solo con miles de ejemplos etiquetados.
- **Etiquetar con un LLM**: sirve para partir, con una muestra revisada a mano para medir su error. Los textos de clientes o de la empresa no se mandan a un servicio externo sin el OK de Benja.
- **Falla típica**: etiquetas inconsistentes entre personas (medir el acuerdo entre etiquetadores), duplicados entre entrenamiento y validación.

## Datos espaciales (leyes, sondajes, bloques)

- **Partida**: promedio por zona o vecino más cercano.
- **Modelo**: kriging (con variograma) como referencia geoestadística; boosting con coordenadas y variables geológicas (litología, alteración, profundidad).
- **Validación**: por bloques espaciales mayores que el alcance del variograma si la tarea es estimar zonas sin sondajes, o del tamaño de la distancia real al sondaje más cercano si es interpolar dentro de una malla. En el recetario, con solo coordenadas, la validación aleatoria da R² 0,80 y la de bloques mayores que el alcance da R² negativo: extrapolar con coordenadas no funciona, y la validación aleatoria lo escondía.
- **Falla típica**: muestras del mismo sondaje a ambos lados de la partición.

## Ranking y recomendación

- **Partida**: lo más popular (global o por segmento).
- **Modelo**: vecinos por ítem o factorización implícita (ALS); boosting para ranking (`objective="lambdarank"`) con variables de usuario, ítem y contexto.
- **Validación**: por tiempo (entrenar con el pasado, medir en lo que vino después); métricas @k (NDCG, recall, MAP); usuarios nuevos aparte.

## Pocos datos (menos de ~1.000 filas)

- Lineal regularizado, pocas variables elegidas con criterio, CV repetida y anidada.
- TabPFN rinde muy bien en tablas chicas sin ajustar hiperparámetros; se compara contra la logística en la misma validación.
- Modelos bayesianos si hay información previa que se pueda declarar.

## Aprendizaje por refuerzo (elegir el algoritmo)

- **Acciones discretas**: DQN y variantes, o PPO.
- **Acciones continuas**: SAC o TD3 si cada paso de simulación es caro (reusan la experiencia); PPO si la simulación es barata y paralelizable.
- **Solo datos históricos, sin simulador**: clonación de comportamiento como base, y RL offline (CQL, IQL). La evaluación offline es difícil y se dice.
- **Implementaciones de referencia**: Stable-Baselines3 o CleanRL, para que la línea base sea la conocida y no una versión propia con errores.
- **Evaluación**: sección 11 de la skill y bloque 11 del recetario.
