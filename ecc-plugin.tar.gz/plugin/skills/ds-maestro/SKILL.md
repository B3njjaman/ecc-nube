---
name: ds-maestro
description: "Ciclo completo de data science, de un problema a una conclusión que aguanta revisión: encuadra la decisión y el tipo de pregunta (descriptiva, exploratoria, comparativa, predictiva, causal o de decisión secuencial), revisa los datos y la fuga, registra las hipótesis con sus rivales antes de ver resultados, elige con un mapa problema → hipótesis → verificación → modelo, revisa el análisis como abogado del diablo y escribe el informe con magnitud e incertidumbre. Es la puerta de entrada y reparte a ds-hipotesis-y-pruebas, ds-modelos-y-validacion y ds-causalidad. Úsala cuando Benja traiga un problema o un dataset y pregunte qué hacer, qué hipótesis plantear, qué prueba o qué modelo usar, cómo analizar unos datos o cómo revisar un análisis ajeno: negocio, industria o minería, investigación y la tesis de RL."
metadata:
  origin: "ecc-benja; ideas de hypothesis-generation, statistical-analysis y exploratory-data-analysis de K-Dense-AI/claude-scientific-skills (MIT, a25cf9ec00e2) y de mle-workflow de affaan-m/ECC (b38be6a7)"
---

# Data science de punta a punta

Objetivo: que cada análisis termine en una respuesta que aguante una revisión: qué se preguntó, qué se supuso, qué se verificó, cuánto vale el efecto, con qué incertidumbre y qué no se sabe. El modelo es una pieza; lo que se entrega es la respuesta a una pregunta que mueve una decisión.

Skills hermanas: `ds-hipotesis-y-pruebas` (hipótesis y pruebas estadísticas), `ds-modelos-y-validacion` (qué modelo y cómo validarlo), `ds-causalidad` (efectos causales). Casos resueltos de punta a punta en [references/casos.md](references/casos.md); plantillas de cada archivo en [references/plantillas.md](references/plantillas.md).

## Reglas

- **La pregunta antes que el modelo.** No se toca un dato sin la ficha del problema (fase 1). Un modelo que no cambia ninguna decisión es un pasatiempo.
- **Asociar, predecir y causar son tres afirmaciones distintas**, con evidencia distinta. Se declara el tipo de pregunta y el informe usa el verbo que la evidencia permite: "se asocia con", "predice", "causa".
- **Lo confirmatorio se decide antes de ver el resultado.** Hipótesis, métrica principal, prueba, umbral y tamaño de muestra quedan escritos y fechados antes de correr el análisis. Lo que aparece mirando los datos se rotula `EXPLORATORIO` y se confirma con datos nuevos o con un conjunto reservado.
- **Siempre contra una base.** Ninguna mejora se celebra sin compararla con una base tonta (media, último valor, ingenuo estacional, clase mayoritaria, la regla que usa hoy el negocio) y, si existe, con lo que está en producción.
- **Magnitud e intervalo, no solo p.** Todo resultado lleva la estimación del efecto, su intervalo y si supera el efecto mínimo que importa. "Significativo" sin magnitud no se reporta, y "no significativo" no significa "no hay efecto".
- **El conjunto de prueba se toca una vez**, para el número final. Se separa al principio, respetando el tiempo y los grupos.
- **Primero en datos simulados.** Antes de creerle a un método en los datos reales, se corre en datos simulados donde la respuesta se conoce; si no la recupera, el problema es el método o el código, no el mundo. Los recetarios de las skills hermanas traen ese chequeo.
- **Números que se pueden rehacer.** Semilla fija, versión de los datos (fecha de corte o hash), versiones de las librerías y el script que produce cada número del informe. Un número que no se puede regenerar no va al informe.
- **Cada conclusión con su evidencia** (tabla, gráfico o salida de un script). Lo no comprobado se marca `SUPUESTO`.
- **Los datos de clientes, de la empresa o personales no salen del PC** sin el OK de Benja: no se pegan en búsquedas web, servicios externos ni otro modelo. En el informe van agregados.

## Archivos

```
analisis/<tema>/
  FICHA.md        fase 1: decisión, tipo de pregunta, unidad, métrica, efecto mínimo relevante
  DATOS.md        fase 2: origen, corte, calidad, variables prohibidas por fuga, partición
  HIPOTESIS.md    fase 3: registro fechado, escrito antes de ver resultados
  src/            el código que produce cada número (scripts o notebooks limpios)
  INFORME.md      fase 7
```

En un repo existente (la tesis, un proyecto de cliente) se usa su carpeta de docs con los mismos archivos.

En la cascada: encuadre, hipótesis y conclusiones los decide la sesión, porque dependen de la conversación con Benja. Los perfiles de datos grandes y los entrenamientos largos los corre `ecc:ejecutor`, que devuelve las cifras literales; los datos crudos no se leen enteros en el contexto, se resumen con scripts. Los pipelines los implementa `ecc:constructor` con test primero (`python-testing`). El código lo revisa `ecc:python-reviewer`, y `ecc:mle-reviewer` si el modelo va a producción (ahí sigue `mle-workflow`). Una conclusión importante pasa además por Codex como segunda opinión.

## Fases

### 1. Encuadre → `FICHA.md`

1. **La decisión.** Qué acción cambia según la respuesta, quién decide y cuánto cuesta equivocarse en cada dirección (falso positivo contra falso negativo, lanzar algo que no sirve contra no lanzar algo que sí).
2. **El tipo de pregunta:**

| Tipo | Pregunta típica | Qué se entrega | Dónde sigue |
|---|---|---|---|
| Descriptiva | ¿Cuánto? ¿Cómo se distribuye? | estimación con intervalo, por segmento | aquí + intervalos de `ds-hipotesis-y-pruebas` |
| Exploratoria | ¿Qué patrones o grupos hay? | hipótesis nuevas, nunca conclusiones | fase 2 + segmentación de `ds-modelos-y-validacion` |
| Comparativa | ¿A difiere de B? ¿Hay relación? | prueba, tamaño del efecto e intervalo | `ds-hipotesis-y-pruebas` |
| Predictiva | ¿Qué va a pasar con este caso? | modelo y error esperado fuera de muestra | `ds-modelos-y-validacion` |
| Causal | ¿Qué pasa si hago X? ¿X causó Y? | efecto con su diseño y sus supuestos | `ds-causalidad` |
| Decisión secuencial | ¿Qué acción conviene en cada estado? | política evaluada en varias semillas | RL en `ds-modelos-y-validacion` |

   La trampa más común: "¿qué factores influyen en el churn?" suena descriptiva, pero casi siempre es causal disfrazada (se quiere saber qué palanca mover). La prueba es preguntar: "si mañana cambiamos X, ¿esperas que cambie Y?". Si la respuesta es sí, la pregunta es causal, y un ranking de importancia de variables no la responde.
3. **La unidad.** De análisis (cliente, transacción, equipo, semilla, día) y de independencia (lo que se aleatorizó o muestreó). Tratar observaciones dependientes como independientes (diez mediciones del mismo equipo, mil episodios de una sola semilla) infla la confianza: es la pseudorreplicación, y explica muchos resultados que no se repiten.
4. **Población y horizonte.** A quién se quiere generalizar y si los datos la representan (¿solo los clientes que respondieron?, ¿solo los equipos que no se dieron de baja?).
5. **Métrica principal** (una sola), métricas de resguardo y el **efecto mínimo relevante**: el cambio más chico que cambiaría la decisión. Sin él no se puede calcular potencia ni afirmar que "no hay efecto".
6. **Restricciones.** Plazo, qué datos existen en el momento de decidir, latencia, si el modelo tiene que ser explicable, quién lo va a mantener.

Termina cuando la ficha dice qué se hará con cada resultado posible: "si el aumento es de al menos 2 pp, se lanza; si el intervalo no descarta menos de 2 pp, se alarga la prueba; si es negativo, se descarta".

### 2. Datos → `DATOS.md`

1. **Cómo nacen los datos.** Quién o qué los registra, cuándo y qué se pierde por el camino. Fecha de corte y versión o hash del archivo.
2. **Calidad.** Tipos, rangos imposibles, duplicados, claves, unidades, zonas horarias, cambios de definición en el tiempo (un campo que cambió de significado en 2024). Faltantes: cuántos y por qué. Imputar con la media o la mediana encoge la varianza y debilita las asociaciones aunque los faltantes sean al azar; y si el faltante depende del valor que falta (el sensor se apaga justo cuando la temperatura sube), además sesga. En modelos predictivos se imputa con un indicador de faltante (`add_indicator=True`); para inferencia, imputación múltiple.
3. **Perfil.** Distribución de cada variable y del objetivo, desbalance de clases, valores extremos (¿error o la señal que importa?), cardinalidad de las categóricas y correlaciones fuertes. Gráficos con la skill `dataviz`.
4. **Auditoría de fuga.** Por cada variable: ¿se conoce en el momento en que se toma la decisión? Se prohíben las posteriores al evento, los IDs o códigos que delatan el objetivo y los agregados calculados con todo el período. El barrido automático está en `ds-modelos-y-validacion`.
5. **Partición.** El conjunto de prueba se aparta ahora, por tiempo o por grupo si los datos lo piden, antes de explorar a fondo, para que la exploración no lo contamine.

Perfil mínimo con pandas:

```python
import numpy as np
import pandas as pd

rng = np.random.default_rng(0)
df = pd.DataFrame({  # datos de ejemplo: reemplazar por pd.read_parquet(...) o pd.read_csv(...)
    "planta": rng.choice(["A", "B", None], 500),
    "toneladas": rng.gamma(5, 200, 500),
    "falla": rng.random(500) < 0.08,
})
df.loc[rng.choice(500, 40, replace=False), "toneladas"] = np.nan

perfil = pd.DataFrame({
    "tipo": df.dtypes.astype(str),
    "faltantes_%": df.isna().mean().mul(100).round(1),
    "unicos": df.nunique(),
})
print(perfil.sort_values("faltantes_%", ascending=False))
print("filas duplicadas:", df.duplicated().sum())
print(df.describe(include="all").T)
print("tasa del objetivo:", df["falla"].mean().round(3))
```

Termina cuando se sabe qué datos hay, qué tan buenos son, qué variables quedan prohibidas por fuga y el conjunto de prueba está apartado.

### 3. Hipótesis → `HIPOTESIS.md` (antes de ver resultados)

Por cada hipótesis confirmatoria (de una a tres; el resto es exploratorio):

- la afirmación en lenguaje del negocio o de la tesis;
- el estimando: el número exacto que se va a estimar, en qué población, unidad y período;
- H0 y H1, la dirección, la prueba, el nivel α y el efecto mínimo relevante;
- la predicción: qué se vería si es cierta y qué la refutaría;
- las explicaciones rivales (azar, medición, confusor, selección, causalidad inversa, regresión a la media, estacionalidad, fuga) y cómo se va a descartar cada una.

Cómo escribirlas bien, y la lista completa de rivales: `ds-hipotesis-y-pruebas`.

Termina cuando cada hipótesis confirmatoria tiene su prueba, su umbral y su criterio de refutación escritos y fechados, antes de correr nada.

### 4. Mapa: del problema al método

| Si el problema es… | Hipótesis que se pone a prueba | Cómo se verifica | Modelos: base → candidatos | Sigue en |
|---|---|---|---|---|
| Comparar dos grupos en una variable continua (ticket medio, rendimiento de dos turnos) | la diferencia de medias es ≥ δ | Welch con IC; bootstrap si hay colas pesadas; ajustar por la covariable previa (CUPED o ANCOVA) | diferencia de medias → regresión con covariables | pruebas |
| Comparar proporciones (conversión, tasa de defectos) | p_B − p_A ≥ δ | IC de la diferencia y z de dos proporciones; Fisher con pocos casos; en A/B, SRM primero | diferencia de proporciones → logística con covariables | pruebas |
| Comparar más de dos grupos | alguna media difiere, y cuáles | ANOVA de Welch y Games-Howell; modelo mixto si hay medidas repetidas | medias por grupo → OLS o modelo mixto | pruebas |
| Relación entre dos variables | asociación monótona o lineal distinta de cero | Spearman o Pearson con IC, después de graficar; buscar confusores | correlación → regresión | pruebas |
| Explicar una respuesta con varios factores (paper, encuesta) | el coeficiente de X ≠ 0, controlando Z | OLS o GLM con errores robustos o agrupados; diagnóstico de residuos | OLS → GLM, mixto o GEE | pruebas; causalidad si se quiere un efecto |
| Conteos o tasas (fallas por mes, reclamos por 1.000 clientes) | la razón de tasas ≠ 1 | GLM de Poisson con exposición; binomial negativa si hay sobredispersión | tasa por grupo → Poisson o binomial negativa | pruebas |
| Tiempo hasta un evento con censura (vida de un componente, tiempo hasta el churn) | un grupo dura menos (HR > 1) | log-rank; Cox con chequeo de riesgos proporcionales | Kaplan-Meier → Cox, Weibull, bosques de supervivencia | modelos |
| Clasificar casos (churn, falla en 7 días, fraude) | las variables separan las clases mejor que la base | PR-AUC o costo fuera de muestra contra la base, con IC; permutar el objetivo | clase mayoritaria o regla → logística regularizada → boosting | modelos |
| Predecir un número (demanda, ley de cobre, consumo) | el modelo baja el error de la base | MAE o RMSE fuera de muestra, con validación que respete tiempo y grupos | media o regla → lineal → boosting | modelos |
| Pronosticar una serie (demanda semanal, tonelaje) | hay tendencia o estacionalidad aprovechable | backtesting con origen móvil contra el ingenuo estacional; MASE; cobertura de intervalos | ingenuo estacional → ETS o SARIMAX → boosting con rezagos | modelos |
| Detectar anomalías (sensores, transacciones) | antes de una falla la señal se desvía de lo normal para su régimen | evaluación por eventos pasados: fallas anticipadas y alertas por semana | umbral robusto por régimen → residuos de un modelo de comportamiento normal → Isolation Forest | modelos |
| Segmentar (clientes, equipos) | hay grupos estables y accionables | estabilidad entre remuestreos, silueta y utilidad para la decisión | reglas (RFM) → k-means estandarizado → GMM o HDBSCAN | modelos |
| Clasificar texto (reclamos, órdenes de trabajo) | el texto predice la categoría mejor que la base | F1 macro con CV estratificada; errores revisados a mano | palabras clave → TF-IDF + logística → embeddings + logística | modelos |
| ¿Qué pasa si hago X? ¿X causó Y? | el efecto de X sobre Y ≠ 0 o ≥ δ | experimento si se puede; si no, el diseño que corresponde a cómo se asignó X, con sus pruebas de supuestos | lo decide el diseño, no el modelo | causalidad |
| ¿A quién le aplico X? (campaña de retención) | el efecto de X varía según el cliente | experimento + modelo de uplift; nunca "a los de mayor riesgo" sin más | T-learner o X-learner | causalidad |
| Comparar algoritmos o configuraciones de RL | A supera a B en retorno normalizado | IQM con IC bootstrap estratificado sobre ≥ 10 semillas, perfiles de desempeño y probabilidad de mejora | el algoritmo de referencia, con el mismo presupuesto de ajuste | modelos |

Si el problema no calza en ninguna fila, se descompone: casi siempre es una combinación (un pronóstico que alimenta una decisión, una segmentación que se valida con un experimento).

### 5. Verificar y modelar

Con la skill hermana que indica el mapa, en este orden: la base primero; después un peldaño de complejidad a la vez, y solo cuando el análisis de errores muestra qué arregla ese peldaño. Cada número que va al informe sale de un script en `src/`.

### 6. Revisión del análisis: abogado del diablo

Antes de escribir el informe, el análisis se ataca a sí mismo:

- **Sensibilidad.** ¿El resultado sobrevive a otra semilla, otra ventana de tiempo, quitar los extremos, otro segmento y otra especificación razonable? Si cambia de signo con decisiones arbitrarias, no es un resultado.
- **Placebo.** Con el objetivo barajado, el procedimiento completo (selección de variables y preprocesamiento incluidos, con validación por grupos si hay entidades repetidas) debe caer al nivel de la base; si no cae, el procedimiento filtra información. No detecta variables posteriores al evento, porque al barajar también pierden su relación con el objetivo: esas se encuentran con la auditoría de la fase 2. Con una fecha de intervención falsa, el "efecto" debe desaparecer.
- **Jardín de caminos.** ¿Cuántas variantes, segmentos y métricas se probaron? Se reportan todas, no solo la que salió.
- **Paradojas.** Simpson (el efecto se invierte por segmento), regresión a la media (se eligieron los peores y "mejoraron" solos), supervivencia (solo se ve lo que sobrevivió) y selección (quién llega a los datos).
- **Magnitud.** ¿El efecto es grande en unidades que le importan a quien decide, o solo distinto de cero porque hay muchos datos?

Prueba de permutación con scikit-learn, para saber si el modelo le gana al azar (el placebo que encuentra fuga del procedimiento está en la sección 2 del recetario de `ds-modelos-y-validacion`):

```python
from sklearn.datasets import make_classification
from sklearn.linear_model import LogisticRegression
from sklearn.model_selection import StratifiedKFold, permutation_test_score

X, y = make_classification(n_samples=600, n_features=8, n_informative=3, random_state=0)  # datos de ejemplo
cv = StratifiedKFold(5, shuffle=True, random_state=0)   # con entidades repetidas: StratifiedGroupKFold y groups=
puntaje, puntajes_barajados, p = permutation_test_score(
    LogisticRegression(max_iter=1000), X, y, cv=cv, scoring="roc_auc", n_permutations=200, random_state=0
)
print(f"AUC real {puntaje:.3f}; con el objetivo barajado {puntajes_barajados.mean():.3f}; p = {p:.4f}")
```

Termina cuando cada amenaza tiene una respuesta (descartada con evidencia, o declarada como limitación).

### 7. Informe → `INFORME.md`

1. **La respuesta en una frase**, con magnitud e incertidumbre: "B sube la conversión en 1,2 pp (IC 95 %: 0,4 a 2,0)".
2. **Qué se recomienda hacer** y con qué nivel de confianza, contra la regla de decisión de la ficha.
3. **La evidencia**: tabla o gráfico principal, la base contra la que se comparó y el tamaño de muestra.
4. **Supuestos y amenazas**, con lo que se hizo para descartar cada una; lo no descartado, como limitación.
5. **Lo exploratorio**, separado y rotulado.
6. **Cómo reproducirlo**: comando, versión de datos, semilla y versiones de las librerías.

El verbo lo pone el diseño: "se asocia" (observacional sin diseño causal), "predice" (validación fuera de muestra) y "causa" o "produce" (experimento o diseño causal con sus supuestos probados). Si el informe va a un tercero (cliente, comité, profesor guía), se escribe en prosa de persona, sin jerga innecesaria, y se pasa por `hzblj-skills:unslop`.

## Entrega

Resumen para Benja: la respuesta en una frase con su intervalo, la decisión que sugiere, las verificaciones que se corrieron con sus cifras, las amenazas que siguen abiertas y lo que no se verificó.
