# Plantillas

Se copian a `analisis/<tema>/`. Lo que no se sabe todavía se deja escrito como `PENDIENTE`, nunca en blanco.

## FICHA.md

```markdown
# Ficha: <tema>

Fecha: <AAAA-MM-DD> · Responsable de la decisión: <quién>

## Decisión
- Qué acción cambia según el resultado:
- Costo de equivocarse hacia un lado (falso positivo, lanzar algo que no sirve):
- Costo de equivocarse hacia el otro (falso negativo, no lanzar algo que sí sirve):

## Pregunta
- En una frase:
- Tipo: descriptiva | exploratoria | comparativa | predictiva | causal | decisión secuencial
- Si es causal: tratamiento, resultado, población, ventana y contraste (ATE, ATT o CATE)

## Unidad y población
- Unidad de análisis:
- Unidad de independencia (lo que se aleatorizó o muestreó):
- Población a la que se quiere generalizar, y si los datos la representan:

## Métricas
- Principal (una):
- Resguardos:
- Efecto mínimo relevante (δ) y de dónde sale:

## Regla de decisión
- Si el resultado es …, entonces …
- Si el intervalo no permite decidir, entonces …

## Restricciones
- Plazo, datos disponibles al momento de decidir, latencia, explicabilidad, quién lo mantiene:
```

## DATOS.md

```markdown
# Datos: <tema>

## Origen
- Fuente, quién o qué la registra, cómo se extrajo:
- Fecha de corte y versión o hash:
- Permisos y confidencialidad (¿puede salir del PC?):

## Calidad
| Variable | Tipo | Faltantes % | Rango o valores | Problemas | Decisión |
|---|---|---|---|---|---|

- Duplicados:
- Cambios de definición en el tiempo:
- Por qué faltan los faltantes (¿depende del valor?):

## Fuga
| Variable | ¿Se conoce al momento de decidir? | Decisión |
|---|---|---|

## Partición
- Esquema (aleatorio, por grupos, temporal, espacial) y por qué:
- Conjunto de prueba apartado el: <fecha>, con <n> filas y <k> unidades
```

## HIPOTESIS.md

Se escribe y se fecha **antes** de correr el análisis confirmatorio. Si después cambia algo, se agrega una línea en "Desviaciones del plan" con la fecha y el motivo; lo de arriba no se edita.

```markdown
# Registro de hipótesis: <tema>

Fecha de registro: <AAAA-MM-DD> · Datos todavía no analizados: sí | no (explicar)

## H1: <afirmación en lenguaje del negocio o de la tesis>
- Estimando:
- H0 / H1 y dirección:
- Prueba o modelo, y nivel α:
- Efecto mínimo relevante:
- Tamaño de muestra o semillas, y potencia (o efecto mínimo detectable):
- Predicción si es cierta:
- Qué resultado la refuta:
- Rivales y cómo se descarta cada uno:
  - <rival>: <cómo>

## Familia y corrección
- Hipótesis confirmatorias de la familia:
- Corrección: Holm | Benjamini-Hochberg | ninguna (justificar)

## Exploratorio
- Lo que se va a mirar sin hipótesis previa (se reporta rotulado como EXPLORATORIO):

## Desviaciones del plan
- <fecha>: <qué cambió y por qué>
```

## INFORME.md

```markdown
# <Pregunta en una línea>

## Respuesta
<Una frase con la magnitud y el intervalo, y el verbo que permite el diseño.>

## Recomendación
<Qué hacer, contra la regla de decisión de la ficha, y con qué confianza.>

## Evidencia
- Comparación principal (tabla o figura), contra la base:
- n por grupo o unidades, período y datos usados:
- Verificaciones corridas y su resultado (supuestos, placebos, sensibilidad):

## Supuestos y amenazas
| Amenaza | Qué se hizo | Estado |
|---|---|---|
| | | descartada / limitación |

## Exploratorio
<Hallazgos no planificados, rotulados como tales.>

## Qué no se sabe
<Lo que este análisis no puede responder, y qué haría falta para responderlo.>

## Reproducir
- Comando:
- Datos (versión o hash):
- Semilla:
- Versiones de las librerías:
```
