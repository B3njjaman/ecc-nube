# Casos resueltos de punta a punta

Cuatro problemas típicos de Benja, recorridos con las fases de `ds-maestro`. Las cifras de los informes son de ejemplo, para mostrar la forma de la frase. El código de cada paso está en los recetarios de las skills hermanas (se indica el bloque).

## 1. Tesis de RL: ¿mi variante supera a PPO?

**Ficha.** Decisión: si la tesis puede afirmar que la variante mejora a PPO. Tipo: comparativa entre algoritmos. Unidad: la corrida completa (semilla × entorno), no el episodio. Población: los 5 entornos evaluados; generalizar a otros entornos queda fuera. Métrica principal: puntaje normalizado al final del presupuesto de pasos, agregado con IQM. Efecto mínimo relevante: 0,05 en IQM normalizado (lo fija Benja con su profesor guía).

**Hipótesis (antes de correr la tanda final).** H1: IQM(variante) − IQM(PPO) > 0, y P(variante > PPO) > 0,5, con un IC 95 % por bootstrap estratificado que excluya 0,5. Rivales:
- más ajuste de hiperparámetros para la variante que para PPO, que se descarta con el mismo presupuesto y protocolo para ambos;
- diferencias de implementación (normalización de observaciones, versión de la librería), que se descartan con la misma base de código y PPO de referencia (Stable-Baselines3 o CleanRL) sin tocar;
- varianza entre semillas, que se descarta con 10 o más semillas por algoritmo y entorno;
- una mejora que existe en un solo entorno, que se descarta reportando el agregado y cada entorno.

**Verificación.**
1. Piloto con 5 semillas para estimar la varianza.
2. Efecto mínimo detectable con las semillas que alcanza el cómputo (`ds-hipotesis-y-pruebas`, bloque 11 del recetario).
3. La tanda final, con semillas de evaluación distintas a las de entrenamiento y el punto de control fijado antes (el final).
4. IQM con IC, probabilidad de mejora y perfiles de desempeño (`ds-modelos-y-validacion`, bloque 11).

Todas las semillas se reportan. Si se compara contra más de un algoritmo, la familia de comparaciones se corrige con Holm.

**Trampas.** El máximo de la curva de aprendizaje, curvas suavizadas que esconden la varianza, la desviación estándar de una sola corrida usada como incertidumbre, ajustar con las semillas de evaluación y descartar semillas "que divergieron".

**Informe.**
> En 5 entornos y 10 semillas por algoritmo, el IQM normalizado de la variante fue 0,62 y el de PPO 0,55. La diferencia es 0,07 (IC 95 % por bootstrap estratificado: 0,01 a 0,14): positiva, pero el intervalo no descarta que sea menor al mínimo relevante de 0,05. La probabilidad de que una corrida de la variante supere a una de PPO es 0,64 (0,55 a 0,72). EXPLORATORIO: la mejora parece concentrarse en 3 de los 5 entornos (figura 4).

## 2. Negocio: prueba A/B del checkout y campaña contra el churn

### 2a. Prueba A/B

**Ficha.** Decisión: lanzar el checkout nuevo. Métrica principal: compra a 7 días por usuario. Resguardos: devoluciones, tiempo de carga y reclamos. δ = 1 pp. Unidad de aleatorización y de análisis: el usuario.

**Hipótesis.** H1: p_B − p_A > 0, con 80 % de potencia si la diferencia real es δ = 1 pp. Demostrar que el efecto es de al menos 1 pp (superioridad con margen) pediría bastante más muestra; en cambio, la ficha fija la regla: si el límite inferior del IC es ≥ 1 pp, se lanza; si queda entre 0 y 1 pp, se lanza porque mantener el checkout nuevo no cuesta más que el actual, y se vuelve a medir en un mes; si el IC incluye el 0, no se lanza. Rivales: asignación rota (SRM), efecto novedad, una campaña de marketing en paralelo (afecta a los dos grupos por igual si la aleatorización está bien), métricas por sesión con errores por sesión.

**Verificación.**
1. Potencia antes de lanzar: con 11 % de base y δ = 1 pp, unos 16.000 usuarios por grupo (bloque 11 del recetario de pruebas). Duración: dos semanas completas como mínimo.
2. No se mira el resultado antes de la fecha.
3. Al cerrar: SRM; diferencia con IC ajustada por CUPED (la compra del mes previo); resguardos; efecto por semana (bloque 13).

**Informe.**
> El checkout nuevo subió la compra a 7 días en 1,2 pp (IC 95 %: 0,7 a 1,7; ajustado por CUPED). El efecto es positivo, pero el intervalo no descarta que sea menor al mínimo de 1 pp. Como mantenerlo no cuesta más que el checkout actual, la regla de la ficha dice lanzarlo y volver a medir en un mes. No hubo cambios en devoluciones ni en tiempo de carga.

### 2b. Campaña contra el churn

**La trampa del encuadre.** "¿A quién llamamos?" parece predictivo (quién se va a ir), pero es causal (a quién le cambia algo la llamada). Los de mayor riesgo pueden ser casos perdidos.

**Camino.**
1. Un modelo de riesgo de churn, con validación por cliente y por tiempo y la PR-AUC contra la base (`ds-modelos-y-validacion`, bloque 1). Sirve para entender, no para decidir a quién llamar.
2. Un experimento: ofrecer al azar a una muestra.
3. Un modelo de uplift con esos datos (`ds-causalidad`, bloque 8).
4. La validación de dirigir por uplift contra dirigir por riesgo y contra el azar, con datos experimentales reservados.

**Informe.**
> Dirigir la oferta al 20 % con mayor uplift estimado evita unas 5 veces más bajas que dirigirla al 20 % de mayor riesgo, en el experimento reservado (IC por bootstrap en la tabla 2).

**Segmentación de clientes**, si se pide. Se parte con RFM. Después, k-means con silueta y estabilidad (bloque 9 del recetario de modelos). Cada segmento tiene que llevar una acción distinta, y si no, no es un segmento útil.

## 3. Industria o minería: anticipar fallas de un molino

**Ficha.** Decisión: inspeccionar o detener el equipo ante una alerta. Costos: una inspección innecesaria contra horas de detención no planificada. Capacidad: el equipo de mantenimiento atiende como mucho 2 alertas por semana. Unidad: equipo × ventana de tiempo. Métrica principal: fallas avisadas con al menos 6 h de anticipación, con 2 falsas alarmas por semana como máximo.

**Datos (lo que suele aparecer).**
- Pocas fallas (eventos raros).
- La fecha de la orden de trabajo no es la del inicio de la falla: se reconstruye con mantenimiento.
- Regímenes de operación (carga, dureza del mineral), sensores que se recalibran después de cada mantención, huecos de datos y zonas horarias.
- Los datos no salen del entorno de la empresa sin el OK de Benja.

**Hipótesis.** Antes de una falla, la vibración se desvía de lo esperado para la carga del momento. Rivales:
- un cambio de régimen (más carga o mineral más duro), que se descarta modelando el comportamiento normal según la carga;
- la deriva del sensor después de una mantención, que se descarta con el registro de mantenciones;
- etiquetas de falla mal fechadas, que se descartan con la revisión con mantenimiento.

**Modelos.**
1. Base: umbral fijo del fabricante.
2. El residuo robusto de un modelo de comportamiento normal (vibración esperada según la carga).
3. Isolation Forest.
4. Con muchas fallas registradas, supervivencia o clasificación de "falla en 7 días".

Evaluación por eventos sobre las fallas pasadas y validación temporal; nunca ventanas mezcladas al azar, porque están autocorrelacionadas (`ds-modelos-y-validacion`, bloque 8).

**Si además se pregunta por el efecto de un cambio de proceso** (un reactivo nuevo, una nueva estrategia de control): es causal. Hay que modelar el lazo de control y usar líneas comparables (DiD) o variaciones planificadas (`ds-causalidad`, secciones 4 y 7, bloques 1 y 9).

**Informe.**
> En los 8 meses de prueba retrospectiva, con el corte fijado en un período normal antes de mirar las fallas, el detector por residuo avisó 7 de 9 fallas con al menos 6 h de anticipación (mediana 31 h), con 0,6 falsas alarmas por semana. El umbral del fabricante avisó 2 de 9. Las dos fallas no avisadas fueron eléctricas, sin firma en la vibración.

## 4. Investigación: ¿la capacitación se asocia con la productividad? (encuesta)

**Ficha.** Decisión: qué afirma el paper o el informe. Tipo: comparativa; causal solo si el diseño lo permite. Unidad: el trabajador, anidado en faenas. Datos: encuesta con pesos de muestreo, autorreporte y escalas Likert.

**DAG.**
- Confusores, que se ajustan: antigüedad, cargo y faena.
- Mediador, que no se ajusta si se quiere el efecto total: las horas de uso de la herramienta aprendida.
- Confusor no medido: la motivación.

**Hipótesis.** El coeficiente de "capacitado" en la productividad, ajustado por los confusores, es mayor que cero. Rivales:
- la selección, porque los más motivados se capacitan: se trata con sensibilidad (E-value) o, si hay un instrumento creíble o un panel antes y después, con IV o DiD;
- la no respuesta de la encuesta: se compara con el padrón y se usan pesos;
- el sesgo de autorreporte: se usa una medida administrativa si existe.

**Verificación.**
- OLS (o logística u ordinal según la respuesta) con errores agrupados por faena (`ds-hipotesis-y-pruebas`, bloque 7).
- Con pocas faenas, el agregado por faena o un bootstrap por clúster (bloques 2 y 9).
- Faltantes con imputación múltiple, si son muchos.
- Varias medidas de productividad: Holm.
- E-value del efecto (`ds-causalidad`, bloque 7); como la productividad es continua, primero se convierte la diferencia estandarizada d en una razón de riesgo aproximada, RR ≈ exp(0,91·d).
- Las escalas Likert: se dice si se tratan como ordinales o como continuas, y se prueba la otra opción como sensibilidad.

**Informe.**
> Los trabajadores capacitados reportan una productividad 2,1 puntos mayor (IC 95 %: 0,7 a 3,6; errores agrupados por faena; ajustado por antigüedad, cargo y faena). Es una asociación: un confusor no medido, como la motivación, tendría que tener una razón de riesgo de 2,3 con la capacitación y con la productividad para anularla (E-value sobre la razón de riesgo aproximada a partir de la diferencia estandarizada).
