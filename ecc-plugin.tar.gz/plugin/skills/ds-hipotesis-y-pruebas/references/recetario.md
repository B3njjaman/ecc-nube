# Recetario de pruebas

Cada bloque se ejecuta solo. Las primeras líneas simulan datos con un efecto conocido: en un análisis real se reemplazan por los datos, y el `assert` final (el método recupera el efecto simulado) se mantiene como prueba del pipeline corriéndolo antes sobre datos simulados con la misma forma que los reales.

Probado el 2026-11-03 con numpy 2.4, pandas 2.3, scipy 1.17, statsmodels 0.15 y scikit-learn 1.9, con las advertencias de API obsoleta tratadas como error.

## Índice

1. Dos medias independientes: Welch, IC y g de Hedges
2. Bootstrap y permutación (cualquier estadístico)
3. Pareado: t pareada y Wilcoxon
4. Tres o más grupos: ANOVA de Welch, pares con Holm y Tukey
5. Dos proporciones, Fisher, χ² y V de Cramér, McNemar
6. Correlación con intervalo
7. Regresión con errores robustos y agrupados
8. Conteos: Poisson y binomial negativa con exposición
9. Medidas repetidas: modelo mixto
10. Equivalencia (TOST) y no inferioridad
11. Potencia, tamaño de muestra y efecto mínimo detectable
12. Comparaciones múltiples
13. Prueba A/B completa: SRM, efecto, CUPED y errores por usuario
14. A/B bayesiano beta-binomial

## 1. Dos medias independientes: Welch, IC y g de Hedges

```python
import numpy as np
from scipy import stats

rng = np.random.default_rng(1)
a = rng.normal(100, 15, 400)   # datos de ejemplo: ticket del grupo A
b = rng.normal(104, 20, 380)   # grupo B; el efecto real simulado es +4

res = stats.ttest_ind(b, a, equal_var=False)          # Welch: B - A
ic = res.confidence_interval(confidence_level=0.95)
dif = b.mean() - a.mean()

# g de Hedges: d con la desviación combinada y corrección por muestra chica
na, nb = len(a), len(b)
s_comb = np.sqrt(((na - 1) * a.var(ddof=1) + (nb - 1) * b.var(ddof=1)) / (na + nb - 2))
g = dif / s_comb * (1 - 3 / (4 * (na + nb) - 9))

print(f"diferencia {dif:.2f} (IC 95 %: {ic.low:.2f} a {ic.high:.2f}); t = {res.statistic:.2f}, "
      f"gl = {res.df:.0f}, p = {res.pvalue:.4f}; g de Hedges = {g:.2f}")
assert ic.low < 4 < ic.high  # chequeo: el IC contiene el efecto simulado
```

## 2. Bootstrap y permutación (cualquier estadístico)

Bootstrap para el intervalo de una diferencia de medianas (montos sesgados, tiempos de reparación); permutación para la prueba de "no hay diferencia" cuando la asignación fue aleatoria.

```python
import numpy as np
from scipy import stats

rng = np.random.default_rng(2)
a = rng.lognormal(3.0, 0.8, 300)   # datos de ejemplo: tiempos de reparación, método A
b = rng.lognormal(2.8, 0.8, 300)   # método B; mediana real exp(3) - exp(2.8) = 3.65 a favor de B

def dif_medianas(x, y, axis=-1):
    return np.median(x, axis=axis) - np.median(y, axis=axis)

boot = stats.bootstrap((a, b), dif_medianas, n_resamples=5000, method="BCa", rng=rng)
perm = stats.permutation_test((a, b), dif_medianas, permutation_type="independent",
                              n_resamples=5000, rng=rng)
ic = boot.confidence_interval
print(f"mediana A - mediana B = {dif_medianas(a, b):.2f} (IC 95 % BCa: {ic.low:.2f} a {ic.high:.2f}); "
      f"p por permutación = {perm.pvalue:.4f}")
real = np.exp(3.0) - np.exp(2.8)
assert ic.low < real < ic.high
```

Con datos agrupados (varias filas por cliente o equipo), el bootstrap remuestrea grupos enteros:

```python
import numpy as np
import pandas as pd

rng = np.random.default_rng(3)
n_eq = 40   # datos de ejemplo: 40 equipos con 25 mediciones cada uno, correlacionadas dentro del equipo
df = pd.DataFrame({"equipo": np.repeat(np.arange(n_eq), 25)})
df["y"] = 50 + np.repeat(rng.normal(0, 5, n_eq), 25) + rng.normal(0, 2, len(df))

grupos = df.groupby("equipo")["y"]
sumas, conteos = grupos.sum().to_numpy(), grupos.size().to_numpy()
medias_boot = []
for _ in range(4000):
    idx = rng.integers(0, n_eq, n_eq)                 # remuestrea equipos, no filas
    medias_boot.append(sumas[idx].sum() / conteos[idx].sum())
lo, hi = np.percentile(medias_boot, [2.5, 97.5])
ingenuo = 1.96 * df["y"].std(ddof=1) / np.sqrt(len(df))
print(f"media {df['y'].mean():.2f}; IC por clúster {lo:.2f} a {hi:.2f} "
      f"(ancho {hi - lo:.2f}) frente al ingenuo ±{ingenuo:.2f} (ancho {2 * ingenuo:.2f})")
assert (hi - lo) > 2 * ingenuo  # tratar las filas como independientes subestima la incertidumbre
```

## 3. Pareado: t pareada y Wilcoxon

```python
import numpy as np
from scipy import stats

rng = np.random.default_rng(4)
antes = rng.normal(70, 10, 30)                # datos de ejemplo: el mismo equipo antes y después
despues = antes + rng.normal(2.5, 3, 30)      # mejora real simulada de 2.5

res = stats.ttest_rel(despues, antes)
ic = res.confidence_interval()
w = stats.wilcoxon(despues - antes)
print(f"cambio medio {np.mean(despues - antes):.2f} (IC 95 %: {ic.low:.2f} a {ic.high:.2f}); "
      f"p = {res.pvalue:.4g}; Wilcoxon p = {w.pvalue:.4g}")
assert ic.low < 2.5 < ic.high
```

## 4. Tres o más grupos: ANOVA de Welch, pares con Holm y Tukey

```python
from itertools import combinations

import numpy as np
from scipy import stats
from statsmodels.stats.multitest import multipletests
from statsmodels.stats.oneway import anova_oneway

rng = np.random.default_rng(5)
grupos = {   # datos de ejemplo: recuperación por turno; solo C difiere (+3)
    "A": rng.normal(85, 2, 40),
    "B": rng.normal(85, 4, 35),
    "C": rng.normal(88, 3, 45),
}
welch = anova_oneway(list(grupos.values()), use_var="unequal")
print(f"ANOVA de Welch: F = {welch.statistic:.2f}, p = {welch.pvalue:.4g}")

pares = list(combinations(grupos, 2))
p_crudos = [stats.ttest_ind(grupos[x], grupos[y], equal_var=False).pvalue for x, y in pares]
rechaza, p_holm, _, _ = multipletests(p_crudos, method="holm")
for (x, y), p, r in zip(pares, p_holm, rechaza):
    print(f"  {x} vs {y}: p Holm = {p:.4g} {'*' if r else ''}")

tukey = stats.tukey_hsd(*grupos.values())   # alternativa si las varianzas son parecidas
print("Tukey p:\n", np.round(tukey.pvalue, 4))
assert dict(zip(pares, rechaza)) == {("A", "B"): False, ("A", "C"): True, ("B", "C"): True}
```

## 5. Dos proporciones, Fisher, χ² y V de Cramér, McNemar

```python
import numpy as np
from scipy import stats
from scipy.stats.contingency import association
from statsmodels.stats.contingency_tables import mcnemar
from statsmodels.stats.proportion import confint_proportions_2indep, test_proportions_2indep

# Dos proporciones (datos de ejemplo: conversiones de B y A; diferencia real 1.2 pp)
conv_b, n_b, conv_a, n_a = 2965, 24105, 2674, 24090
lo, hi = confint_proportions_2indep(conv_b, n_b, conv_a, n_a, compare="diff")
prueba = test_proportions_2indep(conv_b, n_b, conv_a, n_a, compare="diff")
print(f"B - A = {100 * (conv_b / n_b - conv_a / n_a):.2f} pp (IC 95 %: {100 * lo:.2f} a {100 * hi:.2f}); "
      f"z = {prueba.statistic:.2f}, p = {prueba.pvalue:.4f}")

# Pocos casos: exacta de Fisher (defectos con y sin el proveedor nuevo)
tabla = [[3, 47], [11, 39]]
print("Fisher:", stats.fisher_exact(tabla))

# Tabla r x c: chi cuadrado de independencia y V de Cramér
tabla_rc = np.array([[120, 90, 40], [80, 110, 60]])
chi = stats.chi2_contingency(tabla_rc)
print(f"chi2 = {chi.statistic:.2f}, gl = {chi.dof}, p = {chi.pvalue:.4g}, "
      f"V de Cramér = {association(tabla_rc, method='cramer'):.3f}; esperado mínimo {chi.expected_freq.min():.1f}")

# McNemar: dos clasificadores sobre los mismos casos [[ambos bien, solo 1 bien], [solo 2 bien, ambos mal]]
print("McNemar:", mcnemar([[700, 45], [20, 235]], exact=True))
assert lo > 0
```

## 6. Correlación con intervalo

```python
import numpy as np
from scipy import stats

rng = np.random.default_rng(6)
x = rng.normal(size=200)                       # datos de ejemplo
y = 0.4 * x + rng.normal(scale=0.9, size=200)  # correlación real ≈ 0.41

r = stats.pearsonr(x, y)
ic = r.confidence_interval(confidence_level=0.95)
rho = stats.spearmanr(x, y)
boot = stats.bootstrap((x, y), lambda u, v: stats.spearmanr(u, v).statistic,
                       paired=True, vectorized=False, n_resamples=2000, rng=rng)
print(f"Pearson r = {r.statistic:.3f} (IC 95 %: {ic.low:.3f} a {ic.high:.3f}); "
      f"Spearman ρ = {rho.statistic:.3f} (IC bootstrap {boot.confidence_interval.low:.3f} a "
      f"{boot.confidence_interval.high:.3f})")
real = 0.4 / np.sqrt(0.4**2 + 0.9**2)
assert ic.low < real < ic.high
```

## 7. Regresión con errores robustos y agrupados

```python
import numpy as np
import pandas as pd
import statsmodels.formula.api as smf

rng = np.random.default_rng(7)
n_faenas, por_faena = 30, 40   # datos de ejemplo: trabajadores anidados en faenas
df = pd.DataFrame({"faena": np.repeat(np.arange(n_faenas), por_faena)})
df["antiguedad"] = rng.gamma(3, 3, len(df))
p_faena = np.repeat(rng.uniform(0.05, 0.8, n_faenas), por_faena)   # cada faena capacita distinto
df["capacitado"] = (rng.random(len(df)) < p_faena).astype(int)
efecto_faena = np.repeat(rng.normal(0, 4, n_faenas), por_faena)
df["productividad"] = (60 + 2.0 * df["capacitado"] + 0.5 * df["antiguedad"] + efecto_faena
                       + rng.normal(0, 3 + 0.2 * df["antiguedad"]))   # varianza no constante

hc3 = smf.ols("productividad ~ capacitado + antiguedad", df).fit(cov_type="HC3")
cl = smf.ols("productividad ~ capacitado + antiguedad", df).fit(
    cov_type="cluster", cov_kwds={"groups": df["faena"]})
print(cl.summary().tables[1])
lo, hi = cl.conf_int().loc["capacitado"]
print(f"capacitado: {cl.params['capacitado']:.2f} (IC 95 % agrupado por faena {lo:.2f} a {hi:.2f}); "
      f"EE HC3 {hc3.bse['capacitado']:.3f} vs agrupado {cl.bse['capacitado']:.3f}")
assert lo < 2.0 < hi
# diagnóstico: graficar cl.resid contra cl.fittedvalues y un Q-Q de los residuos
```

## 8. Conteos: Poisson y binomial negativa con exposición

```python
import numpy as np
import pandas as pd
import statsmodels.api as sm
import statsmodels.formula.api as smf

rng = np.random.default_rng(8)
n = 300   # datos de ejemplo: fallas por equipo con distintas horas de operación
df = pd.DataFrame({"planta": rng.choice(["norte", "sur"], n), "horas": rng.uniform(200, 2000, n)})
tasa = np.where(df["planta"] == "sur", 1.5, 1.0) * 0.004            # razón de tasas real = 1.5
df["fallas"] = rng.poisson(tasa * df["horas"] * rng.gamma(2, 1 / 2, n))  # con sobredispersión

poisson = smf.glm("fallas ~ planta", df, family=sm.families.Poisson(), exposure=df["horas"]).fit()
dispersion = poisson.pearson_chi2 / poisson.df_resid
print(f"dispersión de Pearson = {dispersion:.2f} (≈ 1 si Poisson basta; > 1.5 sugiere binomial negativa)")

nb = smf.negativebinomial("fallas ~ planta", df, exposure=df["horas"]).fit(disp=0)
rr = np.exp(nb.params["planta[T.sur]"])
lo, hi = np.exp(nb.conf_int().loc["planta[T.sur]"])
print(f"razón de tasas sur/norte = {rr:.2f} (IC 95 %: {lo:.2f} a {hi:.2f}); alpha = {nb.params['alpha']:.2f}")
assert lo < 1.5 < hi
```

## 9. Medidas repetidas: modelo mixto

```python
import numpy as np
import pandas as pd
import statsmodels.formula.api as smf
from scipy import stats

rng = np.random.default_rng(9)
plantas, turnos = 20, 30   # datos de ejemplo: rendimiento por turno en 20 plantas, mitad con método nuevo
df = pd.DataFrame({"planta": np.repeat(np.arange(plantas), turnos)})
df["metodo_nuevo"] = (df["planta"] % 2).astype(int)                     # se asigna por planta
df["rendimiento"] = (100 + 3 * df["metodo_nuevo"] + np.repeat(rng.normal(0, 4, plantas), turnos)
                     + rng.normal(0, 2, len(df)))

mixto = smf.mixedlm("rendimiento ~ metodo_nuevo", df, groups=df["planta"]).fit()
lo, hi = mixto.conf_int().loc["metodo_nuevo"]
# con solo 20 plantas, una realización puede alejarse bastante del efecto real (3): se lee el IC, no el punto
print(f"modelo mixto: {mixto.params['metodo_nuevo']:.2f} (IC 95 % de Wald: {lo:.2f} a {hi:.2f}); "
      f"varianza entre plantas {mixto.cov_re.iloc[0, 0]:.1f}")

# Con pocos grupos el IC de Wald del mixto queda corto. Alternativa simple y honesta:
# promediar por planta (la unidad asignada) y comparar las 20 medias con Welch.
medias = df.groupby("planta").agg(y=("rendimiento", "mean"), t=("metodo_nuevo", "first"))
w = stats.ttest_ind(medias.y[medias.t == 1], medias.y[medias.t == 0], equal_var=False)
ic = w.confidence_interval()
print(f"medias por planta + Welch: IC 95 % {ic.low:.2f} a {ic.high:.2f} (gl = {w.df:.1f})")
assert abs(mixto.params["metodo_nuevo"] - 3) < 3 * mixto.bse["metodo_nuevo"]
```

La unidad efectiva es la planta (20), no el turno (600). En una simulación de 300 repeticiones de este mismo diseño, el IC de Wald del modelo mixto cubrió el efecto real el 92,7 % de las veces y el de medias por planta con Welch el 95,7 %. Con menos de unos 30 o 40 grupos se reporta el agregado (o un bootstrap por clúster) junto al mixto.

## 10. Equivalencia (TOST) y no inferioridad

```python
import numpy as np
from statsmodels.stats.weightstats import ttost_ind, ttest_ind

rng = np.random.default_rng(10)
actual = rng.normal(92.0, 2.0, 120)   # datos de ejemplo: calidad con el proceso actual
nuevo = rng.normal(91.9, 2.0, 120)    # proceso nuevo, más barato; diferencia real -0.1
margen = 1.0                          # equivalentes si |diferencia| < 1 punto (lo fija el negocio)

p_tost, _, _ = ttost_ind(nuevo, actual, -margen, margen, usevar="unequal")
print(f"TOST: p = {p_tost:.4g} -> {'equivalentes' if p_tost < 0.05 else 'no se demuestra equivalencia'}")

# No inferioridad: H0: nuevo - actual <= -margen; H1: nuevo - actual > -margen (unilateral)
t, p_ni, _ = ttest_ind(nuevo, actual, alternative="larger", usevar="unequal", value=-margen)
print(f"no inferioridad: p = {p_ni:.4g}")
assert p_tost < 0.05 and p_ni < 0.05
```

## 11. Potencia, tamaño de muestra y efecto mínimo detectable

```python
import numpy as np
from scipy import stats
from statsmodels.stats.power import NormalIndPower, TTestIndPower
from statsmodels.stats.proportion import proportion_effectsize

# Medias: delta de 4 con desviación 18 -> d = 0.22
n_medias = TTestIndPower().solve_power(effect_size=4 / 18, alpha=0.05, power=0.8)
print(f"medias: {np.ceil(n_medias):.0f} por grupo")

# Proporciones: pasar de 11 % a 12 % (h de Cohen)
h = proportion_effectsize(0.12, 0.11)
n_prop = NormalIndPower().solve_power(effect_size=h, alpha=0.05, power=0.8)
print(f"proporciones 11 % -> 12 %: {np.ceil(n_prop):,.0f} por grupo")

# Al revés: con 10 semillas por algoritmo, qué efecto estandarizado se puede detectar
mde = TTestIndPower().solve_power(nobs1=10, alpha=0.05, power=0.8)
print(f"con 10 por grupo, efecto mínimo detectable d = {mde:.2f}")

# Por simulación: el análisis real planeado (aquí Welch sobre datos sesgados), mil veces
rng = np.random.default_rng(11)
def potencia_simulada(n, efecto, reps=1000):
    hits = 0
    for _ in range(reps):
        a = rng.lognormal(3.0, 0.9, n)
        b = rng.lognormal(3.0, 0.9, n) * efecto
        hits += stats.ttest_ind(b, a, equal_var=False).pvalue < 0.05
    return hits / reps
for n in (100, 200, 400):
    print(f"n = {n}: potencia simulada {potencia_simulada(n, 1.15):.2f}")
assert 300 < n_medias < 350
```

## 12. Comparaciones múltiples

```python
import numpy as np
from scipy import stats
from statsmodels.stats.multitest import multipletests

rng = np.random.default_rng(12)
# datos de ejemplo: 50 sensores comparados antes y después de una mantención; solo 5 cambian de verdad
efectos = np.r_[np.full(5, 0.8), np.zeros(45)]
p = np.array([stats.ttest_ind(rng.normal(e, 1, 40), rng.normal(0, 1, 40)).pvalue for e in efectos])

for metodo in ("holm", "fdr_bh"):
    rechaza, p_aj, _, _ = multipletests(p, alpha=0.05, method=metodo)
    print(f"{metodo}: {rechaza.sum()} descubrimientos ({rechaza[:5].sum()} reales, {rechaza[5:].sum()} falsos)")
print(f"sin corregir: {(p < 0.05).sum()} descubrimientos ({(p[5:] < 0.05).sum()} falsos)")
```

## 13. Prueba A/B completa: SRM, efecto, CUPED y errores por usuario

```python
import numpy as np
import pandas as pd
import statsmodels.formula.api as smf
from scipy import stats

rng = np.random.default_rng(13)
n = 20000   # datos de ejemplo: usuarios aleatorizados 50/50; gasto en el período previo y durante la prueba
df = pd.DataFrame({"grupo": rng.integers(0, 2, n)})
df["gasto_previo"] = rng.gamma(2, 25, n)
df["gasto"] = 0.8 * df["gasto_previo"] + rng.gamma(2, 10, n) + 1.5 * df["grupo"]   # efecto real +1.5

# 1. SRM: ¿la asignación respeta el 50/50 planeado?
conteos = df["grupo"].value_counts().sort_index().to_numpy()
srm = stats.chisquare(conteos, f_exp=[n / 2, n / 2])
print(f"SRM: {conteos} p = {srm.pvalue:.3f} {'ALARMA: no interpretar' if srm.pvalue < 0.001 else 'ok'}")

# 2. Efecto sin ajuste y con CUPED / ANCOVA (covariable anterior a la asignación, centrada)
df["previo_c"] = df["gasto_previo"] - df["gasto_previo"].mean()
crudo = smf.ols("gasto ~ grupo", df).fit(cov_type="HC3")
cuped = smf.ols("gasto ~ grupo + previo_c", df).fit(cov_type="HC3")
for nombre, m in (("sin ajuste", crudo), ("CUPED/ANCOVA", cuped)):
    lo, hi = m.conf_int().loc["grupo"]
    print(f"{nombre}: {m.params['grupo']:.2f} (IC 95 %: {lo:.2f} a {hi:.2f}; ancho {hi - lo:.2f})")
assert cuped.bse["grupo"] < 0.7 * crudo.bse["grupo"]

# 3. Métrica por sesión con aleatorización por usuario: errores agrupados por usuario
ses = df.loc[df.index.repeat(rng.integers(1, 8, n))].reset_index(names="usuario")
ses["compra"] = (rng.random(len(ses)) < 0.10 + 0.01 * ses["grupo"]).astype(int)
agrupado = smf.ols("compra ~ grupo", ses).fit(cov_type="cluster", cov_kwds={"groups": ses["usuario"]})
lo, hi = agrupado.conf_int().loc["grupo"]
print(f"compra por sesión: {100 * agrupado.params['grupo']:.2f} pp (IC 95 % agrupado por usuario "
      f"{100 * lo:.2f} a {100 * hi:.2f})")

# Esa regresión estima la razón compras/sesiones (equivale al método delta). Si el tratamiento cambiara
# cuántas sesiones hace cada usuario, la razón mezclaría dos efectos: se reporta también el del denominador.
por_usuario = ses.groupby("usuario").agg(grupo=("grupo", "first"), sesiones=("compra", "size"))
efecto_ses = smf.ols("sesiones ~ grupo", por_usuario).fit(cov_type="HC3")
lo_s, hi_s = efecto_ses.conf_int().loc["grupo"]
print(f"sesiones por usuario: {efecto_ses.params['grupo']:+.3f} (IC 95 %: {lo_s:.3f} a {hi_s:.3f})")
```

## 14. A/B bayesiano beta-binomial

```python
import numpy as np

rng = np.random.default_rng(14)
conv_a, n_a, conv_b, n_b = 2674, 24090, 2965, 24105   # datos de ejemplo
a_priori = (1, 1)   # uniforme; declararlo y probar otro (p. ej. el histórico) como sensibilidad

post_a = rng.beta(a_priori[0] + conv_a, a_priori[1] + n_a - conv_a, 200_000)
post_b = rng.beta(a_priori[0] + conv_b, a_priori[1] + n_b - conv_b, 200_000)
dif = post_b - post_a
lo, hi = np.percentile(dif, [2.5, 97.5])
perdida_b = np.maximum(post_a - post_b, 0).mean()   # lo que se pierde en promedio si se elige B y era peor
print(f"P(B > A) = {(dif > 0).mean():.4f}; P(B - A > 1 pp) = {(dif > 0.01).mean():.3f}; "
      f"diferencia {100 * dif.mean():.2f} pp (intervalo creíble 95 %: {100 * lo:.2f} a {100 * hi:.2f}); "
      f"pérdida esperada de elegir B {100 * perdida_b:.4f} pp")
```
