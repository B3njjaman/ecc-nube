---
name: ds-hipotesis-y-pruebas
description: "Formular hipótesis comprobables y verificarlas con la prueba estadística correcta: estimando, hipótesis nula y alternativa, efecto mínimo relevante, superioridad, no inferioridad o equivalencia, explicaciones rivales, elección de la prueba según la pregunta y el diseño (no según una prueba de normalidad), supuestos, tamaño del efecto con intervalo, potencia y tamaño de muestra, comparaciones múltiples, remuestreo, enfoque bayesiano y pruebas A/B bien hechas (SRM, CUPED, sin espiar). Úsala cuando haya que decidir qué prueba usar, si una diferencia es real o azar, cuántos datos o semillas hacen falta, cómo plantear una hipótesis, cómo leer un p-valor o cómo revisar una prueba A/B o el análisis estadístico de un paper."
metadata:
  origin: "ecc-benja; ideas de statistical-analysis, statistical-power y hypothesis-generation de K-Dense-AI/claude-scientific-skills (MIT, a25cf9ec00e2)"
---

# Hipótesis y pruebas estadísticas

Una prueba estadística responde una sola pregunta: si estos datos serían raros en un mundo donde la hipótesis nula es cierta. No dice si la hipótesis es verdadera, no mide la importancia del efecto y no arregla un mal diseño. Por eso aquí se trabaja en este orden: hipótesis bien escrita, diseño, prueba, magnitud e intervalo.

El código de cada prueba, ejecutable y con datos simulados donde se conoce la respuesta, está en [references/recetario.md](references/recetario.md) (probado con scipy 1.17, statsmodels 0.15 y scikit-learn 1.9). El ciclo completo está en `ds-maestro`; los efectos causales sin experimento, en `ds-causalidad`.

## 1. De la idea a una hipótesis comprobable

Una hipótesis comprobable tiene cinco piezas:

1. **Estimando**: el número exacto que se va a estimar. "La diferencia de la tasa de compra a 7 días entre la página B y la A, en usuarios nuevos de escritorio, entre el 1 y el 28 de noviembre."
2. **H0 y H1**, y la dirección. Unilateral solo si se decidió antes de ver los datos y si un efecto en la dirección contraria llevaría a la misma decisión que un efecto nulo.
3. **Efecto mínimo relevante (δ)**: el cambio más chico que cambiaría la decisión. Lo fija el negocio o la teoría, no los datos.
4. **Predicción y refutación**: qué se vería si es cierta y qué resultado la daría por falsa.
5. **Rivales**: las otras explicaciones de ese mismo resultado (sección 2).

| Mal | Bien |
|---|---|
| "La nueva página mejora la conversión." | "En usuarios nuevos de escritorio, la compra a 7 días con B es mayor que con A (unilateral, α = 0,05), con 80 % de potencia si la diferencia real es de 1 pp, el mínimo relevante." |
| "El reactivo nuevo mejora la recuperación." | "Con el reactivo nuevo, la recuperación de cobre por turno sube al menos 0,5 puntos frente a las líneas que siguen con el antiguo, ajustando por la ley de alimentación." |
| "Mi algoritmo es mejor que PPO." | "En los 5 entornos de la tesis, el IQM del retorno normalizado final de la variante supera al de PPO; la probabilidad de mejora es > 0,5 con un IC 95 % que no incluye 0,5." |

Hay tres tipos de afirmación, y cada uno tiene su prueba:

- **Superioridad**: B es mejor que A. Exigir que sea mejor por al menos δ (superioridad con margen) es otra hipótesis y pide bastante más muestra que tener potencia para detectar un efecto de δ: la potencia se calcula para la hipótesis que se va a probar.
- **No inferioridad**: B no es peor que A en más de un margen. Es lo que se quiere cuando el cambio abarata o simplifica ("el proceso nuevo no baja la calidad más de 1 %").
- **Equivalencia**: |B − A| < δ, con TOST (dos pruebas unilaterales). Un p > 0,05 en una prueba de diferencia **no** demuestra equivalencia: solo dice que no hubo evidencia suficiente.

## 2. Explicaciones rivales

Se escriben antes de mirar el resultado, y cada una lleva cómo se va a descartar.

| Rival | Cómo se ve | Cómo se descarta |
|---|---|---|
| Azar | efecto grande con muestra chica, que no se repite | potencia calculada de antemano, intervalo, replicar en otros datos |
| Medición o instrumentación | cambió el sensor, el tracking o la definición del campo justo ese mes | registro de cambios, una métrica alternativa que no dependa de esa medición |
| Confusor | una tercera variable mueve a las dos (la ley del mineral mueve el reactivo y la recuperación) | DAG y ajuste, estratificar, diseño causal (`ds-causalidad`) |
| Selección o supervivencia | solo se observa una parte (los que respondieron la encuesta, los equipos que siguen en servicio) | comparar con la población, modelar quién entra a los datos |
| Causalidad inversa | Y mueve a X (los clientes que se van a ir dejan de usar la app) | orden temporal y rezagos; ojo con la anticipación (quien ya decidió irse cambia su conducta antes de que se registre) |
| Regresión a la media | se eligieron los casos extremos y "mejoraron" solos | grupo de comparación igual de extremo y no intervenido |
| Tendencia o estacionalidad | el efecto coincide con una fecha | mismo período del año anterior, grupo de control en paralelo |
| Novedad o aprendizaje | el efecto se desvanece o crece con las semanas | mirar el efecto por semana de exposición |
| Paradoja de Simpson | el efecto agregado se invierte dentro de cada segmento | análisis por segmento; se ajusta por esa variable solo si el DAG dice que es un confusor (si es mediador o colisionador, ajustar sesga) |
| Comparaciones múltiples | se probaron 40 segmentos y uno salió | familia definida antes y corrección (sección 7) |
| Fuga o error de código | el resultado es demasiado bueno | placebo con el objetivo barajado, datos simulados con la respuesta conocida |

## 3. Elegir la prueba

Se elige por la pregunta y el diseño. No se corre Shapiro o Levene para decidir qué prueba usar: esas pruebas tienen poca potencia con n chico (y no detectan lo que importa) y rechazan cualquier cosa con n grande, y elegir la prueba según su resultado altera el error de la prueba final.

| Pregunta | Diseño y datos | Por defecto | Alternativa |
|---|---|---|---|
| ¿Difieren dos medias? | dos grupos independientes | **Welch** (`ttest_ind(equal_var=False)`), nunca Student por defecto | bootstrap o permutación de la diferencia; Mann-Whitney si la pregunta es "¿uno tiende a dar valores más altos?" (no compara medianas) |
| ¿Cambió una medida en los mismos casos? | pareado (antes y después, mismo equipo con dos métodos) | t pareada sobre las diferencias | Wilcoxon de rangos con signo (otra hipótesis: supone diferencias simétricas); bootstrap de las diferencias |
| ¿Difieren tres o más medias? | grupos independientes | ANOVA de Welch (`anova_oneway(use_var="unequal")`), después pares con Welch y Holm | Kruskal-Wallis; Tukey HSD si las varianzas son parecidas |
| ¿Difieren, con mediciones repetidas o casos anidados? | varias mediciones por unidad (turnos por planta, alumnos por curso) | modelo mixto (`mixedlm`) o GEE | promediar por unidad y usar la prueba simple |
| ¿Difieren dos proporciones? | grupos independientes | diferencia con IC (`confint_proportions_2indep`) y su prueba | exacta de Fisher con pocos casos (esperados < 5) |
| ¿Hay relación entre dos categóricas? | tabla r × c | χ² de independencia + V de Cramér | Fisher o Monte Carlo con celdas chicas |
| ¿Dos clasificadores o jueces difieren en los mismos casos? | proporciones pareadas | McNemar | — |
| ¿Hay relación entre dos continuas? | pares (x, y) | Pearson con IC si es lineal; Spearman si es monótona | bootstrap del coeficiente |
| ¿Qué efecto tiene X controlando Z? | varias variables | OLS con errores robustos (HC3); agrupados si hay grupos | GLM según el tipo de respuesta |
| ¿Difieren tasas de conteo? | conteos con exposición (horas, clientes) | GLM de Poisson con `exposure` | binomial negativa si hay sobredispersión |
| ¿Dura menos un grupo? | tiempo hasta evento con censura | log-rank + Cox (`lifelines`) | Weibull AFT; supervivencia en `ds-modelos-y-validacion` |
| ¿Son equivalentes? | dos grupos y un margen δ | TOST (`ttost_ind`) | intervalo 90 % dentro de ±δ (es lo mismo) |
| ¿Difiere una mediana, un percentil 95, un IQM u otro estadístico raro? | casi cualquiera (el bootstrap falla con máximos, cuantiles extremos y muestras muy chicas) | bootstrap (`scipy.stats.bootstrap`) | permutación (`scipy.stats.permutation_test`) |

La unidad de la prueba es la unidad independiente: si se aleatorizó por usuario y se mide por sesión, o hay muchas mediciones por equipo, se agrega por unidad o se usan errores agrupados por unidad. Mil episodios de una misma semilla de RL son una sola observación del algoritmo, no mil.

## 4. Supuestos, en orden de importancia

1. **Independencia.** Se asegura con el diseño, no con una prueba. Violarla (datos en el tiempo, casos agrupados, pseudorreplicación) es lo que más infla los falsos positivos.
2. **Que el modelo describa la pregunta.** Una media comparada en datos muy sesgados (montos de compra, tiempos de reparación) puede no ser lo que importa; a veces la pregunta es la mediana o el log.
3. **Colas pesadas y extremos.** Con n chico, uno o dos valores mueven la media y la t. Se miran los datos y se decide antes cómo tratarlos; nunca se quitan extremos después de ver que "estropean" el resultado.
4. **Varianzas distintas.** Se resuelve usando Welch o errores HC3 por defecto, no con una prueba previa.
5. **Normalidad.** Para comparar medias importa poco con muestras moderadas y distribuciones no muy sesgadas, pero no hay un "n = 30" mágico: con mucho sesgo o colas pesadas hace falta más, o bootstrap.

Los supuestos se revisan con gráficos (histograma por grupo, Q-Q de los residuos, residuos contra ajustados) y se reportan. Si un supuesto falla, se dice qué se hizo y se muestra el análisis de sensibilidad.

## 5. Tamaño del efecto e intervalo

Primero en las unidades originales, que son las que entiende quien decide (pesos, puntos porcentuales, horas, toneladas). Los estandarizados sirven para comparar estudios.

| Prueba | Efecto a reportar |
|---|---|
| Dos medias | diferencia con IC; g de Hedges |
| Dos proporciones | diferencia en pp con IC; riesgo relativo; odds ratio solo si el modelo es logístico |
| Conteos | razón de tasas con IC |
| Supervivencia | hazard ratio con IC; diferencia de mediana de supervivencia |
| Correlación | r o ρ con IC |
| Regresión | coeficiente con IC, en unidades de la respuesta por unidad de X |
| χ² | V de Cramér |

La regla de decisión se lee con los dos extremos del intervalo, contra 0 y contra δ:

- límite inferior ≥ δ: el efecto es relevante;
- límite inferior entre 0 y δ: el efecto es positivo, pero puede ser menor al que importa;
- el intervalo incluye el 0: no se descarta un efecto nulo; si además el límite superior es menor que δ, sí se descarta un efecto relevante (la lógica de la equivalencia);
- límite superior < 0: el efecto es negativo.

## 6. Potencia y tamaño de muestra (antes de juntar datos)

- Insumos: δ, la variabilidad (de datos históricos o un piloto), α y la potencia (80 % o 90 %).
- Si el n está fijo (los datos que hay, las semillas que alcanzan en el cluster), se calcula al revés: el **efecto mínimo detectable** con ese n. Si es mayor que δ, el estudio no puede responder la pregunta, y eso se dice antes de correrlo.
- Para diseños con agrupamiento, medidas repetidas o métricas raras, la potencia se calcula **simulando**: generar datos con el efecto δ, correr el análisis planeado mil veces y contar cuántas veces detecta.
- La "potencia observada" (calculada después con el efecto que salió) no sirve: es una transformación del p-valor y no agrega información.

## 7. Comparaciones múltiples

- La familia se define antes: las hipótesis confirmatorias de la ficha.
- Pocas hipótesis confirmatorias, donde un solo falso positivo es caro: **Holm** (controla la probabilidad de algún falso positivo y es mejor que Bonferroni).
- Muchas pruebas exploratorias (barrer 200 variables, segmentos o sensores): **Benjamini-Hochberg** (controla la tasa de falsos descubrimientos, es decir, la proporción esperada de falsos entre lo que se declara descubierto, con pruebas independientes o con dependencia positiva; con dependencia arbitraria, Benjamini-Yekutieli, `method="fdr_by"`).
- Lo que salió de un barrido es una hipótesis nueva, no un hallazgo, hasta que se confirma con otros datos.

## 8. Pruebas A/B

Antes de lanzar:
- La **unidad de aleatorización** es la unidad de análisis. Si se aleatoriza por usuario, las métricas por sesión o por pedido se analizan con errores agrupados por usuario o con el método delta. Esa métrica es una razón (compras / sesiones): si el tratamiento cambia cuántas sesiones hace cada usuario, la razón mezcla dos efectos, y por eso se reporta también el efecto sobre el denominador (sesiones por usuario) o se elige una métrica por usuario.
- Potencia y **duración fijadas antes**, por lo menos un ciclo semanal completo; en B2B, un ciclo de compra.
- Métrica principal, métricas de resguardo (latencia, devoluciones, reclamos) y δ en la ficha.

Durante:
- **No se espía.** Mirar el p-valor todos los días y parar cuando baja de 0,05 dispara los falsos positivos muy por encima del 5 %. Si hace falta mirar antes, se usa un diseño secuencial planificado (gasto de α tipo O'Brien-Fleming o pruebas siempre válidas tipo mSPRT), no la prueba fija.

Al analizar:
1. **SRM primero**: si la proporción de usuarios por grupo se aleja de la planeada (χ², alarma con p < 0,001), la asignación está rota y el resultado no se interpreta hasta encontrar la causa.
2. **CUPED / ANCOVA**: ajustar por la misma métrica en el período previo reduce la varianza, a veces a la mitad, y el estimador sigue siendo consistente si la covariable es anterior a la asignación (el sesgo de muestra finita por estimar el ajuste con los mismos datos es despreciable en tamaños de A/B).
3. Efecto con IC contra δ, resguardos y efecto por semana (novedad).
4. Segmentos solo si se planearon; si no, son exploratorios.
5. Interferencia: si los grupos se afectan entre sí (mercados de dos lados, inventario compartido, una misma faena), la aleatorización por individuo no sirve; se aleatoriza por clúster o por tiempo.

## 9. Enfoque bayesiano

Sirve cuando se quiere la probabilidad de que B sea mejor que A, la pérdida esperada de elegir mal, o incorporar información previa con muestras chicas. El a priori se declara y se muestra la sensibilidad a él. Con parada opcional, la posterior sigue siendo válida si el modelo y el a priori son razonables. Lo que se degrada son las tasas de error de las decisiones: parar cuando "se ve bien" sube los falsos positivos en sentido frecuentista, y con muestras chicas el a priori pesa mucho. Si importan los falsos positivos, la regla de parada se fija antes. En el recetario está el caso beta-binomial para conversiones.

## 10. Remuestreo

- **Bootstrap**: el intervalo de casi cualquier estadístico suave (media, mediana, percentiles no extremos, IQM, diferencia de AUC). Falla con máximos y mínimos, cuantiles extremos y muestras muy chicas. Se remuestrea la unidad independiente: si hay grupos, se remuestrean grupos enteros (bootstrap por clúster); en series de tiempo, bloques.
- **Permutación**: la prueba exacta de "no hay diferencia" cuando los grupos son intercambiables bajo H0 (asignación aleatoria). No vale si los grupos difieren en varianza o en estructura y la pregunta es solo por la media. Se permuta respetando el diseño: dentro de los pares o de los bloques, si los hay.

## 11. Cómo se reporta

> El grupo B tuvo una conversión de 12,3 % frente a 11,1 % de A (diferencia 1,2 pp; IC 95 %: 0,4 a 2,0; z = 2,9; p = 0,004; n = 24.105 y 24.090). El efecto es positivo, pero el intervalo no descarta que sea menor que el mínimo relevante de 1 pp.

Siempre: estadísticos descriptivos por grupo, el efecto con IC, la prueba con su estadístico y el p exacto (no "p < 0,05"), n por grupo, los supuestos revisados y las desviaciones del plan. En un paper, además, la versión de las librerías y el código.

## Trampas

- Leer p como "la probabilidad de que H0 sea cierta". Es la probabilidad de datos así de extremos **si** H0 fuera cierta.
- Concluir "no hay efecto" desde p > 0,05 sin potencia ni equivalencia.
- "A fue significativo y B no, entonces A y B difieren": hay que probar la diferencia entre A y B.
- Pasar a unilateral, cambiar la métrica principal, quitar extremos o agregar covariables después de ver el resultado.
- Parar el experimento cuando el p cruza 0,05.
- Reportar solo los segmentos que salieron.
- Usar Student en vez de Welch, o errores comunes cuando hay agrupamiento o datos en el tiempo.
- Confundir la desviación estándar (dispersión de los datos) con el error estándar (incertidumbre de la media) en gráficos y tablas.
- Con n enorme, celebrar un efecto "significativo" de 0,01 pp que no cambia ninguna decisión.
